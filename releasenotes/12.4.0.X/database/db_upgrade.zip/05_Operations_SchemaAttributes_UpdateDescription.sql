UPDATE [CorePatterns].[SchemaAttributes] SET [Description] = '{"Values":[{ "Culture":"ca","Data":"Notificaci�"},{ "Culture":"es","Data":"Notificaci�n"},{ "Culture":"it","Data":"Notifica"},{ "Culture":"pt","Data":"Notifica��o"},{ "Culture":"en","Data":"Notification"}]}'
WHERE Id = 'a546d23e-2552-4f06-a78f-b7b41bca151f'

GO

UPDATE [CorePatterns].[SchemaAttributes] SET [Description] = '{"Values":[{ "Culture":"ca","Data":"Plantilla d''E-mail"},{ "Culture":"es","Data":"Plantilla de Email"},{ "Culture":"it","Data":"Modello di posta elettronica."},{ "Culture":"pt","Data":"Modelo de Email"},{ "Culture":"en","Data":"Email Template"}]}'
WHERE Id = '6161ba49-cfe9-4d45-96c4-b4de24fb4303'

GO

UPDATE [CorePatterns].[SchemaAttributes] SET [Description] = '{"Values":[{ "Culture":"ca","Data":"Grup de la Notificaci�"},{ "Culture":"es","Data":"Grupo de la Notificaci�n"},{ "Culture":"it","Data":"Gruppo di notifica"},{ "Culture":"pt","Data":"Grupo da Notifica��o"},{ "Culture":"en","Data":"Notification Group"}]}'
WHERE Id = '15c241a6-43cd-400b-9858-28e470b4a9fc'

GO

UPDATE [CorePatterns].[SchemaAttributes] SET [Description] = '{"Values":[{ "Culture":"ca","Data":"Grup d''Entitat de Notificaci�"},{ "Culture":"es","Data":"Grupo de Entidad de Notificaci�n"},{ "Culture":"it","Data":"Notification Entity Group."},{ "Culture":"pt","Data":"Grupo de Entidade de Notifica��o"},{ "Culture":"en","Data":"Notification Entity Group"}]}'
WHERE Id = '0102967c-ffe0-4361-95d8-964d45dcd0a9'

GO
UPDATE [CorePatterns].[SchemaAttributes] SET [Description] = '{"Values":[{ "Culture":"ca","Data":"Subscripci�"},{ "Culture":"es","Data":"Suscripci�n"},{ "Culture":"it","Data":"Sottoscrizione"},{ "Culture":"pt","Data":"Subscri��o"},{ "Culture":"en","Data":"Subscription"}]}'
WHERE Id = '463977d8-5812-4045-b79b-89c9f5102746'

GO

UPDATE [CorePatterns].[SchemaAttributes] SET [Description] = '{"Values":[{ "Culture":"ca","Data":"Restricci� d''Acc�s a l''Empresa"},{ "Culture":"es","Data":"Restricci�n de Acceso a la Empresa"},{ "Culture":"it","Data":"Limitazione dell''accesso all''azienda"},{ "Culture":"pt","Data":"Restri��o de Acesso � Empresa"},{ "Culture":"en","Data":"Company Access Restriction"}]}'
WHERE Id = 'f3ca66b7-4c22-4828-8507-c88920a7d3ea'

GO
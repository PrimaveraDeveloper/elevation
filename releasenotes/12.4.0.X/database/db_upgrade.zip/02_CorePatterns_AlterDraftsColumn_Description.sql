-- Drop view that used the column Description from CorePatterns.Drafts
IF OBJECT_ID(N'[CorePatterns].[DraftsView]') IS NOT NULL BEGIN DROP VIEW [CorePatterns].[DraftsView] END
GO

-- Drop another view that used the column Description from CorePatterns.Drafts
IF OBJECT_ID(N'[CorePatterns].[DraftResourcesView]') IS NOT NULL BEGIN DROP VIEW [CorePatterns].[DraftResourcesView] END
GO

-- Alter description column from nvarchar100 to nvarchar255
ALTER TABLE [CorePatterns].[Drafts] ALTER COLUMN [Description] nvarchar(255);
GO

-- Create DraftsView
CREATE VIEW [CorePatterns].[DraftsView]
WITH SCHEMABINDING AS
SELECT
    E.[Id]
    , E.[DraftId]
	, E.[Key]
	, E.[Description]
	, E.[Type]
	, E.[ControllerName]
	, E.[ParentId]
	, E.[OperationType]
	, E.[State]
	, E.[OperationId]
	, E.[RoleKey]
	, E.[NaturalKey]
	, E.[IsDraft]
	, E.[CreatedBy]
	, E.[CreatedOn]
	, E.[ModifiedBy]
	, E.[ModifiedOn]
	, E.[IsActive]
	, E.[IsDeleted]
	, E.[IsSystem]
	, E.[Version]
FROM [CorePatterns].[Drafts] E
WHERE E.[IsDeleted] = 0
GO

-- Create DraftResourceView
CREATE VIEW [CorePatterns].[DraftResourcesView] 
WITH SCHEMABINDING AS
SELECT
    E.[Id]
    , E.[DraftId]
    , E.[Key]
    , E.[Description]
    , E.[Type]
    , E.[ControllerName]
    , E.[ParentId]
    , E.[OperationType]
    , E.[State]
	, T0.NaturalKey as [Operation]
    , E.[OperationId]
    , E.[RoleKey]
    , E.[NaturalKey]
    , E.[IsDraft]
    , E.[CreatedBy]
    , E.[CreatedOn]
    , E.[ModifiedBy]
    , E.[ModifiedOn]
    , E.[IsActive] 
    , E.[IsDeleted]
    , E.[IsSystem]
    , E.[Version]
FROM [CorePatterns].[Drafts] E
		left join [CorePatterns].[Operations] T0 on E.OperationId = T0.Id
WHERE E.[IsDeleted] = 0
GO
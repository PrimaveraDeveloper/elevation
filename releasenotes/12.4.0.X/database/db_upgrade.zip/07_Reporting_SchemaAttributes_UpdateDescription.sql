UPDATE [CorePatterns].[SchemaAttributes] SET [Description] = '{"Values":[{ "Culture":"ca","Data":"Grup d''Entitat de Plantilla"},{ "Culture":"es","Data":"Grupo de Entidad de Plantilla"},{ "Culture":"it","Data":"Gruppo di entit� del modello"},{ "Culture":"pt","Data":"Grupo de Entidade de Modelo"},{ "Culture":"en","Data":"Template Entity Group"}]}'
WHERE Id = '51bc9fa1-acc8-4452-beac-059f7c52bf87'

GO
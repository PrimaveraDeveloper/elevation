IF NOT EXISTS(SELECT 1 FROM sys.columns 
        WHERE Name = N'ThumbnailColumnId'
        AND Object_ID = Object_ID(N'QueryBuilder.ListModelColumns'))
BEGIN
    ALTER TABLE [QueryBuilder].[ListModelColumns]
	ADD [ThumbnailColumnId] uniqueidentifier NULL;

	ALTER TABLE [QueryBuilder].[ListModelColumns]  
	WITH CHECK ADD  CONSTRAINT [ListModelColumns_ListModelColumnThumbnailColumnId_ColumnId_FK] 
	FOREIGN KEY(ThumbnailColumnId)
	REFERENCES [QueryBuilder].[ListModelColumns] ([Id])
END

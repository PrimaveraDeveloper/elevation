UPDATE [CorePatterns].[SchemaAttributes] SET [Description] = '{"Values":[{ "Culture":"ca","Data":"Model de la Llista"},{ "Culture":"es","Data":"Modelo de la Lista"},{ "Culture":"it","Data":"Elenco modello"},{ "Culture":"pt","Data":"Modelo da Lista"},{ "Culture":"en","Data":"List Model"}]}'
WHERE Id = 'f8ded5d8-0aa4-4092-8d95-e551567a8a38'

GO

UPDATE [CorePatterns].[SchemaAttributes] SET [Description] = '{"Values":[{ "Culture":"ca","Data":"Acci� de Consulta del Model de la Llista"},{ "Culture":"es","Data":"Acci�n de Consulta del Modelo de la Lista"},{ "Culture":"it","Data":"Elenca l''azione della query del modello"},{ "Culture":"pt","Data":"A��o de Query de Modelo da Lista"},{ "Culture":"en","Data":"List Model Query Action"}]}'
WHERE Id = '9e44b36e-ae29-425d-807b-c3824e59bf47'

GO
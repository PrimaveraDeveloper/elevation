UPDATE [CorePatterns].[SchemaAttributes] SET [Description] = '{"Values":[{ "Culture":"ca","Data":"Calendari"},{ "Culture":"es","Data":"Calendario"},{ "Culture":"it","Data":"Calendario"},{ "Culture":"pt","Data":"Calend�rio"},{ "Culture":"en","Data":"Calendar"}]}'
WHERE Id = 'e1367bce-59a8-4292-8044-db314ab113ac'

GO

UPDATE [CorePatterns].[SchemaAttributes] SET [Description] = '{"Values":[{ "Culture":"ca","Data":"Horari"},{ "Culture":"es","Data":"Horario"},{ "Culture":"it","Data":"Orario del tempo"},{ "Culture":"pt","Data":"Hor�rio"},{ "Culture":"en","Data":"Time Schedule"}]}'
WHERE Id = 'd8ab771d-c6ae-40a0-8a71-504341f3836e'

GO

UPDATE [CorePatterns].[SchemaAttributes] SET [Description] = '{"Values":[{ "Culture":"ca","Data":"Entitat"},{ "Culture":"es","Data":"Entidad"},{ "Culture":"it","Data":"Entit�"},{ "Culture":"pt","Data":"Entidade"},{ "Culture":"en","Data":"Entity"}]}'
WHERE Id = 'f5ce031f-fa96-4c2c-8d44-d71f621e9232'

GO

UPDATE [CorePatterns].[SchemaAttributes] SET [Description] = '{"Values":[{ "Culture":"ca","Data":"Seq��ncia"},{ "Culture":"es","Data":"Secuencia"},{ "Culture":"it","Data":"Sequenza"},{ "Culture":"pt","Data":"Sequ�ncia"},{ "Culture":"en","Data":"Sequence"}]}'
WHERE Id = '8ad32e65-0a68-40b8-a804-3ba4ffcfb3b2'

GO

UPDATE [CorePatterns].[SchemaAttributes] SET [Description] = '{"Values":[{ "Culture":"ca","Data":"Estat de l''Entitat"},{ "Culture":"es","Data":"Estado de la Entidad"},{ "Culture":"it","Data":"Stato dell''entit�"},{ "Culture":"pt","Data":"Estado da Entidade"},{ "Culture":"en","Data":"Entity State"}]}'
WHERE Id = '826bb1b8-95df-4fdb-a9ad-b99f05e7becd'

GO

UPDATE [CorePatterns].[SchemaAttributes] SET [Description] = '{"Values":[{ "Culture":"ca","Data":"Descripci�"},{ "Culture":"es","Data":"Descripci�n"},{ "Culture":"it","Data":"Descrizione"},{ "Culture":"pt","Data":"Descri��o"},{ "Culture":"en","Data":"Description"}]}'
WHERE Id = '50fcea91-6bce-4a62-a18c-246572be057e'

GO

UPDATE [CorePatterns].[SchemaAttributes] SET [Description] = '{"Values":[{ "Culture":"ca","Data":"Moneda"},{ "Culture":"es","Data":"Moneda"},{ "Culture":"it","Data":"Moneta"},{ "Culture":"pt","Data":"Moeda"},{ "Culture":"en","Data":"Currency"}]}'
WHERE Id = '61cc357b-587f-4a5b-8870-69d39d388228'

GO

UPDATE [CorePatterns].[SchemaAttributes] SET [Description] = '{"Values":[{ "Culture":"ca","Data":"Grup de Contactes"},{ "Culture":"es","Data":"Grupo de Contactos"},{ "Culture":"it","Data":"Contatta Group."},{ "Culture":"pt","Data":"Grupo de Contactos"},{ "Culture":"en","Data":"Contact Group"}]}'
WHERE Id = '7717e6d0-d51e-4adb-a935-2669b435ea24'

GO

UPDATE [CorePatterns].[SchemaAttributes] SET [Description] = '{"Values":[{ "Culture":"ca","Data":"Tasca"},{ "Culture":"es","Data":"Tarea"},{ "Culture":"it","Data":"Incarico"},{ "Culture":"pt","Data":"Tarefa"},{ "Culture":"en","Data":"Assignment"}]}'
WHERE Id = '7398d97d-1ba7-4d08-9fff-6fccaeb6bb13'

GO

UPDATE [CorePatterns].[SchemaAttributes] SET [Description] = '{"Values":[{ "Culture":"ca","Data":"Operaci� de Fons"},{ "Culture":"es","Data":"Operaci�n de Fondo"},{ "Culture":"it","Data":"Dolototoperazione"},{ "Culture":"pt","Data":"Opera��o de Fundo"},{ "Culture":"en","Data":"BackgroundOperation"}]}'
WHERE Id = 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b'

GO
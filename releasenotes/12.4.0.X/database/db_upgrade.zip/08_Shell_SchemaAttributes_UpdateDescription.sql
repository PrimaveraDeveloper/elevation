UPDATE [CorePatterns].[SchemaAttributes] SET [Description] = '{"Values":[{ "Culture":"ca","Data":"Definici� de la Vista de l''Entitat"},{ "Culture":"es","Data":"Definici�n de la Vista de la Entidad"},{ "Culture":"it","Data":"Definizione della vista dell''entit�"},{ "Culture":"pt","Data":"Defini��o da Vista da Entidade"},{ "Culture":"en","Data":"Entity View Definition"}]}'
WHERE Id = 'feee86c1-ec04-4ef3-b5f9-44aa17b938c6'

GO

UPDATE [CorePatterns].[SchemaAttributes] SET [Description] = '{"Values":[{ "Culture":"ca","Data":"Men�"},{ "Culture":"es","Data":"Men�"},{ "Culture":"it","Data":"Men�"},{ "Culture":"pt","Data":"Menu"},{ "Culture":"en","Data":"Menu"}]}'
WHERE Id = '0b39fcbe-a4ff-428a-b760-f867461b73f2'

GO
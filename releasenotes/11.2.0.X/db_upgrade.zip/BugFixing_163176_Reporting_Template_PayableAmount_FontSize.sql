UPDATE [Reporting].[Templates] SET [Model] = 
'{
  "settings": {
    "marginLeft": 220,
    "marginTop": 80,
    "marginBottom": 95,
    "marginRight": 100
  },
  "global": {
    "default": {
      "height": 50,
      "border": 0,
      "borders": "Bottom",
      "color": "#000000",
      "borderColor": "#E0E0E0",
      "fontFamily": "Calibri",
      "fontStyle": "Regular",
      "fontSize": 8,
      "textAlign": "Left",
      "label": {
        "fontStyle": "Bold",
        "textAlign": "Left",
        "borderColor": "#E0E0E0",
        "height": 50
      },
      "marginRight": 0,
      "marginLeft": 0
    },
    "text": {},
    "number": {},
    "decimal": {},
    "money": {},
    "percentage": {}
  },
  "pageHeader": {},
  "body": {
    "list": {
      "header": {
        "border": 1,
        "color": "#000000"
      },
      "number": {
        "textAlign": "Right",
        "label": {
          "textAlign": "Right"
        }
      },
      "decimal": {
        "textAlign": "Right",
        "label": {
          "textAlign": "Right"
        }
      },
      "money": {
        "textAlign": "Right",
        "label": {
          "textAlign": "Right"
        }
      },
      "percentage": {
        "textAlign": "Right",
        "label": {
          "textAlign": "Right"
        }
      },
      "line": {
        "border": 1,
        "borders": "Bottom",
        "borderColor": "#E0E0E0"
      },
      "default": {
        "marginRight": 10,
        "border": 0,
        "borders": "None",
        "borderColor": "#E0E0E0",
        "label": {
          "marginRight": 10,
          "border": 1,
          "borders": "Bottom",
          "borderColor": "#000000"
        }
      }
    }
  },
  "elements": {
    "footer1": {
      "border": 0,
      "borders": "None",
      "color": "#000000",
      "textValue": ""
    },
    "footer2": {
      "border": 0,
      "borders": "None",
      "color": "#000000",
      "textValue": ""
    },
    "companyInfo": {
      "border": 0,
      "color": "#000000",
      "positionX": 0,
      "positionY": 100
    },
    "documentInfo": {
      "marginRight": 50,
      "positionX": 0,
      "positionY": 590,
      "label": {
        "marginRight": 50,
        "border": 1,
        "borders": "Bottom",
        "color": "#000000"
      }
    },
    "loadingInfo": {
      "marginRight": 50,
      "label": {
        "marginRight": 50,
        "border": 1,
        "borders": "Bottom",
        "color": "#000000"
      }
    },
    "unloadingInfo": {
      "marginRight": 50,
      "label": {
        "marginRight": 50,
        "border": 1,
        "borders": "Bottom",
        "color": "#000000"
      }
    },
    "title": {
      "height": 50,
      "fontSize": 13,
      "fontStyle": "Bold",
      "textAlign": "Left",
      "border": 3,
      "borders": "Bottom",
      "borderColor": "#000000",
      "color": "#000000",
      "positionX": 0,
      "positionY": 530
    },
    "logo": {
      "backgroundImage": "",
      "useCompanyLogo": "true",
      "positionX": 0,
      "positionY": 0,
      "height": 100,
      "Width": 400
    },
    "copyLabel": {
      "fontStyle": "Bold",
      "textAlign": "Left",
      "positionX": 0,
      "positionY": 485
    },
    "broughtForward": {
      "fontStyle": "Bold",
      "color": "#000000",
      "textAlign": "Right"
    },
    "carryforward": {
      "fontStyle": "Bold",
      "color": "#000000",
      "textAlign": "Right"
    },
    "name": {
      "color": "#000000",
      "fontStyle": "Bold",
      "fontSize": 8,
      "textAlign": "Left"
    },
    "totalsPanel": {
      "textAlign": "Right",
      "border": 1,
      "borders": "Bottom",
      "label": {
        "textAlign": "Left",
        "border": 1,
        "borders": "Bottom"
      }
    },
    "payableAmount": {
      "height": 80,
      "fontSize": 12,
      "fontStyle": "Bold",
      "border": 3,
      "borders": "Top",
      "borderColor": "#000000",
      "label": {
        "height": 80,
        "fontSize": 12,
        "fontStyle": "Bold",
        "border": 3,
        "borders": "Top",
        "borderColor": "#000000"
      }
    },
    "wTaxTotal": {
      "height": 80,
      "border": 0,
      "label": {
        "height": 80,
        "border": 0
      }
    },
    "totalLiability": {
      "height": 40,
      "border": 0,
      "fontSize": 14,
      "fontFamily": "Calibri",
      "fontStyle": "Bold",
      "label": {
        "height": 40,
        "border": 0,
        "fontSize": 14,
        "fontStyle": "Bold"
      }
    },
    "defaultLine": {
      "defaultValue": "---------------------"
    },
    "H1": {
      "fontSize": 16,
      "fontStyle": "Bold"
    },
    "H2": {
      "height": 0,
      "marginLeft": 250
    },
    "H3": {
      "fontSize": 10
    },
    "documentReference": {
      "formatRegExp": "([^.]*).([^.]*).([^.]*)",
      "formatRegReplace": "$1 $2/$3"
    }
  },
  "reportHeader": {},
  "pageFooter": {},
  "reportFooter": {
    "list": {
      "header": {
        "border": 1,
        "color": "#000000"
      },
      "line": {
        "border": 1,
        "borders": "Bottom",
        "borderColor": "#E0E0E0"
      },
      "default": {
        "marginRight": 10,
        "border": 1,
        "borders": "None",
        "borderColor": "#E0E0E0",
        "label": {
          "marginRight": 10,
          "border": 1,
          "borders": "Bottom",
          "borderColor": "#000000"
        }
      },
      "number": {
        "textAlign": "Right",
        "label": {
          "textAlign": "Right"
        }
      },
      "decimal": {
        "textAlign": "Right",
        "label": {
          "textAlign": "Right"
        }
      },
      "money": {
        "textAlign": "Right",
        "label": {
          "textAlign": "Right"
        }
      },
      "percentage": {
        "textAlign": "Right",
        "label": {
          "textAlign": "Right"
        }
      }
    }
  }
}' 
WHERE [Id] = 'A860C204-DBD4-E511-BEFC-C01885A63E41'
           

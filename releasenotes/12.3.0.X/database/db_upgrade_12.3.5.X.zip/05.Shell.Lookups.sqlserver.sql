﻿-- Entity Lookups

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [Shell].[Shell.UserSettingsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [Shell].[Shell.UserSettingsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= 'e8191641-b317-42c4-b754-214d8d073673')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= 'e8191641-b317-42c4-b754-214d8d073673'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    'e8191641-b317-42c4-b754-214d8d073673'
    ,'Shell'
    ,'UserSettings'
    ,'UserSettingsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Definició d''Usuari"},{ "Culture":"es","Data":"Definición de Usuario"},{ "Culture":"it","Data":"Impostazione dell''utente."},{ "Culture":"pt","Data":"Definição de Utilizador"},{ "Culture":"en","Data":"User Setting"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Definició d''Usuari)"},{ "Culture":"es","Data":"(Definición de Usuario)"},{ "Culture":"it","Data":"(Impostazione dell''utente)"},{ "Culture":"pt","Data":"(Definição de Utilizador)"},{ "Culture":"en","Data":"(User Setting)"}]}'
    ,1
    ,'e8191641-b317-42c4-b754-214d8d073673'
    ,'e8191641-b317-42c4-b754-214d8d073673'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '2fe7f1f4-74fc-c5fc-c206-4f3cab87c3ad'
        ,'{"Values":[{ "Culture":"ca","Data":"Definició d''Usuari"},{ "Culture":"es","Data":"Definición de Usuario"},{ "Culture":"it","Data":"Impostazione dell''utente."},{ "Culture":"pt","Data":"Definição de Utilizador"},{ "Culture":"en","Data":"User Setting"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'e8191641-b317-42c4-b754-214d8d073673'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: UserSettingsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Shell' AND 
                    specific_name = 'UserSettingsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Shell].[UserSettingsQuery]
GO

CREATE FUNCTION  [Shell].[UserSettingsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [Shell].[UserSettingsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [Shell].[Shell.ProductsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [Shell].[Shell.ProductsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '70600f04-96ae-418c-bfc1-38d7c4cdc566')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '70600f04-96ae-418c-bfc1-38d7c4cdc566'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '70600f04-96ae-418c-bfc1-38d7c4cdc566'
    ,'Shell'
    ,'Products'
    ,'ProductsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Producte"},{ "Culture":"es","Data":"Producto"},{ "Culture":"it","Data":"Prodotto"},{ "Culture":"pt","Data":"Produto"},{ "Culture":"en","Data":"Product"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Producte)"},{ "Culture":"es","Data":"(Producto)"},{ "Culture":"it","Data":"(Prodotto)"},{ "Culture":"pt","Data":"(Produto)"},{ "Culture":"en","Data":"(Product)"}]}'
    ,1
    ,'70600f04-96ae-418c-bfc1-38d7c4cdc566'
    ,'70600f04-96ae-418c-bfc1-38d7c4cdc566'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '922a61fa-0399-303b-6a8b-38cb64f5ce36'
        ,'{"Values":[{ "Culture":"ca","Data":"Producte"},{ "Culture":"es","Data":"Producto"},{ "Culture":"it","Data":"Prodotto"},{ "Culture":"pt","Data":"Produto"},{ "Culture":"en","Data":"Product"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'70600f04-96ae-418c-bfc1-38d7c4cdc566'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: ProductsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Shell' AND 
                    specific_name = 'ProductsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Shell].[ProductsQuery]
GO

CREATE FUNCTION  [Shell].[ProductsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [Shell].[ProductsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [Shell].[Shell.EntityViewDefinitionsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [Shell].[Shell.EntityViewDefinitionsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= 'feee86c1-ec04-4ef3-b5f9-44aa17b938c6')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= 'feee86c1-ec04-4ef3-b5f9-44aa17b938c6'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    'feee86c1-ec04-4ef3-b5f9-44aa17b938c6'
    ,'Shell'
    ,'EntityViewDefinitions'
    ,'EntityViewDefinitionsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Definició de la Vista de l''Entitat"},{ "Culture":"es","Data":"Definición de la Vista de la Entidad"},{ "Culture":"it","Data":"Definizione della vista dell''entità"},{ "Culture":"pt","Data":"Definição da Vista da Entidade"},{ "Culture":"en","Data":"Entity View Definition"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Definició de la Vista de l''Entitat, Descripció)"},{ "Culture":"es","Data":"(Definición de la Vista de la Entidad, Descripción)"},{ "Culture":"it","Data":"(Definizione della vista dell''entità, descrizione)"},{ "Culture":"pt","Data":"(Definição da Vista da Entidade, Descrição)"},{ "Culture":"en","Data":"(Entity View Definition, Description)"}]}'
    ,1
    ,'feee86c1-ec04-4ef3-b5f9-44aa17b938c6'
    ,'feee86c1-ec04-4ef3-b5f9-44aa17b938c6'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'f93233a4-9d9f-7f30-8bc2-002c5ffaae36'
        ,'{"Values":[{ "Culture":"ca","Data":"Definició de la Vista de l''Entitat"},{ "Culture":"es","Data":"Definición de la Vista de la Entidad"},{ "Culture":"it","Data":"Definizione della vista dell''entità"},{ "Culture":"pt","Data":"Definição da Vista da Entidade"},{ "Culture":"en","Data":"Entity View Definition"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'feee86c1-ec04-4ef3-b5f9-44aa17b938c6'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: Description (Description) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'bd63b523-ef73-0be3-aa76-ac304e3a0db7'
        ,'{"Values":[{ "Culture":"ca","Data":"Descripció"},{ "Culture":"es","Data":"Descripción"},{ "Culture":"it","Data":"Descrizione"},{ "Culture":"pt","Data":"Descrição"},{ "Culture":"en","Data":"Description"}]}'
        ,'True'
        ,'False'
        ,1
        ,'Text'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'feee86c1-ec04-4ef3-b5f9-44aa17b938c6'
        ,0
        ,0
        ,1
        ,'Description'
        ,'Description'
        ,'True'
        )
GO

-- List Query TVF: EntityViewDefinitionsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Shell' AND 
                    specific_name = 'EntityViewDefinitionsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Shell].[EntityViewDefinitionsQuery]
GO

CREATE FUNCTION  [Shell].[EntityViewDefinitionsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey], [T1].[Description] AS [Description]
FROM [Shell].[EntityViewDefinitionsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[Description] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [Shell].[Shell.MenusLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [Shell].[Shell.MenusLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '0b39fcbe-a4ff-428a-b760-f867461b73f2')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '0b39fcbe-a4ff-428a-b760-f867461b73f2'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '0b39fcbe-a4ff-428a-b760-f867461b73f2'
    ,'Shell'
    ,'MenuDatas'
    ,'MenusLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Menú"},{ "Culture":"es","Data":"Menú"},{ "Culture":"it","Data":"Menù"},{ "Culture":"pt","Data":"Menu"},{ "Culture":"en","Data":"Menu"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Menú)"},{ "Culture":"es","Data":"(Menú)"},{ "Culture":"it","Data":"(Menù)"},{ "Culture":"pt","Data":"(Menu)"},{ "Culture":"en","Data":"(Menu)"}]}'
    ,1
    ,'0b39fcbe-a4ff-428a-b760-f867461b73f2'
    ,'0b39fcbe-a4ff-428a-b760-f867461b73f2'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '61c45823-38f2-b19a-6218-256b0cea3b3a'
        ,'{"Values":[{ "Culture":"ca","Data":"Menú"},{ "Culture":"es","Data":"Menú"},{ "Culture":"it","Data":"Menù"},{ "Culture":"pt","Data":"Menu"},{ "Culture":"en","Data":"Menu"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'0b39fcbe-a4ff-428a-b760-f867461b73f2'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: MenusQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Shell' AND 
                    specific_name = 'MenusQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Shell].[MenusQuery]
GO

CREATE FUNCTION  [Shell].[MenusQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [Shell].[MenusView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- List Query TVF: IdentityMenusQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Shell' AND 
                    specific_name = 'IdentityMenusQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Shell].[IdentityMenusQuery]
GO

CREATE FUNCTION  [Shell].[IdentityMenusQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [Shell].[IdentityMenusView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- List Query TVF: HelpPagesQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Shell' AND 
                    specific_name = 'HelpPagesQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Shell].[HelpPagesQuery]
GO

CREATE FUNCTION  [Shell].[HelpPagesQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [Shell].[HelpPagesView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [Shell].[Shell.MenuDataLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [Shell].[Shell.MenuDataLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '4dfb3403-f287-4e1b-8ecd-4ae0b9c3ee87')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '4dfb3403-f287-4e1b-8ecd-4ae0b9c3ee87'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '4dfb3403-f287-4e1b-8ecd-4ae0b9c3ee87'
    ,'Shell'
    ,'MenuDatas'
    ,'MenuDataLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Menú"},{ "Culture":"es","Data":"Menú"},{ "Culture":"it","Data":"Menù"},{ "Culture":"pt","Data":"Menu"},{ "Culture":"en","Data":"Menu"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Menú)"},{ "Culture":"es","Data":"(Menú)"},{ "Culture":"it","Data":"(Menù)"},{ "Culture":"pt","Data":"(Menu)"},{ "Culture":"en","Data":"(Menu)"}]}'
    ,1
    ,'0b39fcbe-a4ff-428a-b760-f867461b73f2'
    ,'4dfb3403-f287-4e1b-8ecd-4ae0b9c3ee87'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '06d48b55-9034-747e-59d3-9a78e8a6bba7'
        ,'{"Values":[{ "Culture":"ca","Data":"Menú"},{ "Culture":"es","Data":"Menú"},{ "Culture":"it","Data":"Menù"},{ "Culture":"pt","Data":"Menu"},{ "Culture":"en","Data":"Menu"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'4dfb3403-f287-4e1b-8ecd-4ae0b9c3ee87'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Shell' AND 
                    specific_name = 'MenuDataQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Shell].[MenuDataQuery]
GO

CREATE FUNCTION  [Shell].[MenuDataQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [Shell].[MenusView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO


-- Associations Lookups


	-- Association Lookup: MenuData_MenusForRootMenuQuery (MenuDatas | MenuData | Menu.RootMenu)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Shell' AND 
                    specific_name = 'MenuData_MenusForRootMenuQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Shell].[MenuData_MenusForRootMenuQuery]
GO

	CREATE FUNCTION  [Shell].[MenuData_MenusForRootMenuQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [Shell].MenusQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- Association Lookup: MenuData_MenusForMenuItemsChildMenuQuery (MenuDatas | MenuData | (MenuItems) MenuItem.ChildMenu)

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Shell' AND 
                    specific_name = 'MenuData_MenusForMenuItemsChildMenuQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Shell].[MenuData_MenusForMenuItemsChildMenuQuery]
GO

CREATE FUNCTION  [Shell].[MenuData_MenusForMenuItemsChildMenuQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [Shell].MenusQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO


-- Shell.Verify_MenuData_MenusForRootMenuQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'Shell' AND 
                    [SPECIFIC_NAME] = 'Verify_MenuData_MenusForRootMenuQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [Shell].[Verify_MenuData_MenusForRootMenuQuery]
GO

-- [Shell].Verify_MenuData_MenusForRootMenuQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'Shell' AND 
                    [DOMAIN_NAME] = 'Verify_MenuData_MenusForRootMenuQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [Shell].Verify_MenuData_MenusForRootMenuQuery_Parameters
GO

CREATE TYPE [Shell].Verify_MenuData_MenusForRootMenuQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- Shell.Verify_MenuData_MenusForRootMenuQuery

CREATE FUNCTION [Shell].[Verify_MenuData_MenusForRootMenuQuery] (
     @List AS [Shell].Verify_MenuData_MenusForRootMenuQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Shell].[MenuData_MenusForRootMenuQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- Shell.Verify_MenuData_MenusForMenuItemsChildMenuQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'Shell' AND 
                    [SPECIFIC_NAME] = 'Verify_MenuData_MenusForMenuItemsChildMenuQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [Shell].[Verify_MenuData_MenusForMenuItemsChildMenuQuery]
GO

-- [Shell].Verify_MenuData_MenusForMenuItemsChildMenuQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'Shell' AND 
                    [DOMAIN_NAME] = 'Verify_MenuData_MenusForMenuItemsChildMenuQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [Shell].Verify_MenuData_MenusForMenuItemsChildMenuQuery_Parameters
GO

CREATE TYPE [Shell].Verify_MenuData_MenusForMenuItemsChildMenuQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- Shell.Verify_MenuData_MenusForMenuItemsChildMenuQuery

CREATE FUNCTION [Shell].[Verify_MenuData_MenusForMenuItemsChildMenuQuery] (
     @List AS [Shell].Verify_MenuData_MenusForMenuItemsChildMenuQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Shell].[MenuData_MenusForMenuItemsChildMenuQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO



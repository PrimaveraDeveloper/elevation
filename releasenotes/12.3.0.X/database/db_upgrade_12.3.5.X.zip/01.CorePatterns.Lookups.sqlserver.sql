﻿-- Entity Lookups

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.OrganizationConfigurationsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.OrganizationConfigurationsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= 'af789096-edfc-4152-833d-bcad6dd6dafb')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= 'af789096-edfc-4152-833d-bcad6dd6dafb'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    'af789096-edfc-4152-833d-bcad6dd6dafb'
    ,'CorePatterns'
    ,'OrganizationConfigurations'
    ,'OrganizationConfigurationsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Configuració de l''Organització"},{ "Culture":"es","Data":"Configuración de la Organización"},{ "Culture":"it","Data":"Configurazione dell''organizzazione"},{ "Culture":"pt","Data":"Configuração da Organização"},{ "Culture":"en","Data":"Organization Configuration"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Configuració de l''Organització)"},{ "Culture":"es","Data":"(Configuración de la Organización)"},{ "Culture":"it","Data":"(Configurazione dell''organizzazione)"},{ "Culture":"pt","Data":"(Configuração da Organização)"},{ "Culture":"en","Data":"(Organization Configuration)"}]}'
    ,1
    ,'af789096-edfc-4152-833d-bcad6dd6dafb'
    ,'af789096-edfc-4152-833d-bcad6dd6dafb'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'dd4c77a9-5a3d-d33a-94ab-f4bdef994611'
        ,'{"Values":[{ "Culture":"ca","Data":"Configuració de l''Organització"},{ "Culture":"es","Data":"Configuración de la Organización"},{ "Culture":"it","Data":"Configurazione dell''organizzazione"},{ "Culture":"pt","Data":"Configuração da Organização"},{ "Culture":"en","Data":"Organization Configuration"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'af789096-edfc-4152-833d-bcad6dd6dafb'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: OrganizationConfigurationsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'OrganizationConfigurationsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[OrganizationConfigurationsQuery]
GO

CREATE FUNCTION  [CorePatterns].[OrganizationConfigurationsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [CorePatterns].[OrganizationConfigurationsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.CalendarsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.CalendarsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= 'e1367bce-59a8-4292-8044-db314ab113ac')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= 'e1367bce-59a8-4292-8044-db314ab113ac'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    'e1367bce-59a8-4292-8044-db314ab113ac'
    ,'CorePatterns'
    ,'Calendars'
    ,'CalendarsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Calendari"},{ "Culture":"es","Data":"Calendario"},{ "Culture":"it","Data":"Calendario"},{ "Culture":"pt","Data":"Calendário"},{ "Culture":"en","Data":"Calendar"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Calendari, Descripció)"},{ "Culture":"es","Data":"(Calendario, Descripción)"},{ "Culture":"it","Data":"(Calendario, descrizione)"},{ "Culture":"pt","Data":"(Calendário, Descrição)"},{ "Culture":"en","Data":"(Calendar, Description)"}]}'
    ,1
    ,'e1367bce-59a8-4292-8044-db314ab113ac'
    ,'e1367bce-59a8-4292-8044-db314ab113ac'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'f43b8dea-a4f9-a130-b352-750f33c5c117'
        ,'{"Values":[{ "Culture":"ca","Data":"Calendari"},{ "Culture":"es","Data":"Calendario"},{ "Culture":"it","Data":"Calendario"},{ "Culture":"pt","Data":"Calendário"},{ "Culture":"en","Data":"Calendar"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'e1367bce-59a8-4292-8044-db314ab113ac'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: Description (Description) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '1b1a3c2f-9668-9a58-5ab5-b86c583c1201'
        ,'{"Values":[{ "Culture":"ca","Data":"Descripció"},{ "Culture":"es","Data":"Descripción"},{ "Culture":"it","Data":"Descrizione"},{ "Culture":"pt","Data":"Descrição"},{ "Culture":"en","Data":"Description"}]}'
        ,'True'
        ,'False'
        ,1
        ,'Text'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'e1367bce-59a8-4292-8044-db314ab113ac'
        ,0
        ,0
        ,1
        ,'Description'
        ,'Description'
        ,'True'
        )
GO

-- List Query TVF: CalendarsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'CalendarsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[CalendarsQuery]
GO

CREATE FUNCTION  [CorePatterns].[CalendarsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey], [T1].[Description] AS [Description]
FROM [CorePatterns].[CalendarsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[Description] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.CalendarEventTypesLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.CalendarEventTypesLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '98e6bcda-f26c-4fe3-8038-ecdfb82fd5ca')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '98e6bcda-f26c-4fe3-8038-ecdfb82fd5ca'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '98e6bcda-f26c-4fe3-8038-ecdfb82fd5ca'
    ,'CorePatterns'
    ,'CalendarEventTypes'
    ,'CalendarEventTypesLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Tipus d''Esdeveniment del Calendari"},{ "Culture":"es","Data":"Tipo de Evento del Calendario"},{ "Culture":"it","Data":"Tipo di evento del calendario"},{ "Culture":"pt","Data":"Tipo de Evento de Calendário"},{ "Culture":"en","Data":"Calendar Event Type"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Tipus d''Esdeveniment de Calendari, Descripció)"},{ "Culture":"es","Data":"(Tipo de Evento de Calendario, Descripción)"},{ "Culture":"it","Data":"(Tipo di evento del calendario, Descrizione)"},{ "Culture":"pt","Data":"(Tipo de Evento de Calendário, Descrição)"},{ "Culture":"en","Data":"(Calendar Event Type, Description)"}]}'
    ,1
    ,'98e6bcda-f26c-4fe3-8038-ecdfb82fd5ca'
    ,'98e6bcda-f26c-4fe3-8038-ecdfb82fd5ca'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'a24cf6dd-6816-e320-091b-62f07fa7177a'
        ,'{"Values":[{ "Culture":"ca","Data":"Tipus d''Esdeveniment del Calendari"},{ "Culture":"es","Data":"Tipo de Evento del Calendario"},{ "Culture":"it","Data":"Tipo di evento del calendario"},{ "Culture":"pt","Data":"Tipo de Evento de Calendário"},{ "Culture":"en","Data":"Calendar Event Type"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'98e6bcda-f26c-4fe3-8038-ecdfb82fd5ca'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: Description (Description) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'be6b3966-185b-b735-6146-7cb71410d3f7'
        ,'{"Values":[{ "Culture":"ca","Data":"Descripció"},{ "Culture":"es","Data":"Descripción"},{ "Culture":"it","Data":"Descrizione"},{ "Culture":"pt","Data":"Descrição"},{ "Culture":"en","Data":"Description"}]}'
        ,'True'
        ,'False'
        ,1
        ,'Text'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'98e6bcda-f26c-4fe3-8038-ecdfb82fd5ca'
        ,0
        ,0
        ,1
        ,'Description'
        ,'Description'
        ,'True'
        )
GO

-- List Query TVF: CalendarEventTypesQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'CalendarEventTypesQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[CalendarEventTypesQuery]
GO

CREATE FUNCTION  [CorePatterns].[CalendarEventTypesQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey], [T1].[Description] AS [Description]
FROM [CorePatterns].[CalendarEventTypesView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[Description] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.TimeSchedulesLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.TimeSchedulesLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= 'd8ab771d-c6ae-40a0-8a71-504341f3836e')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= 'd8ab771d-c6ae-40a0-8a71-504341f3836e'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    'd8ab771d-c6ae-40a0-8a71-504341f3836e'
    ,'CorePatterns'
    ,'TimeSchedules'
    ,'TimeSchedulesLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Horari"},{ "Culture":"es","Data":"Horario"},{ "Culture":"it","Data":"Orario del tempo"},{ "Culture":"pt","Data":"Horário"},{ "Culture":"en","Data":"Time Schedule"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Horari, Descripció)"},{ "Culture":"es","Data":"(Horario, Descripción)"},{ "Culture":"it","Data":"(Orario del tempo, descrizione)"},{ "Culture":"pt","Data":"(Horário, Descrição)"},{ "Culture":"en","Data":"(Time Schedule, Description)"}]}'
    ,1
    ,'d8ab771d-c6ae-40a0-8a71-504341f3836e'
    ,'d8ab771d-c6ae-40a0-8a71-504341f3836e'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'f4e08892-9bef-d9a3-a9a4-cfb860bb5ddd'
        ,'{"Values":[{ "Culture":"ca","Data":"Horari"},{ "Culture":"es","Data":"Horario"},{ "Culture":"it","Data":"Orario del tempo"},{ "Culture":"pt","Data":"Horário"},{ "Culture":"en","Data":"Time Schedule"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'d8ab771d-c6ae-40a0-8a71-504341f3836e'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: Description (Description) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '8f73f3fa-1c2d-d657-8cd3-a5ff583f9f30'
        ,'{"Values":[{ "Culture":"ca","Data":"Descripció"},{ "Culture":"es","Data":"Descripción"},{ "Culture":"it","Data":"Descrizione"},{ "Culture":"pt","Data":"Descrição"},{ "Culture":"en","Data":"Description"}]}'
        ,'True'
        ,'False'
        ,1
        ,'Text'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'d8ab771d-c6ae-40a0-8a71-504341f3836e'
        ,0
        ,0
        ,1
        ,'Description'
        ,'Description'
        ,'True'
        )
GO

-- List Query TVF: TimeSchedulesQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'TimeSchedulesQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[TimeSchedulesQuery]
GO

CREATE FUNCTION  [CorePatterns].[TimeSchedulesQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey], [T1].[Description] AS [Description]
FROM [CorePatterns].[TimeSchedulesView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[Description] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.DocumentsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.DocumentsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '483b134c-a9b6-4454-b22b-706e2318a783')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '483b134c-a9b6-4454-b22b-706e2318a783'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '483b134c-a9b6-4454-b22b-706e2318a783'
    ,'CorePatterns'
    ,'Documents'
    ,'DocumentsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Càrrega d''Arxiu"},{ "Culture":"es","Data":"Carga de Archivo"},{ "Culture":"it","Data":"Upload di file"},{ "Culture":"pt","Data":"Carregamento de Ficheiro"},{ "Culture":"en","Data":"File Upload"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Càrrega d''Arxiu)"},{ "Culture":"es","Data":"(Carga de Archivo)"},{ "Culture":"it","Data":"(Upload di file)"},{ "Culture":"pt","Data":"(Carregamento de Ficheiro)"},{ "Culture":"en","Data":"(File Upload)"}]}'
    ,1
    ,'483b134c-a9b6-4454-b22b-706e2318a783'
    ,'483b134c-a9b6-4454-b22b-706e2318a783'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '98905551-da43-555d-86ac-17cace365dd3'
        ,'{"Values":[{ "Culture":"ca","Data":"Càrrega d''Arxiu"},{ "Culture":"es","Data":"Carga de Archivo"},{ "Culture":"it","Data":"Upload di file"},{ "Culture":"pt","Data":"Carregamento de Ficheiro"},{ "Culture":"en","Data":"File Upload"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'483b134c-a9b6-4454-b22b-706e2318a783'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: DocumentsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'DocumentsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[DocumentsQuery]
GO

CREATE FUNCTION  [CorePatterns].[DocumentsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [CorePatterns].[DocumentsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.DocumentChunksLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.DocumentChunksLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '4536df73-9979-4ffb-a746-a65f9fe29a39')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '4536df73-9979-4ffb-a746-a65f9fe29a39'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '4536df73-9979-4ffb-a746-a65f9fe29a39'
    ,'CorePatterns'
    ,'DocumentChunks'
    ,'DocumentChunksLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Fragment de Document"},{ "Culture":"es","Data":"Fragmento de Documento"},{ "Culture":"it","Data":"Documento Chunk."},{ "Culture":"pt","Data":"Fragmento de Documento"},{ "Culture":"en","Data":"Document Chunk"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Fragment de Document)"},{ "Culture":"es","Data":"(Fragmento de Documento)"},{ "Culture":"it","Data":"(Chunk del documento)"},{ "Culture":"pt","Data":"(Fragmento de Documento)"},{ "Culture":"en","Data":"(Document Chunk)"}]}'
    ,1
    ,'4536df73-9979-4ffb-a746-a65f9fe29a39'
    ,'4536df73-9979-4ffb-a746-a65f9fe29a39'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '02a1d8a0-e9ea-1fa4-8786-8c6f7b917847'
        ,'{"Values":[{ "Culture":"ca","Data":"Fragment de Document"},{ "Culture":"es","Data":"Fragmento de Documento"},{ "Culture":"it","Data":"Documento Chunk."},{ "Culture":"pt","Data":"Fragmento de Documento"},{ "Culture":"en","Data":"Document Chunk"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'4536df73-9979-4ffb-a746-a65f9fe29a39'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: DocumentChunksQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'DocumentChunksQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[DocumentChunksQuery]
GO

CREATE FUNCTION  [CorePatterns].[DocumentChunksQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [CorePatterns].[DocumentChunksView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.SchemaEntitiesLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.SchemaEntitiesLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= 'f5ce031f-fa96-4c2c-8d44-d71f621e9232')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= 'f5ce031f-fa96-4c2c-8d44-d71f621e9232'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    'f5ce031f-fa96-4c2c-8d44-d71f621e9232'
    ,'CorePatterns'
    ,'SchemaEntities'
    ,'SchemaEntitiesLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Entitat"},{ "Culture":"es","Data":"Entidad"},{ "Culture":"it","Data":"Entità"},{ "Culture":"pt","Data":"Entidade"},{ "Culture":"en","Data":"Entity"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Entitat)"},{ "Culture":"es","Data":"(Entidad)"},{ "Culture":"it","Data":"(Entità)"},{ "Culture":"pt","Data":"(Entidade)"},{ "Culture":"en","Data":"(Entity)"}]}'
    ,1
    ,'f5ce031f-fa96-4c2c-8d44-d71f621e9232'
    ,'f5ce031f-fa96-4c2c-8d44-d71f621e9232'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '58e7318f-3ac5-face-3ee4-c46da1e66f33'
        ,'{"Values":[{ "Culture":"ca","Data":"Entitat"},{ "Culture":"es","Data":"Entidad"},{ "Culture":"it","Data":"Entità"},{ "Culture":"pt","Data":"Entidade"},{ "Culture":"en","Data":"Entity"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'f5ce031f-fa96-4c2c-8d44-d71f621e9232'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: SchemaEntitiesQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'SchemaEntitiesQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[SchemaEntitiesQuery]
GO

CREATE FUNCTION  [CorePatterns].[SchemaEntitiesQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [CorePatterns].[SchemaEntitiesView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.SchemaAttributesLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.SchemaAttributesLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= 'e4a3809e-663d-4fbd-82ac-b5b25a95fc4b')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= 'e4a3809e-663d-4fbd-82ac-b5b25a95fc4b'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    'e4a3809e-663d-4fbd-82ac-b5b25a95fc4b'
    ,'CorePatterns'
    ,'SchemaAttributes'
    ,'SchemaAttributesLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Atribut de l''Entitat"},{ "Culture":"es","Data":"Atributo de la Entidad"},{ "Culture":"it","Data":"Attributo di entità"},{ "Culture":"pt","Data":"Atributo da Entidade"},{ "Culture":"en","Data":"Entity Attribute"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Atribut de l''Entitat, Clau)"},{ "Culture":"es","Data":"(Atributo de la Entidad, Clave)"},{ "Culture":"it","Data":"(Attributo entità, chiave)"},{ "Culture":"pt","Data":"(Atributo da Entidade, Chave)"},{ "Culture":"en","Data":"(Entity Attribute, Key)"}]}'
    ,1
    ,'e4a3809e-663d-4fbd-82ac-b5b25a95fc4b'
    ,'e4a3809e-663d-4fbd-82ac-b5b25a95fc4b'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'ea2c66b9-f9b7-f673-44a0-64f7cf441dc5'
        ,'{"Values":[{ "Culture":"ca","Data":"Atribut de l''Entitat"},{ "Culture":"es","Data":"Atributo de la Entidad"},{ "Culture":"it","Data":"Attributo di entità"},{ "Culture":"pt","Data":"Atributo da Entidade"},{ "Culture":"en","Data":"Entity Attribute"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'e4a3809e-663d-4fbd-82ac-b5b25a95fc4b'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: Key (Key) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '24a64b4e-a546-3bfa-d00a-42913bcadb42'
        ,'{"Values":[{ "Culture":"ca","Data":"Clau"},{ "Culture":"es","Data":"Clave"},{ "Culture":"it","Data":"Chiave"},{ "Culture":"pt","Data":"Chave"},{ "Culture":"en","Data":"Key"}]}'
        ,'True'
        ,'False'
        ,1
        ,'Text'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'e4a3809e-663d-4fbd-82ac-b5b25a95fc4b'
        ,0
        ,0
        ,1
        ,'Key'
        ,'Key'
        ,'True'
        )
GO

-- List Query TVF: SchemaAttributesQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'SchemaAttributesQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[SchemaAttributesQuery]
GO

CREATE FUNCTION  [CorePatterns].[SchemaAttributesQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey], [T1].[Key] AS [Key]
FROM [CorePatterns].[SchemaAttributesView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[Key] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.EntityLocksLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.EntityLocksLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '61a2a01b-8742-4c41-ad24-dda2fb61065a')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '61a2a01b-8742-4c41-ad24-dda2fb61065a'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '61a2a01b-8742-4c41-ad24-dda2fb61065a'
    ,'CorePatterns'
    ,'EntityLocks'
    ,'EntityLocksLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Bloqueig d''Entitat"},{ "Culture":"es","Data":"Bloqueo de Entidad"},{ "Culture":"it","Data":"Blocco dell''entità"},{ "Culture":"pt","Data":"Bloqueio de Entidade"},{ "Culture":"en","Data":"Entity Lock"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Bloqueig d''Entitat)"},{ "Culture":"es","Data":"(Bloqueo de Entidad)"},{ "Culture":"it","Data":"(Lock Entity)"},{ "Culture":"pt","Data":"(Bloqueio de Entidade)"},{ "Culture":"en","Data":"(Entity Lock)"}]}'
    ,1
    ,'61a2a01b-8742-4c41-ad24-dda2fb61065a'
    ,'61a2a01b-8742-4c41-ad24-dda2fb61065a'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '30d596a5-887d-17c2-96e5-0aa98e3a0116'
        ,'{"Values":[{ "Culture":"ca","Data":"Bloqueig d''Entitat"},{ "Culture":"es","Data":"Bloqueo de Entidad"},{ "Culture":"it","Data":"Blocco dell''entità"},{ "Culture":"pt","Data":"Bloqueio de Entidade"},{ "Culture":"en","Data":"Entity Lock"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'61a2a01b-8742-4c41-ad24-dda2fb61065a'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: EntityLocksQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'EntityLocksQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[EntityLocksQuery]
GO

CREATE FUNCTION  [CorePatterns].[EntityLocksQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [CorePatterns].[EntityLocksView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.CulturesLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.CulturesLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '90f42d07-ff9c-4b7b-bf70-d0b8982662ab')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '90f42d07-ff9c-4b7b-bf70-d0b8982662ab'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '90f42d07-ff9c-4b7b-bf70-d0b8982662ab'
    ,'CorePatterns'
    ,'Cultures'
    ,'CulturesLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Cultura"},{ "Culture":"es","Data":"Cultura"},{ "Culture":"it","Data":"Cultura"},{ "Culture":"pt","Data":"Cultura"},{ "Culture":"en","Data":"Culture"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Cultura, Nom)"},{ "Culture":"es","Data":"(Cultura, Nombre)"},{ "Culture":"it","Data":"(Cultura, nome)"},{ "Culture":"pt","Data":"(Cultura, Nome)"},{ "Culture":"en","Data":"(Culture, Name)"}]}'
    ,1
    ,'90f42d07-ff9c-4b7b-bf70-d0b8982662ab'
    ,'90f42d07-ff9c-4b7b-bf70-d0b8982662ab'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '70be3a43-4862-087c-1280-a5f3c91c7437'
        ,'{"Values":[{ "Culture":"ca","Data":"Cultura"},{ "Culture":"es","Data":"Cultura"},{ "Culture":"it","Data":"Cultura"},{ "Culture":"pt","Data":"Cultura"},{ "Culture":"en","Data":"Culture"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'90f42d07-ff9c-4b7b-bf70-d0b8982662ab'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: Name (Name) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '35760375-d210-90b3-11b9-211117216bc2'
        ,'{"Values":[{ "Culture":"ca","Data":"Nom"},{ "Culture":"es","Data":"Nombre"},{ "Culture":"it","Data":"Nome"},{ "Culture":"pt","Data":"Nome"},{ "Culture":"en","Data":"Name"}]}'
        ,'True'
        ,'False'
        ,1
        ,'Text'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'90f42d07-ff9c-4b7b-bf70-d0b8982662ab'
        ,0
        ,0
        ,1
        ,'Name'
        ,'Name'
        ,'True'
        )
GO

-- List Query TVF: CulturesQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'CulturesQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[CulturesQuery]
GO

CREATE FUNCTION  [CorePatterns].[CulturesQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey], [T1].[Name] AS [Name]
FROM [CorePatterns].[CulturesView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[Name] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.PropertyMapsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.PropertyMapsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '2c78c6ab-7f7f-4492-a68b-9e666826f98f')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '2c78c6ab-7f7f-4492-a68b-9e666826f98f'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '2c78c6ab-7f7f-4492-a68b-9e666826f98f'
    ,'CorePatterns'
    ,'PropertyMaps'
    ,'PropertyMapsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Informe de Propietats"},{ "Culture":"es","Data":"Informe de Propiedades"},{ "Culture":"it","Data":"Mappa della proprietà"},{ "Culture":"pt","Data":"Mapa das Propriedades"},{ "Culture":"en","Data":"Property Map"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Informe de Propietats)"},{ "Culture":"es","Data":"(Informe de Propiedades)"},{ "Culture":"it","Data":"(Mappa della proprietà)"},{ "Culture":"pt","Data":"(Mapa das Propriedades)"},{ "Culture":"en","Data":"(Property Map)"}]}'
    ,1
    ,'2c78c6ab-7f7f-4492-a68b-9e666826f98f'
    ,'2c78c6ab-7f7f-4492-a68b-9e666826f98f'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'd37510be-1927-e0cf-4a7f-d8898e05f0cc'
        ,'{"Values":[{ "Culture":"ca","Data":"Informe de Propietats"},{ "Culture":"es","Data":"Informe de Propiedades"},{ "Culture":"it","Data":"Mappa della proprietà"},{ "Culture":"pt","Data":"Mapa das Propriedades"},{ "Culture":"en","Data":"Property Map"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'2c78c6ab-7f7f-4492-a68b-9e666826f98f'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: PropertyMapsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'PropertyMapsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[PropertyMapsQuery]
GO

CREATE FUNCTION  [CorePatterns].[PropertyMapsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [CorePatterns].[PropertyMapsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.DocumentCopyLabelsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.DocumentCopyLabelsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '4799e95e-9ab7-4014-a2d3-7d1c172cbdbc')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '4799e95e-9ab7-4014-a2d3-7d1c172cbdbc'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '4799e95e-9ab7-4014-a2d3-7d1c172cbdbc'
    ,'CorePatterns'
    ,'DocumentCopyLabels'
    ,'DocumentCopyLabelsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Identificador de la Còpia del Document"},{ "Culture":"es","Data":"Identificador de la Copia del Documento"},{ "Culture":"it","Data":"Etichetta della copia del documento."},{ "Culture":"pt","Data":"Identificador da Cópia do Documento"},{ "Culture":"en","Data":"Document Copy Label"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Identificador de la Còpia del Document)"},{ "Culture":"es","Data":"(Identificador de la Copia del Documento)"},{ "Culture":"it","Data":"(Etichetta copia documento)"},{ "Culture":"pt","Data":"(Identificador da Cópia do Documento)"},{ "Culture":"en","Data":"(Document Copy Label)"}]}'
    ,1
    ,'4799e95e-9ab7-4014-a2d3-7d1c172cbdbc'
    ,'4799e95e-9ab7-4014-a2d3-7d1c172cbdbc'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '5e5d78c3-bcea-cb5e-9552-80d15cd4c9d7'
        ,'{"Values":[{ "Culture":"ca","Data":"Identificador de la Còpia del Document"},{ "Culture":"es","Data":"Identificador de la Copia del Documento"},{ "Culture":"it","Data":"Etichetta della copia del documento."},{ "Culture":"pt","Data":"Identificador da Cópia do Documento"},{ "Culture":"en","Data":"Document Copy Label"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'4799e95e-9ab7-4014-a2d3-7d1c172cbdbc'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: DocumentCopyLabelsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'DocumentCopyLabelsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[DocumentCopyLabelsQuery]
GO

CREATE FUNCTION  [CorePatterns].[DocumentCopyLabelsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [CorePatterns].[DocumentCopyLabelsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.ObjectChangeSetsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.ObjectChangeSetsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '4d26592c-90e2-413d-8269-b7d39c20c190')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '4d26592c-90e2-413d-8269-b7d39c20c190'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '4d26592c-90e2-413d-8269-b7d39c20c190'
    ,'CorePatterns'
    ,'ObjectChangeSets'
    ,'ObjectChangeSetsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Conjunt de Canvis de l''Objecte"},{ "Culture":"es","Data":"Conjunto de Cambios del Objeto"},{ "Culture":"it","Data":"Cambio oggetto Set."},{ "Culture":"pt","Data":"Conjunto de Alterações do Objeto"},{ "Culture":"en","Data":"Object Change Set"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Conjunt de Canvis de l''Objecte)"},{ "Culture":"es","Data":"(Conjunto de Cambios del Objeto)"},{ "Culture":"it","Data":"(Set di modifica dell''oggetto)"},{ "Culture":"pt","Data":"(Conjunto de Alterações do Objeto)"},{ "Culture":"en","Data":"(Object Change Set)"}]}'
    ,1
    ,'4d26592c-90e2-413d-8269-b7d39c20c190'
    ,'4d26592c-90e2-413d-8269-b7d39c20c190'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '9adea8c2-bb22-743b-c6a3-ebae16cf27d4'
        ,'{"Values":[{ "Culture":"ca","Data":"Conjunt de Canvis de l''Objecte"},{ "Culture":"es","Data":"Conjunto de Cambios del Objeto"},{ "Culture":"it","Data":"Cambio oggetto Set."},{ "Culture":"pt","Data":"Conjunto de Alterações do Objeto"},{ "Culture":"en","Data":"Object Change Set"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'4d26592c-90e2-413d-8269-b7d39c20c190'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: ObjectChangeSetsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'ObjectChangeSetsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[ObjectChangeSetsQuery]
GO

CREATE FUNCTION  [CorePatterns].[ObjectChangeSetsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [CorePatterns].[ObjectChangeSetsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.SequencesLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.SequencesLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '8ad32e65-0a68-40b8-a804-3ba4ffcfb3b2')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '8ad32e65-0a68-40b8-a804-3ba4ffcfb3b2'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '8ad32e65-0a68-40b8-a804-3ba4ffcfb3b2'
    ,'CorePatterns'
    ,'Sequences'
    ,'SequencesLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Seqüència"},{ "Culture":"es","Data":"Secuencia"},{ "Culture":"it","Data":"Sequenza"},{ "Culture":"pt","Data":"Sequência"},{ "Culture":"en","Data":"Sequence"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Seqüència, Descripció)"},{ "Culture":"es","Data":"(Secuencia, Descripción)"},{ "Culture":"it","Data":"(Sequenza, descrizione)"},{ "Culture":"pt","Data":"(Sequência, Descrição)"},{ "Culture":"en","Data":"(Sequence, Description)"}]}'
    ,1
    ,'8ad32e65-0a68-40b8-a804-3ba4ffcfb3b2'
    ,'8ad32e65-0a68-40b8-a804-3ba4ffcfb3b2'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'c4a7f8ad-d290-1ce2-2c94-1afd883ed732'
        ,'{"Values":[{ "Culture":"ca","Data":"Seqüència"},{ "Culture":"es","Data":"Secuencia"},{ "Culture":"it","Data":"Sequenza"},{ "Culture":"pt","Data":"Sequência"},{ "Culture":"en","Data":"Sequence"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'8ad32e65-0a68-40b8-a804-3ba4ffcfb3b2'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: Description (Description) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'b2fe0e02-5e0c-5c8b-19b5-ef7713741f8f'
        ,'{"Values":[{ "Culture":"ca","Data":"Descripció"},{ "Culture":"es","Data":"Descripción"},{ "Culture":"it","Data":"Descrizione"},{ "Culture":"pt","Data":"Descrição"},{ "Culture":"en","Data":"Description"}]}'
        ,'True'
        ,'False'
        ,1
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'8ad32e65-0a68-40b8-a804-3ba4ffcfb3b2'
        ,0
        ,0
        ,1
        ,'Description'
        ,'Description'
        ,'True'
        )
GO

-- List Query TVF: SequencesQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'SequencesQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[SequencesQuery]
GO

CREATE FUNCTION  [CorePatterns].[SequencesQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey], [T1].[Description] AS [Description]
FROM [CorePatterns].[SequencesView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[Description] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.SchemaEntityStatesLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.SchemaEntityStatesLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '826bb1b8-95df-4fdb-a9ad-b99f05e7becd')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '826bb1b8-95df-4fdb-a9ad-b99f05e7becd'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '826bb1b8-95df-4fdb-a9ad-b99f05e7becd'
    ,'CorePatterns'
    ,'SchemaEntityStates'
    ,'SchemaEntityStatesLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Estat de l''Entitat"},{ "Culture":"es","Data":"Estado de la Entidad"},{ "Culture":"it","Data":"Stato dell''entità"},{ "Culture":"pt","Data":"Estado da Entidade"},{ "Culture":"en","Data":"Entity State"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Estat de l''Entitat)"},{ "Culture":"es","Data":"(Estado de la Entidad)"},{ "Culture":"it","Data":"(Stato di entità)"},{ "Culture":"pt","Data":"(Estado da Entidade)"},{ "Culture":"en","Data":"(Entity State)"}]}'
    ,1
    ,'826bb1b8-95df-4fdb-a9ad-b99f05e7becd'
    ,'826bb1b8-95df-4fdb-a9ad-b99f05e7becd'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '34a33384-4865-727c-f79b-53b0f97f6388'
        ,'{"Values":[{ "Culture":"ca","Data":"Estat de l''Entitat"},{ "Culture":"es","Data":"Estado de la Entidad"},{ "Culture":"it","Data":"Stato dell''entità"},{ "Culture":"pt","Data":"Estado da Entidade"},{ "Culture":"en","Data":"Entity State"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'826bb1b8-95df-4fdb-a9ad-b99f05e7becd'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: SchemaEntityStatesQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'SchemaEntityStatesQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[SchemaEntityStatesQuery]
GO

CREATE FUNCTION  [CorePatterns].[SchemaEntityStatesQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [CorePatterns].[SchemaEntityStatesView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.SchemaEntityExtensionsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.SchemaEntityExtensionsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= 'fca3ad8a-68ca-4c6d-b04f-41f915963456')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= 'fca3ad8a-68ca-4c6d-b04f-41f915963456'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    'fca3ad8a-68ca-4c6d-b04f-41f915963456'
    ,'CorePatterns'
    ,'SchemaEntityExtensions'
    ,'SchemaEntityExtensionsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Extensió d''Entitat d''Esquema"},{ "Culture":"es","Data":"Extensión de Schema Entity"},{ "Culture":"it","Data":"Estensione dell''entità dello schema"},{ "Culture":"pt","Data":"Extensão do Schema Entity"},{ "Culture":"en","Data":"Schema Entity Extension"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Extensió d''Entitat d''Esquema)"},{ "Culture":"es","Data":"(Extensión de Schema Entity)"},{ "Culture":"it","Data":"(Estensione dell''entità dello schema)"},{ "Culture":"pt","Data":"(Extensão do Schema Entity)"},{ "Culture":"en","Data":"(Schema Entity Extension)"}]}'
    ,1
    ,'fca3ad8a-68ca-4c6d-b04f-41f915963456'
    ,'fca3ad8a-68ca-4c6d-b04f-41f915963456'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '6a5f8725-0a2b-b16a-a479-604c0147e464'
        ,'{"Values":[{ "Culture":"ca","Data":"Extensió d''Entitat d''Esquema"},{ "Culture":"es","Data":"Extensión de Schema Entity"},{ "Culture":"it","Data":"Estensione dell''entità dello schema"},{ "Culture":"pt","Data":"Extensão do Schema Entity"},{ "Culture":"en","Data":"Schema Entity Extension"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'fca3ad8a-68ca-4c6d-b04f-41f915963456'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: SchemaEntityExtensionsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'SchemaEntityExtensionsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[SchemaEntityExtensionsQuery]
GO

CREATE FUNCTION  [CorePatterns].[SchemaEntityExtensionsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [CorePatterns].[SchemaEntityExtensionsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.EntityStateTransitionHistoriesLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.EntityStateTransitionHistoriesLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '3d878e34-4b75-4d7e-af18-5ebfa9bca807')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '3d878e34-4b75-4d7e-af18-5ebfa9bca807'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '3d878e34-4b75-4d7e-af18-5ebfa9bca807'
    ,'CorePatterns'
    ,'EntityStateTransitionHistories'
    ,'EntityStateTransitionHistoriesLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Històric de la Transició de l''Estat"},{ "Culture":"es","Data":"Historial de la Transición del Estado"},{ "Culture":"it","Data":"Storia dello stato di transizione"},{ "Culture":"pt","Data":"Histórico da Transição do Estado"},{ "Culture":"en","Data":"State Transition History"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Històric de la Transició de l''Estat)"},{ "Culture":"es","Data":"(Historial de la Transición del Estado)"},{ "Culture":"it","Data":"(Storia dello stato di transizione)"},{ "Culture":"pt","Data":"(Histórico da Transição do Estado)"},{ "Culture":"en","Data":"(State Transition History)"}]}'
    ,1
    ,'3d878e34-4b75-4d7e-af18-5ebfa9bca807'
    ,'3d878e34-4b75-4d7e-af18-5ebfa9bca807'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'f29a845c-c5b5-8408-badb-c1962ae3af10'
        ,'{"Values":[{ "Culture":"ca","Data":"Històric de la Transició de l''Estat"},{ "Culture":"es","Data":"Historial de la Transición del Estado"},{ "Culture":"it","Data":"Storia dello stato di transizione"},{ "Culture":"pt","Data":"Histórico da Transição do Estado"},{ "Culture":"en","Data":"State Transition History"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'3d878e34-4b75-4d7e-af18-5ebfa9bca807'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: EntityStateTransitionHistoriesQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'EntityStateTransitionHistoriesQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[EntityStateTransitionHistoriesQuery]
GO

CREATE FUNCTION  [CorePatterns].[EntityStateTransitionHistoriesQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [CorePatterns].[EntityStateTransitionHistoriesView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.DraftsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.DraftsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '53df104a-4746-4f4f-ba26-c1b69c217675')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '53df104a-4746-4f4f-ba26-c1b69c217675'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '53df104a-4746-4f4f-ba26-c1b69c217675'
    ,'CorePatterns'
    ,'Drafts'
    ,'DraftsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Esborrany"},{ "Culture":"es","Data":"Borrador"},{ "Culture":"it","Data":"Brutta copia"},{ "Culture":"pt","Data":"Rascunho"},{ "Culture":"en","Data":"Draft"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Esborrany)"},{ "Culture":"es","Data":"(Borrador)"},{ "Culture":"it","Data":"(Brutta copia)"},{ "Culture":"pt","Data":"(Rascunho)"},{ "Culture":"en","Data":"(Draft)"}]}'
    ,1
    ,'53df104a-4746-4f4f-ba26-c1b69c217675'
    ,'53df104a-4746-4f4f-ba26-c1b69c217675'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '348a7fff-cc8a-69b2-4801-462522f71884'
        ,'{"Values":[{ "Culture":"ca","Data":"Esborrany"},{ "Culture":"es","Data":"Borrador"},{ "Culture":"it","Data":"Brutta copia"},{ "Culture":"pt","Data":"Rascunho"},{ "Culture":"en","Data":"Draft"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'53df104a-4746-4f4f-ba26-c1b69c217675'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: DraftsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'DraftsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[DraftsQuery]
GO

CREATE FUNCTION  [CorePatterns].[DraftsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [CorePatterns].[DraftsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.RulesLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.RulesLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '5ba0f088-0f70-407e-9def-c4cfe3a89793')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '5ba0f088-0f70-407e-9def-c4cfe3a89793'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '5ba0f088-0f70-407e-9def-c4cfe3a89793'
    ,'CorePatterns'
    ,'Rules'
    ,'RulesLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Regla"},{ "Culture":"es","Data":"Regla"},{ "Culture":"it","Data":"Regola"},{ "Culture":"pt","Data":"Regra"},{ "Culture":"en","Data":"Rule"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Regla)"},{ "Culture":"es","Data":"(Regla)"},{ "Culture":"it","Data":"(Regola)"},{ "Culture":"pt","Data":"(Regra)"},{ "Culture":"en","Data":"(Rule)"}]}'
    ,1
    ,'5ba0f088-0f70-407e-9def-c4cfe3a89793'
    ,'5ba0f088-0f70-407e-9def-c4cfe3a89793'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'ed2b06a3-debc-b1b1-0a88-4e5aca157cca'
        ,'{"Values":[{ "Culture":"ca","Data":"Regla"},{ "Culture":"es","Data":"Regla"},{ "Culture":"it","Data":"Regola"},{ "Culture":"pt","Data":"Regra"},{ "Culture":"en","Data":"Rule"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'5ba0f088-0f70-407e-9def-c4cfe3a89793'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: RulesQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'RulesQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[RulesQuery]
GO

CREATE FUNCTION  [CorePatterns].[RulesQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [CorePatterns].[RulesView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.OperationsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.OperationsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= 'c65e050a-0746-4154-927a-9d28e1620537')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= 'c65e050a-0746-4154-927a-9d28e1620537'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    'c65e050a-0746-4154-927a-9d28e1620537'
    ,'CorePatterns'
    ,'Operations'
    ,'OperationsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Operació"},{ "Culture":"es","Data":"Operación"},{ "Culture":"it","Data":"Operazione"},{ "Culture":"pt","Data":"Operação"},{ "Culture":"en","Data":"Operation"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Operació)"},{ "Culture":"es","Data":"(Operación)"},{ "Culture":"it","Data":"(Funzionamento)"},{ "Culture":"pt","Data":"(Operação)"},{ "Culture":"en","Data":"(Operation)"}]}'
    ,1
    ,'c65e050a-0746-4154-927a-9d28e1620537'
    ,'c65e050a-0746-4154-927a-9d28e1620537'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '74d3f16e-eea2-0965-cf1d-9432747d9a40'
        ,'{"Values":[{ "Culture":"ca","Data":"Operació"},{ "Culture":"es","Data":"Operación"},{ "Culture":"it","Data":"Operazione"},{ "Culture":"pt","Data":"Operação"},{ "Culture":"en","Data":"Operation"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'c65e050a-0746-4154-927a-9d28e1620537'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: OperationsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'OperationsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[OperationsQuery]
GO

CREATE FUNCTION  [CorePatterns].[OperationsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [CorePatterns].[OperationsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- List Query TVF: ProcessesQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'ProcessesQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[ProcessesQuery]
GO

CREATE FUNCTION  [CorePatterns].[ProcessesQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [CorePatterns].[ProcessesView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.CurrenciesLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.CurrenciesLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '61cc357b-587f-4a5b-8870-69d39d388228')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '61cc357b-587f-4a5b-8870-69d39d388228'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '61cc357b-587f-4a5b-8870-69d39d388228'
    ,'CorePatterns'
    ,'Currencies'
    ,'CurrenciesLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Moneda"},{ "Culture":"es","Data":"Moneda"},{ "Culture":"it","Data":"Moneta"},{ "Culture":"pt","Data":"Moeda"},{ "Culture":"en","Data":"Currency"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Moneda, Descripció)"},{ "Culture":"es","Data":"(Moneda, Descripción)"},{ "Culture":"it","Data":"(Valuta, Descrizione)"},{ "Culture":"pt","Data":"(Moeda, Descrição)"},{ "Culture":"en","Data":"(Currency, Description)"}]}'
    ,1
    ,'61cc357b-587f-4a5b-8870-69d39d388228'
    ,'61cc357b-587f-4a5b-8870-69d39d388228'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '37b9f818-fd7b-d2b9-578d-7720f925101a'
        ,'{"Values":[{ "Culture":"ca","Data":"Moneda"},{ "Culture":"es","Data":"Moneda"},{ "Culture":"it","Data":"Moneta"},{ "Culture":"pt","Data":"Moeda"},{ "Culture":"en","Data":"Currency"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'61cc357b-587f-4a5b-8870-69d39d388228'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: Description (Description) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '9bd4aa3c-c99f-3c16-14ff-f72fb235328b'
        ,'{"Values":[{ "Culture":"ca","Data":"Descripció"},{ "Culture":"es","Data":"Descripción"},{ "Culture":"it","Data":"Descrizione"},{ "Culture":"pt","Data":"Descrição"},{ "Culture":"en","Data":"Description"}]}'
        ,'True'
        ,'False'
        ,1
        ,'Text'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'61cc357b-587f-4a5b-8870-69d39d388228'
        ,0
        ,0
        ,1
        ,'Description'
        ,'Description'
        ,'True'
        )
GO


-- Column: CurrencyUnit (CurrencyUnit) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '91b4badf-5191-e526-97f0-d948cada8c2e'
        ,'{"Values":[{ "Culture":"ca","Data":"Unitat de la Moneda"},{ "Culture":"es","Data":"Unidad de la Moneda"},{ "Culture":"it","Data":"Unità di valuta"},{ "Culture":"pt","Data":"Unidade da Moeda"},{ "Culture":"en","Data":"Currency Unit"}]}'
        ,'True'
        ,'False'
        ,2
        ,'ShortText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'61cc357b-587f-4a5b-8870-69d39d388228'
        ,0
        ,0
        ,1
        ,'CurrencyUnit'
        ,'CurrencyUnit'
        ,'True'
        )
GO


-- Column: Symbol (Symbol) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'b985b542-7488-58ed-73a4-69d8ea92e9d9'
        ,'{"Values":[{ "Culture":"ca","Data":"Símbol"},{ "Culture":"es","Data":"Símbolo"},{ "Culture":"it","Data":"Simbolo"},{ "Culture":"pt","Data":"Símbolo"},{ "Culture":"en","Data":"Symbol"}]}'
        ,'True'
        ,'False'
        ,3
        ,'ShortText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'61cc357b-587f-4a5b-8870-69d39d388228'
        ,0
        ,0
        ,1
        ,'Symbol'
        ,'Symbol'
        ,'True'
        )
GO

-- List Query TVF: CurrenciesQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'CurrenciesQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[CurrenciesQuery]
GO

CREATE FUNCTION  [CorePatterns].[CurrenciesQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey], [T1].[Description] AS [Description], [T1].[CurrencyUnit] AS [CurrencyUnit], [T1].[Symbol] AS [Symbol]
FROM [CorePatterns].[CurrenciesView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[Description] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI))
AND (ISNULL([T1].[ValidFrom], '0001/01/01') < GETDATE()
AND ISNULL([T1].[ValidTo], '9999/12/31') > GETDATE()))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.CountriesLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.CountriesLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= 'e6f96018-ce8e-48d1-a6b3-c0ffd16da3f3')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= 'e6f96018-ce8e-48d1-a6b3-c0ffd16da3f3'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    'e6f96018-ce8e-48d1-a6b3-c0ffd16da3f3'
    ,'CorePatterns'
    ,'Countries'
    ,'CountriesLookup'
	,'{"Values":[{ "Culture":"ca","Data":"País"},{ "Culture":"es","Data":"País"},{ "Culture":"it","Data":"Nazione"},{ "Culture":"pt","Data":"País"},{ "Culture":"en","Data":"Country"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(País, Nom)"},{ "Culture":"es","Data":"(País, Nombre)"},{ "Culture":"it","Data":"(Nome del paese)"},{ "Culture":"pt","Data":"(País, Nome)"},{ "Culture":"en","Data":"(Country, Name)"}]}'
    ,1
    ,'e6f96018-ce8e-48d1-a6b3-c0ffd16da3f3'
    ,'e6f96018-ce8e-48d1-a6b3-c0ffd16da3f3'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '9b927af2-5020-3083-edcb-448881755450'
        ,'{"Values":[{ "Culture":"ca","Data":"País"},{ "Culture":"es","Data":"País"},{ "Culture":"it","Data":"Nazione"},{ "Culture":"pt","Data":"País"},{ "Culture":"en","Data":"Country"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'e6f96018-ce8e-48d1-a6b3-c0ffd16da3f3'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: Name (Name) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'd334fbe1-f37d-f635-6c07-e3ee9543433b'
        ,'{"Values":[{ "Culture":"ca","Data":"Nom"},{ "Culture":"es","Data":"Nombre"},{ "Culture":"it","Data":"Nome"},{ "Culture":"pt","Data":"Nome"},{ "Culture":"en","Data":"Name"}]}'
        ,'True'
        ,'False'
        ,1
        ,'Text'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'e6f96018-ce8e-48d1-a6b3-c0ffd16da3f3'
        ,0
        ,0
        ,1
        ,'Name'
        ,'Name'
        ,'True'
        )
GO

-- List Query TVF: CountriesQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'CountriesQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[CountriesQuery]
GO

CREATE FUNCTION  [CorePatterns].[CountriesQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey], [T1].[Name] AS [Name]
FROM [CorePatterns].[CountriesView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[Name] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.RegionsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.RegionsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= 'e78da86f-1fc3-4bc5-bfbd-5a060c2dc449')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= 'e78da86f-1fc3-4bc5-bfbd-5a060c2dc449'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    'e78da86f-1fc3-4bc5-bfbd-5a060c2dc449'
    ,'CorePatterns'
    ,'Regions'
    ,'RegionsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Regió"},{ "Culture":"es","Data":"Región"},{ "Culture":"it","Data":"Regione"},{ "Culture":"pt","Data":"Região"},{ "Culture":"en","Data":"Region"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Regió, Nom)"},{ "Culture":"es","Data":"(Región, Nombre)"},{ "Culture":"it","Data":"(Regione, nome)"},{ "Culture":"pt","Data":"(Região, Nome)"},{ "Culture":"en","Data":"(Region, Name)"}]}'
    ,1
    ,'e78da86f-1fc3-4bc5-bfbd-5a060c2dc449'
    ,'e78da86f-1fc3-4bc5-bfbd-5a060c2dc449'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'faa310bb-abce-41da-1752-63669da28e93'
        ,'{"Values":[{ "Culture":"ca","Data":"Regió"},{ "Culture":"es","Data":"Región"},{ "Culture":"it","Data":"Regione"},{ "Culture":"pt","Data":"Região"},{ "Culture":"en","Data":"Region"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'e78da86f-1fc3-4bc5-bfbd-5a060c2dc449'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: Name (Name) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '5a0afa26-3821-b01e-6677-9261d292df16'
        ,'{"Values":[{ "Culture":"ca","Data":"Nom"},{ "Culture":"es","Data":"Nombre"},{ "Culture":"it","Data":"Nome"},{ "Culture":"pt","Data":"Nome"},{ "Culture":"en","Data":"Name"}]}'
        ,'True'
        ,'False'
        ,1
        ,'Text'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'e78da86f-1fc3-4bc5-bfbd-5a060c2dc449'
        ,0
        ,0
        ,1
        ,'Name'
        ,'Name'
        ,'True'
        )
GO

-- List Query TVF: RegionsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'RegionsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[RegionsQuery]
GO

CREATE FUNCTION  [CorePatterns].[RegionsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey], [T1].[Name] AS [Name]
FROM [CorePatterns].[RegionsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[Name] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.PostalZonesLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.PostalZonesLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= 'c92fb37c-5a57-45da-ae62-67018afcf968')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= 'c92fb37c-5a57-45da-ae62-67018afcf968'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    'c92fb37c-5a57-45da-ae62-67018afcf968'
    ,'CorePatterns'
    ,'PostalZones'
    ,'PostalZonesLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Codi Postal"},{ "Culture":"es","Data":"Código Postal"},{ "Culture":"it","Data":"Codice Postale"},{ "Culture":"pt","Data":"Código Postal"},{ "Culture":"en","Data":"Postal Code"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Codi Postal, Descripció)"},{ "Culture":"es","Data":"(Código Postal, Descripción)"},{ "Culture":"it","Data":"(Codice Postale, Descrizione)"},{ "Culture":"pt","Data":"(Código Postal, Descrição)"},{ "Culture":"en","Data":"(Postal Code, Description)"}]}'
    ,1
    ,'c92fb37c-5a57-45da-ae62-67018afcf968'
    ,'c92fb37c-5a57-45da-ae62-67018afcf968'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '0892bb01-f3e6-5c00-5883-8c90761a4730'
        ,'{"Values":[{ "Culture":"ca","Data":"Codi Postal"},{ "Culture":"es","Data":"Código Postal"},{ "Culture":"it","Data":"Codice Postale"},{ "Culture":"pt","Data":"Código Postal"},{ "Culture":"en","Data":"Postal Code"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'c92fb37c-5a57-45da-ae62-67018afcf968'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: Description (Description) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '155b0df8-b346-1bc0-f99d-8dd4670e9f68'
        ,'{"Values":[{ "Culture":"ca","Data":"Descripció"},{ "Culture":"es","Data":"Descripción"},{ "Culture":"it","Data":"Descrizione"},{ "Culture":"pt","Data":"Descrição"},{ "Culture":"en","Data":"Description"}]}'
        ,'True'
        ,'False'
        ,1
        ,'Text'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'c92fb37c-5a57-45da-ae62-67018afcf968'
        ,0
        ,0
        ,1
        ,'Description'
        ,'Description'
        ,'True'
        )
GO

-- List Query TVF: PostalZonesQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'PostalZonesQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[PostalZonesQuery]
GO

CREATE FUNCTION  [CorePatterns].[PostalZonesQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey], [T1].[Description] AS [Description]
FROM [CorePatterns].[PostalZonesView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[Description] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.CompaniesLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.CompaniesLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= 'cfceb0dc-99f3-455d-9b6d-38bb7bffa159')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= 'cfceb0dc-99f3-455d-9b6d-38bb7bffa159'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    'cfceb0dc-99f3-455d-9b6d-38bb7bffa159'
    ,'CorePatterns'
    ,'Companies'
    ,'CompaniesLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Empresa"},{ "Culture":"es","Data":"Empresa"},{ "Culture":"it","Data":"Società"},{ "Culture":"pt","Data":"Empresa"},{ "Culture":"en","Data":"Company"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Empresa, Nom de l''Empresa)"},{ "Culture":"es","Data":"(Empresa, Nombre de la Empresa)"},{ "Culture":"it","Data":"(Azienda, Nome dell''azienda)"},{ "Culture":"pt","Data":"(Empresa, Nome da Empresa)"},{ "Culture":"en","Data":"(Company, Company Name)"}]}'
    ,1
    ,'cfceb0dc-99f3-455d-9b6d-38bb7bffa159'
    ,'cfceb0dc-99f3-455d-9b6d-38bb7bffa159'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'b474cc85-6f70-ca41-3616-e97544306487'
        ,'{"Values":[{ "Culture":"ca","Data":"Empresa"},{ "Culture":"es","Data":"Empresa"},{ "Culture":"it","Data":"Società"},{ "Culture":"pt","Data":"Empresa"},{ "Culture":"en","Data":"Company"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'cfceb0dc-99f3-455d-9b6d-38bb7bffa159'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: Name (Name) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '3219c963-3a16-1980-c720-5fea3dc53733'
        ,'{"Values":[{ "Culture":"ca","Data":"Nom de l''Empresa"},{ "Culture":"es","Data":"Nombre de la Empresa"},{ "Culture":"it","Data":"Nome della ditta"},{ "Culture":"pt","Data":"Nome da Empresa"},{ "Culture":"en","Data":"Company Name"}]}'
        ,'True'
        ,'False'
        ,1
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'cfceb0dc-99f3-455d-9b6d-38bb7bffa159'
        ,0
        ,0
        ,1
        ,'Name'
        ,'Name'
        ,'True'
        )
GO

-- List Query TVF: CompaniesQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'CompaniesQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[CompaniesQuery]
GO

CREATE FUNCTION  [CorePatterns].[CompaniesQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey], [T1].[Name] AS [Name]
FROM [CorePatterns].[CompaniesIncludeDeletedView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[Name] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI))
AND (ISNULL([T1].[AccessClaim], '') = ''
OR [T1].[AccessClaim] IN (SELECT AccessClaim
FROM [Identity].[UserAccessClaims]
WHERE ([UserAccessClaims].[AccessClaim] = [T1].[AccessClaim]
AND [UserAccessClaims].[UserId] = CAST(@user AS uniqueidentifier)))))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.AddressesLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.AddressesLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '0f214758-e9f3-4a1a-9f5c-7aac3445ccdc')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '0f214758-e9f3-4a1a-9f5c-7aac3445ccdc'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '0f214758-e9f3-4a1a-9f5c-7aac3445ccdc'
    ,'CorePatterns'
    ,'Addresses'
    ,'AddressesLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Adreça"},{ "Culture":"es","Data":"Dirección"},{ "Culture":"it","Data":"Indirizzo"},{ "Culture":"pt","Data":"Endereço"},{ "Culture":"en","Data":"Address"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Adreça, Nom del Contacte)"},{ "Culture":"es","Data":"(Dirección, Nombre del Contacto)"},{ "Culture":"it","Data":"(Indirizzo, nome del contatto)"},{ "Culture":"pt","Data":"(Endereço, Nome do Contacto)"},{ "Culture":"en","Data":"(Address, Contact Name)"}]}'
    ,1
    ,'0f214758-e9f3-4a1a-9f5c-7aac3445ccdc'
    ,'0f214758-e9f3-4a1a-9f5c-7aac3445ccdc'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '68e69374-ad6e-56de-5237-63d0545d14f8'
        ,'{"Values":[{ "Culture":"ca","Data":"Adreça"},{ "Culture":"es","Data":"Dirección"},{ "Culture":"it","Data":"Indirizzo"},{ "Culture":"pt","Data":"Endereço"},{ "Culture":"en","Data":"Address"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'0f214758-e9f3-4a1a-9f5c-7aac3445ccdc'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: ContactName (ContactName) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '8347d8a3-1c3c-bda0-cb11-c39519770765'
        ,'{"Values":[{ "Culture":"ca","Data":"Nom del Contacte"},{ "Culture":"es","Data":"Nombre del Contacto"},{ "Culture":"it","Data":"Nome del contatto"},{ "Culture":"pt","Data":"Nome do Contacto"},{ "Culture":"en","Data":"Contact Name"}]}'
        ,'True'
        ,'False'
        ,1
        ,'Text'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'0f214758-e9f3-4a1a-9f5c-7aac3445ccdc'
        ,0
        ,0
        ,1
        ,'ContactName'
        ,'ContactName'
        ,'True'
        )
GO

-- List Query TVF: AddressesQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'AddressesQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[AddressesQuery]
GO

CREATE FUNCTION  [CorePatterns].[AddressesQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey], [T1].[ContactName] AS [ContactName]
FROM [CorePatterns].[AddressesView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[ContactName] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.ExchangeRatesLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.ExchangeRatesLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '9422871e-2a0b-444b-9c62-7b39d634dc7e')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '9422871e-2a0b-444b-9c62-7b39d634dc7e'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '9422871e-2a0b-444b-9c62-7b39d634dc7e'
    ,'CorePatterns'
    ,'ExchangeRates'
    ,'ExchangeRatesLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Tipus de Canvi"},{ "Culture":"es","Data":"Tipo de Cambio"},{ "Culture":"it","Data":"Tasso di cambio"},{ "Culture":"pt","Data":"Taxa de Câmbio"},{ "Culture":"en","Data":"Exchange Rate"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Tipus de Canvi)"},{ "Culture":"es","Data":"(Tipo de Cambio)"},{ "Culture":"it","Data":"(Tasso di cambio)"},{ "Culture":"pt","Data":"(Taxa de Câmbio)"},{ "Culture":"en","Data":"(Exchange Rate)"}]}'
    ,1
    ,'9422871e-2a0b-444b-9c62-7b39d634dc7e'
    ,'9422871e-2a0b-444b-9c62-7b39d634dc7e'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'ebdff015-e6c5-cfb4-689d-e75f75d2257c'
        ,'{"Values":[{ "Culture":"ca","Data":"Tipus de Canvi"},{ "Culture":"es","Data":"Tipo de Cambio"},{ "Culture":"it","Data":"Tasso di cambio"},{ "Culture":"pt","Data":"Taxa de Câmbio"},{ "Culture":"en","Data":"Exchange Rate"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'9422871e-2a0b-444b-9c62-7b39d634dc7e'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: ExchangeRatesQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'ExchangeRatesQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[ExchangeRatesQuery]
GO

CREATE FUNCTION  [CorePatterns].[ExchangeRatesQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [CorePatterns].[ExchangeRatesView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.UnitsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.UnitsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= 'a35d5fb1-84ab-46b9-a599-813542cda30b')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= 'a35d5fb1-84ab-46b9-a599-813542cda30b'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    'a35d5fb1-84ab-46b9-a599-813542cda30b'
    ,'CorePatterns'
    ,'Units'
    ,'UnitsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Unitat"},{ "Culture":"es","Data":"Unidad"},{ "Culture":"it","Data":"Unità"},{ "Culture":"pt","Data":"Unidade"},{ "Culture":"en","Data":"Unit"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Unitat, Descripció)"},{ "Culture":"es","Data":"(Unidad, Descripción)"},{ "Culture":"it","Data":"(Unità, Descrizione)"},{ "Culture":"pt","Data":"(Unidade, Descrição)"},{ "Culture":"en","Data":"(Unit, Description)"}]}'
    ,1
    ,'a35d5fb1-84ab-46b9-a599-813542cda30b'
    ,'a35d5fb1-84ab-46b9-a599-813542cda30b'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'be0042ae-9bcc-c011-16bb-1031f10033b2'
        ,'{"Values":[{ "Culture":"ca","Data":"Unitat"},{ "Culture":"es","Data":"Unidad"},{ "Culture":"it","Data":"Unità"},{ "Culture":"pt","Data":"Unidade"},{ "Culture":"en","Data":"Unit"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'a35d5fb1-84ab-46b9-a599-813542cda30b'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: Description (Description) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'd3f49417-775d-0570-995f-1b0627b92c18'
        ,'{"Values":[{ "Culture":"ca","Data":"Descripció"},{ "Culture":"es","Data":"Descripción"},{ "Culture":"it","Data":"Descrizione"},{ "Culture":"pt","Data":"Descrição"},{ "Culture":"en","Data":"Description"}]}'
        ,'True'
        ,'False'
        ,1
        ,'Text'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'a35d5fb1-84ab-46b9-a599-813542cda30b'
        ,0
        ,0
        ,1
        ,'Description'
        ,'Description'
        ,'True'
        )
GO

-- List Query TVF: UnitsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'UnitsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[UnitsQuery]
GO

CREATE FUNCTION  [CorePatterns].[UnitsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey], [T1].[Description] AS [Description]
FROM [CorePatterns].[UnitsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[Description] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.UnitDimensionsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.UnitDimensionsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '70754271-5c3c-4433-aa7f-0a57857ef011')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '70754271-5c3c-4433-aa7f-0a57857ef011'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '70754271-5c3c-4433-aa7f-0a57857ef011'
    ,'CorePatterns'
    ,'UnitDimensions'
    ,'UnitDimensionsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Dimensió de l''Unitat"},{ "Culture":"es","Data":"Dimensión de la Unidad"},{ "Culture":"it","Data":"Dimensione dell''unità"},{ "Culture":"pt","Data":"Dimensão da Unidade"},{ "Culture":"en","Data":"Unit Dimension"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Dimensió de l''Unitat, Descripció)"},{ "Culture":"es","Data":"(Dimensión de la Unidad, Descripción)"},{ "Culture":"it","Data":"(Dimensione Unità, Descrizione)"},{ "Culture":"pt","Data":"(Dimensão da Unidade, Descrição)"},{ "Culture":"en","Data":"(Unit Dimension, Description)"}]}'
    ,1
    ,'70754271-5c3c-4433-aa7f-0a57857ef011'
    ,'70754271-5c3c-4433-aa7f-0a57857ef011'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'd7eb47d0-6af4-a546-9734-7bd56f213bb3'
        ,'{"Values":[{ "Culture":"ca","Data":"Dimensió de l''Unitat"},{ "Culture":"es","Data":"Dimensión de la Unidad"},{ "Culture":"it","Data":"Dimensione dell''unità"},{ "Culture":"pt","Data":"Dimensão da Unidade"},{ "Culture":"en","Data":"Unit Dimension"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'70754271-5c3c-4433-aa7f-0a57857ef011'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: Description (Description) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '0ccb8454-b02e-873e-fd2d-bfa0352c396d'
        ,'{"Values":[{ "Culture":"ca","Data":"Descripció"},{ "Culture":"es","Data":"Descripción"},{ "Culture":"it","Data":"Descrizione"},{ "Culture":"pt","Data":"Descrição"},{ "Culture":"en","Data":"Description"}]}'
        ,'True'
        ,'False'
        ,1
        ,'Text'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'70754271-5c3c-4433-aa7f-0a57857ef011'
        ,0
        ,0
        ,1
        ,'Description'
        ,'Description'
        ,'True'
        )
GO

-- List Query TVF: UnitDimensionsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'UnitDimensionsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[UnitDimensionsQuery]
GO

CREATE FUNCTION  [CorePatterns].[UnitDimensionsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey], [T1].[Description] AS [Description]
FROM [CorePatterns].[UnitDimensionsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[Description] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- List Query TVF: MovEntitiesLookupDependenciesQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'MovEntitiesLookupDependenciesQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[MovEntitiesLookupDependenciesQuery]
GO

CREATE FUNCTION  [CorePatterns].[MovEntitiesLookupDependenciesQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [CorePatterns].[MovEntitiesLookupDependenciesView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.PowerBiInfosLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.PowerBiInfosLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '11901357-b1f8-42e7-9b30-652d237d45eb')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '11901357-b1f8-42e7-9b30-652d237d45eb'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '11901357-b1f8-42e7-9b30-652d237d45eb'
    ,'CorePatterns'
    ,'PowerBiInfos'
    ,'PowerBiInfosLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Info. de Power Bi"},{ "Culture":"es","Data":"Info. de Power Bi"},{ "Culture":"it","Data":"Power BI info"},{ "Culture":"pt","Data":"Info. de Power Bi"},{ "Culture":"en","Data":"Power Bi Info"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Info. de Power Bi)"},{ "Culture":"es","Data":"(Info. de Power Bi)"},{ "Culture":"it","Data":"(Power BI info)"},{ "Culture":"pt","Data":"(Info. de Power Bi)"},{ "Culture":"en","Data":"(Power Bi Info)"}]}'
    ,1
    ,'11901357-b1f8-42e7-9b30-652d237d45eb'
    ,'11901357-b1f8-42e7-9b30-652d237d45eb'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '27f71608-90e3-3e87-b817-b79907a9193e'
        ,'{"Values":[{ "Culture":"ca","Data":"Info. de Power Bi"},{ "Culture":"es","Data":"Info. de Power Bi"},{ "Culture":"it","Data":"Power BI info"},{ "Culture":"pt","Data":"Info. de Power Bi"},{ "Culture":"en","Data":"Power Bi Info"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'11901357-b1f8-42e7-9b30-652d237d45eb'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: PowerBiInfosQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'PowerBiInfosQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[PowerBiInfosQuery]
GO

CREATE FUNCTION  [CorePatterns].[PowerBiInfosQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [CorePatterns].[PowerBiInfosView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.ContactsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.ContactsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= 'b7ec2abe-9833-41f6-beb3-3f187c51124b')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= 'b7ec2abe-9833-41f6-beb3-3f187c51124b'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    'b7ec2abe-9833-41f6-beb3-3f187c51124b'
    ,'CorePatterns'
    ,'Contacts'
    ,'ContactsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Contacte"},{ "Culture":"es","Data":"Contacto"},{ "Culture":"it","Data":"Contatto"},{ "Culture":"pt","Data":"Contacto"},{ "Culture":"en","Data":"Contact"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Contacte, Nom, Contacte Professional, E-mail)"},{ "Culture":"es","Data":"(Contacto, Nombre, Contacto Profesional, Email)"},{ "Culture":"it","Data":"(Contatto, nome, telefono aziendale, e-mail)"},{ "Culture":"pt","Data":"(Contacto, Nome, Contacto Profissional, Email)"},{ "Culture":"en","Data":"(Contact, Name, Business Phone, Email)"}]}'
    ,1
    ,'b7ec2abe-9833-41f6-beb3-3f187c51124b'
    ,'b7ec2abe-9833-41f6-beb3-3f187c51124b'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '0c078b5c-6f90-ddd1-78fb-16130332cbf7'
        ,'{"Values":[{ "Culture":"ca","Data":"Contacte"},{ "Culture":"es","Data":"Contacto"},{ "Culture":"it","Data":"Contatto"},{ "Culture":"pt","Data":"Contacto"},{ "Culture":"en","Data":"Contact"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'b7ec2abe-9833-41f6-beb3-3f187c51124b'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: Name (Name) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '0b424164-2051-f1ce-1411-9758f21dbac7'
        ,'{"Values":[{ "Culture":"ca","Data":"Nom"},{ "Culture":"es","Data":"Nombre"},{ "Culture":"it","Data":"Nome"},{ "Culture":"pt","Data":"Nome"},{ "Culture":"en","Data":"Name"}]}'
        ,'True'
        ,'False'
        ,1
        ,'Text'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'b7ec2abe-9833-41f6-beb3-3f187c51124b'
        ,0
        ,0
        ,1
        ,'Name'
        ,'Name'
        ,'True'
        )
GO


-- Column: BusinessTelephone (BusinessTelephone) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'feb3d269-15c1-ae42-8dc9-0e1b173f764d'
        ,'{"Values":[{ "Culture":"ca","Data":"Contacte Professional"},{ "Culture":"es","Data":"Contacto Profesional"},{ "Culture":"it","Data":"telefono aziendale"},{ "Culture":"pt","Data":"Contacto Profissional"},{ "Culture":"en","Data":"Business Phone"}]}'
        ,'True'
        ,'False'
        ,2
        ,'Phone'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'b7ec2abe-9833-41f6-beb3-3f187c51124b'
        ,0
        ,0
        ,1
        ,'BusinessTelephone'
        ,'BusinessTelephone'
        ,'True'
        )
GO


-- Column: ElectronicMail (ElectronicMail) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '29e0770a-cfb9-ff76-9a01-bd526cfbf36a'
        ,'{"Values":[{ "Culture":"ca","Data":"E-mail"},{ "Culture":"es","Data":"Email"},{ "Culture":"it","Data":"E-mail"},{ "Culture":"pt","Data":"Email"},{ "Culture":"en","Data":"Email"}]}'
        ,'True'
        ,'False'
        ,3
        ,'Email'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'b7ec2abe-9833-41f6-beb3-3f187c51124b'
        ,0
        ,0
        ,1
        ,'ElectronicMail'
        ,'ElectronicMail'
        ,'True'
        )
GO

-- List Query TVF: ContactsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'ContactsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[ContactsQuery]
GO

CREATE FUNCTION  [CorePatterns].[ContactsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey], [T1].[Name] AS [Name], [T1].[BusinessTelephone] AS [BusinessTelephone], [T1].[ElectronicMail] AS [ElectronicMail]
FROM [CorePatterns].[ContactsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[Name] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[BusinessTelephone] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[ElectronicMail] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.ContactTypesLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.ContactTypesLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= 'c198ba43-3d38-4f83-825d-63b0408b6f8b')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= 'c198ba43-3d38-4f83-825d-63b0408b6f8b'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    'c198ba43-3d38-4f83-825d-63b0408b6f8b'
    ,'CorePatterns'
    ,'ContactTypes'
    ,'ContactTypesLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Tipus de Contacte"},{ "Culture":"es","Data":"Tipo de Contacto"},{ "Culture":"it","Data":"Tipo di contatto"},{ "Culture":"pt","Data":"Tipo de Contacto"},{ "Culture":"en","Data":"Contact Type"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Tipus de Contacte, Descripció)"},{ "Culture":"es","Data":"(Tipo de Contacto, Descripción)"},{ "Culture":"it","Data":"(Tipo di contatto, Descrizione)"},{ "Culture":"pt","Data":"(Tipo de Contacto, Descrição)"},{ "Culture":"en","Data":"(Contact Type, Description)"}]}'
    ,1
    ,'c198ba43-3d38-4f83-825d-63b0408b6f8b'
    ,'c198ba43-3d38-4f83-825d-63b0408b6f8b'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'b46811cc-e355-d38d-ae93-e06a212508be'
        ,'{"Values":[{ "Culture":"ca","Data":"Tipus de Contacte"},{ "Culture":"es","Data":"Tipo de Contacto"},{ "Culture":"it","Data":"Tipo di contatto"},{ "Culture":"pt","Data":"Tipo de Contacto"},{ "Culture":"en","Data":"Contact Type"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'c198ba43-3d38-4f83-825d-63b0408b6f8b'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: Description (Description) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'd63a5de5-0dfc-79f7-ebfb-bb45007df116'
        ,'{"Values":[{ "Culture":"ca","Data":"Descripció"},{ "Culture":"es","Data":"Descripción"},{ "Culture":"it","Data":"Descrizione"},{ "Culture":"pt","Data":"Descrição"},{ "Culture":"en","Data":"Description"}]}'
        ,'True'
        ,'False'
        ,1
        ,'Text'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'c198ba43-3d38-4f83-825d-63b0408b6f8b'
        ,0
        ,0
        ,1
        ,'Description'
        ,'Description'
        ,'True'
        )
GO

-- List Query TVF: ContactTypesQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'ContactTypesQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[ContactTypesQuery]
GO

CREATE FUNCTION  [CorePatterns].[ContactTypesQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey], [T1].[Description] AS [Description]
FROM [CorePatterns].[ContactTypesView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[Description] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.ContactGroupsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.ContactGroupsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '7717e6d0-d51e-4adb-a935-2669b435ea24')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '7717e6d0-d51e-4adb-a935-2669b435ea24'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '7717e6d0-d51e-4adb-a935-2669b435ea24'
    ,'CorePatterns'
    ,'ContactGroups'
    ,'ContactGroupsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Grup de Contactes"},{ "Culture":"es","Data":"Grupo de Contactos"},{ "Culture":"it","Data":"Contatta Group."},{ "Culture":"pt","Data":"Grupo de Contactos"},{ "Culture":"en","Data":"Contact Group"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Grup de Contactes, Descripció)"},{ "Culture":"es","Data":"(Grupo de Contactos, Descripción)"},{ "Culture":"it","Data":"(Gruppo di contatto, descrizione)"},{ "Culture":"pt","Data":"(Grupo de Contactos, Descrição)"},{ "Culture":"en","Data":"(Contact Group, Description)"}]}'
    ,1
    ,'7717e6d0-d51e-4adb-a935-2669b435ea24'
    ,'7717e6d0-d51e-4adb-a935-2669b435ea24'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '752c6546-25aa-ce43-d7dd-4623efd01557'
        ,'{"Values":[{ "Culture":"ca","Data":"Grup de Contactes"},{ "Culture":"es","Data":"Grupo de Contactos"},{ "Culture":"it","Data":"Contatta Group."},{ "Culture":"pt","Data":"Grupo de Contactos"},{ "Culture":"en","Data":"Contact Group"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'7717e6d0-d51e-4adb-a935-2669b435ea24'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: Description (Description) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '695b2592-8632-4c1f-e93e-096a342009fa'
        ,'{"Values":[{ "Culture":"ca","Data":"Descripció"},{ "Culture":"es","Data":"Descripción"},{ "Culture":"it","Data":"Descrizione"},{ "Culture":"pt","Data":"Descrição"},{ "Culture":"en","Data":"Description"}]}'
        ,'True'
        ,'False'
        ,1
        ,'Text'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'7717e6d0-d51e-4adb-a935-2669b435ea24'
        ,0
        ,0
        ,1
        ,'Description'
        ,'Description'
        ,'True'
        )
GO

-- List Query TVF: ContactGroupsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'ContactGroupsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[ContactGroupsQuery]
GO

CREATE FUNCTION  [CorePatterns].[ContactGroupsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey], [T1].[Description] AS [Description]
FROM [CorePatterns].[ContactGroupsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[Description] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.FiscalTimeZonesLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.FiscalTimeZonesLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '70306f3c-b342-40f3-b56d-16cf5daa3cfc')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '70306f3c-b342-40f3-b56d-16cf5daa3cfc'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '70306f3c-b342-40f3-b56d-16cf5daa3cfc'
    ,'CorePatterns'
    ,'FiscalTimeZones'
    ,'FiscalTimeZonesLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Fus Horari Fiscal"},{ "Culture":"es","Data":"Huso Horario Fiscal"},{ "Culture":"it","Data":"Fuso orario fiscale"},{ "Culture":"pt","Data":"Fuso Horário Fiscal"},{ "Culture":"en","Data":"Fiscal Time Zone"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Fus Horari Fiscal, Nom de visualització)"},{ "Culture":"es","Data":"(Huso Horario Fiscal, Nombre para mostrar)"},{ "Culture":"it","Data":"(Fuso orario fiscale, nome visualizzato)"},{ "Culture":"pt","Data":"(Fuso Horário Fiscal, Nome a apresentar)"},{ "Culture":"en","Data":"(Fiscal Time Zone, Display Name)"}]}'
    ,1
    ,'70306f3c-b342-40f3-b56d-16cf5daa3cfc'
    ,'70306f3c-b342-40f3-b56d-16cf5daa3cfc'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '04077f0c-f33b-3c63-7bd1-05e26b85cdf8'
        ,'{"Values":[{ "Culture":"ca","Data":"Fus Horari Fiscal"},{ "Culture":"es","Data":"Huso Horario Fiscal"},{ "Culture":"it","Data":"Fuso orario fiscale"},{ "Culture":"pt","Data":"Fuso Horário Fiscal"},{ "Culture":"en","Data":"Fiscal Time Zone"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'70306f3c-b342-40f3-b56d-16cf5daa3cfc'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: DisplayName (DisplayName) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '572a954e-2936-8e04-bda7-789acc7c1bbb'
        ,'{"Values":[{ "Culture":"ca","Data":"Nom de visualització"},{ "Culture":"es","Data":"Nombre para mostrar"},{ "Culture":"it","Data":"Nome da visualizzare"},{ "Culture":"pt","Data":"Nome a apresentar"},{ "Culture":"en","Data":"Display Name"}]}'
        ,'True'
        ,'False'
        ,1
        ,'Text'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'70306f3c-b342-40f3-b56d-16cf5daa3cfc'
        ,0
        ,0
        ,1
        ,'DisplayName'
        ,'DisplayName'
        ,'True'
        )
GO

-- List Query TVF: FiscalTimeZonesQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'FiscalTimeZonesQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[FiscalTimeZonesQuery]
GO

CREATE FUNCTION  [CorePatterns].[FiscalTimeZonesQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey], [CorePatterns].[GetLocalizedValue]([T1].[DisplayName], @culture) AS [DisplayName]
FROM [CorePatterns].[FiscalTimeZonesView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [CorePatterns].[GetLocalizedValue]([T1].[DisplayName], @culture) LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.AttachmentsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.AttachmentsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '0650e501-8f1c-47a8-9a49-eafa1aab2244')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '0650e501-8f1c-47a8-9a49-eafa1aab2244'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '0650e501-8f1c-47a8-9a49-eafa1aab2244'
    ,'CorePatterns'
    ,'Attachments'
    ,'AttachmentsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Adjunt"},{ "Culture":"es","Data":"Adjunto"},{ "Culture":"it","Data":"Attaccamento"},{ "Culture":"pt","Data":"Anexo"},{ "Culture":"en","Data":"Attachment"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Adjunt)"},{ "Culture":"es","Data":"(Adjunto)"},{ "Culture":"it","Data":"(Attacco)"},{ "Culture":"pt","Data":"(Anexo)"},{ "Culture":"en","Data":"(Attachment)"}]}'
    ,1
    ,'0650e501-8f1c-47a8-9a49-eafa1aab2244'
    ,'0650e501-8f1c-47a8-9a49-eafa1aab2244'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '36d922ff-9099-e4fa-889b-0a8ba45b1e6b'
        ,'{"Values":[{ "Culture":"ca","Data":"Adjunt"},{ "Culture":"es","Data":"Adjunto"},{ "Culture":"it","Data":"Attaccamento"},{ "Culture":"pt","Data":"Anexo"},{ "Culture":"en","Data":"Attachment"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'0650e501-8f1c-47a8-9a49-eafa1aab2244'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: AttachmentsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'AttachmentsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[AttachmentsQuery]
GO

CREATE FUNCTION  [CorePatterns].[AttachmentsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [CorePatterns].[AttachmentsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.ImportDataTemplatesLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.ImportDataTemplatesLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '7488c5c9-4e04-4958-92f1-8afdeea3b1b1')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '7488c5c9-4e04-4958-92f1-8afdeea3b1b1'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '7488c5c9-4e04-4958-92f1-8afdeea3b1b1'
    ,'CorePatterns'
    ,'ImportDataTemplates'
    ,'ImportDataTemplatesLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Plantilla per Importació de Dades"},{ "Culture":"es","Data":"Plantilla para Importación de Datos"},{ "Culture":"it","Data":"Importa modello di dati"},{ "Culture":"pt","Data":"Modelo para Importação de Dados"},{ "Culture":"en","Data":"Import Data Template"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Plantilla per Importació de Dades)"},{ "Culture":"es","Data":"(Plantilla para Importación de Datos)"},{ "Culture":"it","Data":"(Importa modello di dati)"},{ "Culture":"pt","Data":"(Modelo para Importação de Dados)"},{ "Culture":"en","Data":"(Import Data Template)"}]}'
    ,1
    ,'7488c5c9-4e04-4958-92f1-8afdeea3b1b1'
    ,'7488c5c9-4e04-4958-92f1-8afdeea3b1b1'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'd150e3a0-3778-4126-aad8-9e632d509509'
        ,'{"Values":[{ "Culture":"ca","Data":"Plantilla per Importació de Dades"},{ "Culture":"es","Data":"Plantilla para Importación de Datos"},{ "Culture":"it","Data":"Importa modello di dati"},{ "Culture":"pt","Data":"Modelo para Importação de Dados"},{ "Culture":"en","Data":"Import Data Template"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'7488c5c9-4e04-4958-92f1-8afdeea3b1b1'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: ImportDataTemplatesQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'ImportDataTemplatesQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[ImportDataTemplatesQuery]
GO

CREATE FUNCTION  [CorePatterns].[ImportDataTemplatesQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [CorePatterns].[ImportDataTemplatesView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.ImportDataInfosLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.ImportDataInfosLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= 'd3f7a877-66d8-48dd-99d6-253999218457')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= 'd3f7a877-66d8-48dd-99d6-253999218457'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    'd3f7a877-66d8-48dd-99d6-253999218457'
    ,'CorePatterns'
    ,'ImportDataInfos'
    ,'ImportDataInfosLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Info. de l''Importació de Dades"},{ "Culture":"es","Data":"Info. de la Importación de Datos"},{ "Culture":"it","Data":"Importa informazioni sui dati"},{ "Culture":"pt","Data":"Info. da Importação de Dados"},{ "Culture":"en","Data":"Import Data Info"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Info. de l''Importació de Dades)"},{ "Culture":"es","Data":"(Info. de la Importación de Datos)"},{ "Culture":"it","Data":"(Importa informazioni sui dati)"},{ "Culture":"pt","Data":"(Info. dos Dados de Importação)"},{ "Culture":"en","Data":"(Import Data Info)"}]}'
    ,1
    ,'d3f7a877-66d8-48dd-99d6-253999218457'
    ,'d3f7a877-66d8-48dd-99d6-253999218457'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'f8d92663-0a89-5932-3763-174c6e5943e5'
        ,'{"Values":[{ "Culture":"ca","Data":"Info. de l''Importació de Dades"},{ "Culture":"es","Data":"Info. de la Importación de Datos"},{ "Culture":"it","Data":"Importa informazioni sui dati"},{ "Culture":"pt","Data":"Info. da Importação de Dados"},{ "Culture":"en","Data":"Import Data Info"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'d3f7a877-66d8-48dd-99d6-253999218457'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: ImportDataInfosQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'ImportDataInfosQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[ImportDataInfosQuery]
GO

CREATE FUNCTION  [CorePatterns].[ImportDataInfosQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [CorePatterns].[ImportDataInfosView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.ClientNotificationsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.ClientNotificationsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '0b7909e2-0f03-4c2e-ac13-97bbef3e4689')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '0b7909e2-0f03-4c2e-ac13-97bbef3e4689'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '0b7909e2-0f03-4c2e-ac13-97bbef3e4689'
    ,'CorePatterns'
    ,'ClientNotifications'
    ,'ClientNotificationsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Notificació de Client"},{ "Culture":"es","Data":"Notificación de Cliente"},{ "Culture":"it","Data":"Notifica del cliente"},{ "Culture":"pt","Data":"Notificação de Cliente"},{ "Culture":"en","Data":"Client Notification"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Notificació de client)"},{ "Culture":"es","Data":"(Notificación de cliente)"},{ "Culture":"it","Data":"(Notifica del client)"},{ "Culture":"pt","Data":"(Notificação de Cliente)"},{ "Culture":"en","Data":"(Client Notification)"}]}'
    ,1
    ,'0b7909e2-0f03-4c2e-ac13-97bbef3e4689'
    ,'0b7909e2-0f03-4c2e-ac13-97bbef3e4689'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '5ce5044b-9515-328e-a11f-5ba96b1a6b3b'
        ,'{"Values":[{ "Culture":"ca","Data":"Notificació de Client"},{ "Culture":"es","Data":"Notificación de Cliente"},{ "Culture":"it","Data":"Notifica del cliente"},{ "Culture":"pt","Data":"Notificação de Cliente"},{ "Culture":"en","Data":"Client Notification"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'0b7909e2-0f03-4c2e-ac13-97bbef3e4689'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: ClientNotificationsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'ClientNotificationsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[ClientNotificationsQuery]
GO

CREATE FUNCTION  [CorePatterns].[ClientNotificationsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [CorePatterns].[ClientNotificationsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.EntityLockReasonsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.EntityLockReasonsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '4ddc2ff0-4172-4b3b-8148-8dd21c9f610f')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '4ddc2ff0-4172-4b3b-8148-8dd21c9f610f'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '4ddc2ff0-4172-4b3b-8148-8dd21c9f610f'
    ,'CorePatterns'
    ,'EntityLockReasons'
    ,'EntityLockReasonsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Motiu de Bloqueig d''Entitat"},{ "Culture":"es","Data":"Motivo de Bloqueo de Entidad"},{ "Culture":"it","Data":"Motivo della serratura dell''entità"},{ "Culture":"pt","Data":"Motivo de Bloqueio de Entidade"},{ "Culture":"en","Data":"Entity Lock Reason"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Motiu de Bloqueig d''Entitat, Descripció)"},{ "Culture":"es","Data":"(Motivo de Bloqueo de Entidad, Descripción)"},{ "Culture":"it","Data":"(Motivo della serratura dell''entità, Descrizione)"},{ "Culture":"pt","Data":"(Motivo de Bloqueio de Entidade, Descrição)"},{ "Culture":"en","Data":"(Entity Lock Reason, Description)"}]}'
    ,1
    ,'4ddc2ff0-4172-4b3b-8148-8dd21c9f610f'
    ,'4ddc2ff0-4172-4b3b-8148-8dd21c9f610f'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'aa6c1ef6-eaeb-644d-2db9-6187a35d659f'
        ,'{"Values":[{ "Culture":"ca","Data":"Motiu de Bloqueig d''Entitat"},{ "Culture":"es","Data":"Motivo de Bloqueo de Entidad"},{ "Culture":"it","Data":"Motivo della serratura dell''entità"},{ "Culture":"pt","Data":"Motivo de Bloqueio de Entidade"},{ "Culture":"en","Data":"Entity Lock Reason"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'4ddc2ff0-4172-4b3b-8148-8dd21c9f610f'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: Description (Description) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'ee696a29-5124-d116-2c75-b25feb3a4a42'
        ,'{"Values":[{ "Culture":"ca","Data":"Descripció"},{ "Culture":"es","Data":"Descripción"},{ "Culture":"it","Data":"Descrizione"},{ "Culture":"pt","Data":"Descrição"},{ "Culture":"en","Data":"Description"}]}'
        ,'True'
        ,'False'
        ,1
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'4ddc2ff0-4172-4b3b-8148-8dd21c9f610f'
        ,0
        ,0
        ,1
        ,'Description'
        ,'Description'
        ,'True'
        )
GO

-- List Query TVF: EntityLockReasonsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'EntityLockReasonsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[EntityLockReasonsQuery]
GO

CREATE FUNCTION  [CorePatterns].[EntityLockReasonsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey], [CorePatterns].[GetLocalizedValue]([T1].[Description], @culture) AS [Description]
FROM [CorePatterns].[EntityLockReasonsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [CorePatterns].[GetLocalizedValue]([T1].[Description], @culture) LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.AssignmentsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.AssignmentsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '7398d97d-1ba7-4d08-9fff-6fccaeb6bb13')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '7398d97d-1ba7-4d08-9fff-6fccaeb6bb13'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '7398d97d-1ba7-4d08-9fff-6fccaeb6bb13'
    ,'CorePatterns'
    ,'Assignments'
    ,'AssignmentsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Tasca"},{ "Culture":"es","Data":"Tarea"},{ "Culture":"it","Data":"Incarico"},{ "Culture":"pt","Data":"Tarefa"},{ "Culture":"en","Data":"Assignment"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Tasca, Títol)"},{ "Culture":"es","Data":"(Tarea, Título)"},{ "Culture":"it","Data":"(Assegnazione, Titolo)"},{ "Culture":"pt","Data":"(Tarefa, Título)"},{ "Culture":"en","Data":"(Assignment, Title)"}]}'
    ,1
    ,'7398d97d-1ba7-4d08-9fff-6fccaeb6bb13'
    ,'7398d97d-1ba7-4d08-9fff-6fccaeb6bb13'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '6ea3103c-4203-a77f-4d4d-997e2ecefbb0'
        ,'{"Values":[{ "Culture":"ca","Data":"Tasca"},{ "Culture":"es","Data":"Tarea"},{ "Culture":"it","Data":"Incarico"},{ "Culture":"pt","Data":"Tarefa"},{ "Culture":"en","Data":"Assignment"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'7398d97d-1ba7-4d08-9fff-6fccaeb6bb13'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: AssignmentState (AssignmentState) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '6002a114-04ea-56b6-8625-c016448a80a5'
        ,'{"Values":[{ "Culture":"ca","Data":"Estat de la Tasca"},{ "Culture":"es","Data":"Estado de la Tarea"},{ "Culture":"it","Data":"Stato di assegnazione"},{ "Culture":"pt","Data":"Estado da Tarefa"},{ "Culture":"en","Data":"Assignment State"}]}'
        ,'True'
        ,'False'
        ,1
        ,'ValueListItem'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'7398d97d-1ba7-4d08-9fff-6fccaeb6bb13'
        ,0
        ,0
        ,1
        ,'AssignmentState'
        ,'AssignmentState'
        ,'True'
        )
GO


-- Column: Title (Title) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '09ba2a0f-633b-11cd-8fc3-ed7656bf631a'
        ,'{"Values":[{ "Culture":"ca","Data":"Títol"},{ "Culture":"es","Data":"Título"},{ "Culture":"it","Data":"Titolo"},{ "Culture":"pt","Data":"Título"},{ "Culture":"en","Data":"Title"}]}'
        ,'True'
        ,'False'
        ,2
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'7398d97d-1ba7-4d08-9fff-6fccaeb6bb13'
        ,0
        ,0
        ,1
        ,'Title'
        ,'Title'
        ,'True'
        )
GO


-- Column: AssignedToDescription (AssignedToDescription) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '7ae5fb26-eac4-3d31-4307-9d1f06c92e62'
        ,'{"Values":[{ "Culture":"ca","Data":"Assignat a la Descripció"},{ "Culture":"es","Data":"Asignado a la Descripción"},{ "Culture":"it","Data":"Assegnato a"},{ "Culture":"pt","Data":"Atribuído à Descrição"},{ "Culture":"en","Data":"Assigned To"}]}'
        ,'True'
        ,'False'
        ,3
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'7398d97d-1ba7-4d08-9fff-6fccaeb6bb13'
        ,0
        ,0
        ,1
        ,'AssignedToDescription'
        ,'AssignedToDescription'
        ,'True'
        )
GO

-- List Query TVF: AssignmentsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'AssignmentsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[AssignmentsQuery]
GO

CREATE FUNCTION  [CorePatterns].[AssignmentsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey], [CorePatterns].[GetLocalizedValue]([T2].[Description], @culture) AS [AssignmentState], [T1].[Title] AS [Title], [T1].[AssignedToDescription] AS [AssignedToDescription]
FROM [CorePatterns].[AssignmentsView] [T1]
LEFT JOIN [CorePatterns].[AssignmentStatesView] [T2] ON [T2].[Id] = [T1].[AssignmentStateId]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[Title] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.CustomEntityRecordsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.CustomEntityRecordsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '49469b00-3496-4cd3-bbd2-14a020b2b258')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '49469b00-3496-4cd3-bbd2-14a020b2b258'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '49469b00-3496-4cd3-bbd2-14a020b2b258'
    ,'CorePatterns'
    ,'CustomEntityRecords'
    ,'CustomEntityRecordsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Registre de l''Entitat Personalitzada"},{ "Culture":"es","Data":"Registro de la Entidad Personalizada"},{ "Culture":"it","Data":"Record di entità personalizzato"},{ "Culture":"pt","Data":"Registo da Entidade Personalizada"},{ "Culture":"en","Data":"Custom Entity Record"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Registre de l''Entitat Personalitzada, Descripció)"},{ "Culture":"es","Data":"(Registro de la Entidad Personalizada, Descripción)"},{ "Culture":"it","Data":"(Record di entità personalizzata, descrizione)"},{ "Culture":"pt","Data":"(Registo da Entidade Personalizada, Descrição)"},{ "Culture":"en","Data":"(Custom Entity Record, Description)"}]}'
    ,1
    ,'49469b00-3496-4cd3-bbd2-14a020b2b258'
    ,'49469b00-3496-4cd3-bbd2-14a020b2b258'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '55e866c8-9b07-ff26-da71-4683493176df'
        ,'{"Values":[{ "Culture":"ca","Data":"Registre de l''Entitat Personalitzada"},{ "Culture":"es","Data":"Registro de la Entidad Personalizada"},{ "Culture":"it","Data":"Record di entità personalizzato"},{ "Culture":"pt","Data":"Registo da Entidade Personalizada"},{ "Culture":"en","Data":"Custom Entity Record"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'49469b00-3496-4cd3-bbd2-14a020b2b258'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: Description (Description) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'ccfddd75-ab3f-f2e7-d0b5-fe0eb9f3073a'
        ,'{"Values":[{ "Culture":"ca","Data":"Descripció"},{ "Culture":"es","Data":"Descripción"},{ "Culture":"it","Data":"Descrizione"},{ "Culture":"pt","Data":"Descrição"},{ "Culture":"en","Data":"Description"}]}'
        ,'True'
        ,'False'
        ,1
        ,'Text'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'49469b00-3496-4cd3-bbd2-14a020b2b258'
        ,0
        ,0
        ,1
        ,'Description'
        ,'Description'
        ,'True'
        )
GO

-- List Query TVF: CustomEntityRecordsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'CustomEntityRecordsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[CustomEntityRecordsQuery]
GO

CREATE FUNCTION  [CorePatterns].[CustomEntityRecordsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL', @companyId UNIQUEIDENTIFIER  = NULL)
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey], [T1].[Description] AS [Description]
FROM [CorePatterns].[CustomEntityRecordsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[Description] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI))
AND (@companyId IS NULL
OR [T1].[CompanyId] = @companyId))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.BackgroundOperationsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.BackgroundOperationsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b'
    ,'CorePatterns'
    ,'BackgroundOperations'
    ,'BackgroundOperationsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Operació de Fons"},{ "Culture":"es","Data":"Operación de Fondo"},{ "Culture":"it","Data":"Dolototoperazione"},{ "Culture":"pt","Data":"Operação de Fundo"},{ "Culture":"en","Data":"BackgroundOperation"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Operació de Fons)"},{ "Culture":"es","Data":"(Operación de Fondo)"},{ "Culture":"it","Data":"(Downloadoperazione)"},{ "Culture":"pt","Data":"(Operação de Fundo)"},{ "Culture":"en","Data":"(BackgroundOperation)"}]}'
    ,1
    ,'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b'
    ,'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'd66cb03c-aafa-44bb-95a9-aeafda2359e6'
        ,'{"Values":[{ "Culture":"ca","Data":"Operació de Fons"},{ "Culture":"es","Data":"Operación de Fondo"},{ "Culture":"it","Data":"Dolototoperazione"},{ "Culture":"pt","Data":"Operação de Fundo"},{ "Culture":"en","Data":"BackgroundOperation"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: BackgroundOperationsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'BackgroundOperationsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[BackgroundOperationsQuery]
GO

CREATE FUNCTION  [CorePatterns].[BackgroundOperationsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [CorePatterns].[BackgroundOperationsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.ExtensibilityViewDefinitionsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.ExtensibilityViewDefinitionsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '9f82e5ce-3c64-4239-aa19-3e59b4e44937')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '9f82e5ce-3c64-4239-aa19-3e59b4e44937'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '9f82e5ce-3c64-4239-aa19-3e59b4e44937'
    ,'CorePatterns'
    ,'ExtensibilityViewDefinitions'
    ,'ExtensibilityViewDefinitionsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Definició de la vista d''''extensibilitat"},{ "Culture":"es","Data":"Definición de Vista de Extensibilidad"},{ "Culture":"it","Data":"Definizione della vista di estensibilità"},{ "Culture":"pt","Data":"Definição da Vista de Extensibilidade"},{ "Culture":"en","Data":"Extensibility View Definition"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Definició de la visualització d''''extensibilitat)"},{ "Culture":"es","Data":"(Definición de Vista de Extensibilidad)"},{ "Culture":"it","Data":"(Definizione della vista di estensibilità)"},{ "Culture":"pt","Data":"(Definição da Vista de Extensibilidade)"},{ "Culture":"en","Data":"(Extensibility View Definition)"}]}'
    ,1
    ,'9f82e5ce-3c64-4239-aa19-3e59b4e44937'
    ,'9f82e5ce-3c64-4239-aa19-3e59b4e44937'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '91c8c175-292a-d3f3-dc4e-8228ddee277f'
        ,'{"Values":[{ "Culture":"ca","Data":"Definició de la vista d''''extensibilitat"},{ "Culture":"es","Data":"Definición de Vista de Extensibilidad"},{ "Culture":"it","Data":"Definizione della vista di estensibilità"},{ "Culture":"pt","Data":"Definição da Vista de Extensibilidade"},{ "Culture":"en","Data":"Extensibility View Definition"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'9f82e5ce-3c64-4239-aa19-3e59b4e44937'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: ExtensibilityViewDefinitionsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'ExtensibilityViewDefinitionsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[ExtensibilityViewDefinitionsQuery]
GO

CREATE FUNCTION  [CorePatterns].[ExtensibilityViewDefinitionsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [CorePatterns].[ExtensibilityViewDefinitionsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.CustomEntitiesLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.CustomEntitiesLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '0389b827-f2c8-4186-8a0d-bc707bbcb724')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '0389b827-f2c8-4186-8a0d-bc707bbcb724'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '0389b827-f2c8-4186-8a0d-bc707bbcb724'
    ,'CorePatterns'
    ,'SchemaEntities'
    ,'CustomEntitiesLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Entitat"},{ "Culture":"es","Data":"Entidad"},{ "Culture":"it","Data":"Entità"},{ "Culture":"pt","Data":"Entidade"},{ "Culture":"en","Data":"Entity"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Entitat)"},{ "Culture":"es","Data":"(Entidad)"},{ "Culture":"it","Data":"(Entità)"},{ "Culture":"pt","Data":"(Entidade)"},{ "Culture":"en","Data":"(Entity)"}]}'
    ,1
    ,'f5ce031f-fa96-4c2c-8d44-d71f621e9232'
    ,'0389b827-f2c8-4186-8a0d-bc707bbcb724'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '96ea0945-3f03-4001-a6db-3b359cbf079b'
        ,'{"Values":[{ "Culture":"ca","Data":"Entitat"},{ "Culture":"es","Data":"Entidad"},{ "Culture":"it","Data":"Entità"},{ "Culture":"pt","Data":"Entidade"},{ "Culture":"en","Data":"Entity"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'0389b827-f2c8-4186-8a0d-bc707bbcb724'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'CustomEntitiesQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[CustomEntitiesQuery]
GO

CREATE FUNCTION  [CorePatterns].[CustomEntitiesQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [CorePatterns].[SchemaEntitiesView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.StandardSequencesLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.StandardSequencesLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '8d9a0d42-88d5-4fb1-976c-72664da22d6c')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '8d9a0d42-88d5-4fb1-976c-72664da22d6c'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '8d9a0d42-88d5-4fb1-976c-72664da22d6c'
    ,'CorePatterns'
    ,'Sequences'
    ,'StandardSequencesLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Seqüència"},{ "Culture":"es","Data":"Secuencia"},{ "Culture":"it","Data":"Sequenza"},{ "Culture":"pt","Data":"Sequência"},{ "Culture":"en","Data":"Sequence"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Seqüència, Descripció)"},{ "Culture":"es","Data":"(Secuencia, Descripción)"},{ "Culture":"it","Data":"(Sequenza, descrizione)"},{ "Culture":"pt","Data":"(Sequência, Descrição)"},{ "Culture":"en","Data":"(Sequence, Description)"}]}'
    ,1
    ,'8ad32e65-0a68-40b8-a804-3ba4ffcfb3b2'
    ,'8d9a0d42-88d5-4fb1-976c-72664da22d6c'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'bb323c77-e06a-7149-b163-0c636b9c27a1'
        ,'{"Values":[{ "Culture":"ca","Data":"Seqüència"},{ "Culture":"es","Data":"Secuencia"},{ "Culture":"it","Data":"Sequenza"},{ "Culture":"pt","Data":"Sequência"},{ "Culture":"en","Data":"Sequence"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'8d9a0d42-88d5-4fb1-976c-72664da22d6c'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: Description (Description) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'b6d41915-50cd-a40a-95e4-2bc059fb6844'
        ,'{"Values":[{ "Culture":"ca","Data":"Descripció"},{ "Culture":"es","Data":"Descripción"},{ "Culture":"it","Data":"Descrizione"},{ "Culture":"pt","Data":"Descrição"},{ "Culture":"en","Data":"Description"}]}'
        ,'True'
        ,'False'
        ,1
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'8d9a0d42-88d5-4fb1-976c-72664da22d6c'
        ,0
        ,0
        ,1
        ,'Description'
        ,'Description'
        ,'True'
        )
GO

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'StandardSequencesQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[StandardSequencesQuery]
GO

CREATE FUNCTION  [CorePatterns].[StandardSequencesQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey], [T1].[Description] AS [Description]
FROM [CorePatterns].[SequencesView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[Description] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.DraftDataLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.DraftDataLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '5faf9e86-15a7-4b83-81c2-c83b629a5a80')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '5faf9e86-15a7-4b83-81c2-c83b629a5a80'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '5faf9e86-15a7-4b83-81c2-c83b629a5a80'
    ,'CorePatterns'
    ,'Drafts'
    ,'DraftDataLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Esborrany"},{ "Culture":"es","Data":"Borrador"},{ "Culture":"it","Data":"Brutta copia"},{ "Culture":"pt","Data":"Rascunho"},{ "Culture":"en","Data":"Draft"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Esborrany)"},{ "Culture":"es","Data":"(Borrador)"},{ "Culture":"it","Data":"(Brutta copia)"},{ "Culture":"pt","Data":"(Rascunho)"},{ "Culture":"en","Data":"(Draft)"}]}'
    ,1
    ,'53df104a-4746-4f4f-ba26-c1b69c217675'
    ,'5faf9e86-15a7-4b83-81c2-c83b629a5a80'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'a65676fe-8eec-eab9-f9cd-e9685424e5c1'
        ,'{"Values":[{ "Culture":"ca","Data":"Esborrany"},{ "Culture":"es","Data":"Borrador"},{ "Culture":"it","Data":"Brutta copia"},{ "Culture":"pt","Data":"Rascunho"},{ "Culture":"en","Data":"Draft"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'5faf9e86-15a7-4b83-81c2-c83b629a5a80'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'DraftDataQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[DraftDataQuery]
GO

CREATE FUNCTION  [CorePatterns].[DraftDataQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [CorePatterns].[DraftsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO


-- Associations Lookups


-- Association Lookup: CustomEntity_SchemaEntitiesForAssociationsTargetQuery (SchemaEntities | CustomEntity | (Associations) SchemaEntitiesAssociation.Target)

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'CustomEntity_SchemaEntitiesForAssociationsTargetQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[CustomEntity_SchemaEntitiesForAssociationsTargetQuery]
GO

CREATE FUNCTION  [CorePatterns].[CustomEntity_SchemaEntitiesForAssociationsTargetQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].SchemaEntitiesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO


-- Association Lookup: CustomEntity_SchemaAttributesForAssociationsAttributeQuery (SchemaEntities | CustomEntity | (Associations) SchemaEntitiesAssociation.Attribute)

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'CustomEntity_SchemaAttributesForAssociationsAttributeQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[CustomEntity_SchemaAttributesForAssociationsAttributeQuery]
GO

CREATE FUNCTION  [CorePatterns].[CustomEntity_SchemaAttributesForAssociationsAttributeQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].SchemaAttributesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO


-- CorePatterns.Verify_CustomEntity_SchemaEntitiesForAssociationsTargetQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_CustomEntity_SchemaEntitiesForAssociationsTargetQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_CustomEntity_SchemaEntitiesForAssociationsTargetQuery]
GO

-- [CorePatterns].Verify_CustomEntity_SchemaEntitiesForAssociationsTargetQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_CustomEntity_SchemaEntitiesForAssociationsTargetQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_CustomEntity_SchemaEntitiesForAssociationsTargetQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_CustomEntity_SchemaEntitiesForAssociationsTargetQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_CustomEntity_SchemaEntitiesForAssociationsTargetQuery

CREATE FUNCTION [CorePatterns].[Verify_CustomEntity_SchemaEntitiesForAssociationsTargetQuery] (
     @List AS [CorePatterns].Verify_CustomEntity_SchemaEntitiesForAssociationsTargetQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[CustomEntity_SchemaEntitiesForAssociationsTargetQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- CorePatterns.Verify_CustomEntity_SchemaAttributesForAssociationsAttributeQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_CustomEntity_SchemaAttributesForAssociationsAttributeQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_CustomEntity_SchemaAttributesForAssociationsAttributeQuery]
GO

-- [CorePatterns].Verify_CustomEntity_SchemaAttributesForAssociationsAttributeQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_CustomEntity_SchemaAttributesForAssociationsAttributeQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_CustomEntity_SchemaAttributesForAssociationsAttributeQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_CustomEntity_SchemaAttributesForAssociationsAttributeQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_CustomEntity_SchemaAttributesForAssociationsAttributeQuery

CREATE FUNCTION [CorePatterns].[Verify_CustomEntity_SchemaAttributesForAssociationsAttributeQuery] (
     @List AS [CorePatterns].Verify_CustomEntity_SchemaAttributesForAssociationsAttributeQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[CustomEntity_SchemaAttributesForAssociationsAttributeQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


	-- Association Lookup: SchemaAttribute_SchemaEntitiesForSchemaEntityQuery (SchemaAttributes | SchemaAttribute | SchemaAttribute.SchemaEntity)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'SchemaAttribute_SchemaEntitiesForSchemaEntityQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[SchemaAttribute_SchemaEntitiesForSchemaEntityQuery]
GO

	CREATE FUNCTION  [CorePatterns].[SchemaAttribute_SchemaEntitiesForSchemaEntityQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].SchemaEntitiesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
	-- Association Lookup: SchemaAttribute_SchemaEntitiesForLookupEntityQuery (SchemaAttributes | SchemaAttribute | SchemaAttribute.LookupEntity)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'SchemaAttribute_SchemaEntitiesForLookupEntityQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[SchemaAttribute_SchemaEntitiesForLookupEntityQuery]
GO

	CREATE FUNCTION  [CorePatterns].[SchemaAttribute_SchemaEntitiesForLookupEntityQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].SchemaEntitiesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- CorePatterns.Verify_SchemaAttribute_SchemaEntitiesForSchemaEntityQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_SchemaAttribute_SchemaEntitiesForSchemaEntityQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_SchemaAttribute_SchemaEntitiesForSchemaEntityQuery]
GO

-- [CorePatterns].Verify_SchemaAttribute_SchemaEntitiesForSchemaEntityQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_SchemaAttribute_SchemaEntitiesForSchemaEntityQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_SchemaAttribute_SchemaEntitiesForSchemaEntityQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_SchemaAttribute_SchemaEntitiesForSchemaEntityQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_SchemaAttribute_SchemaEntitiesForSchemaEntityQuery

CREATE FUNCTION [CorePatterns].[Verify_SchemaAttribute_SchemaEntitiesForSchemaEntityQuery] (
     @List AS [CorePatterns].Verify_SchemaAttribute_SchemaEntitiesForSchemaEntityQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[SchemaAttribute_SchemaEntitiesForSchemaEntityQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- CorePatterns.Verify_SchemaAttribute_SchemaEntitiesForLookupEntityQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_SchemaAttribute_SchemaEntitiesForLookupEntityQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_SchemaAttribute_SchemaEntitiesForLookupEntityQuery]
GO

-- [CorePatterns].Verify_SchemaAttribute_SchemaEntitiesForLookupEntityQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_SchemaAttribute_SchemaEntitiesForLookupEntityQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_SchemaAttribute_SchemaEntitiesForLookupEntityQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_SchemaAttribute_SchemaEntitiesForLookupEntityQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_SchemaAttribute_SchemaEntitiesForLookupEntityQuery

CREATE FUNCTION [CorePatterns].[Verify_SchemaAttribute_SchemaEntitiesForLookupEntityQuery] (
     @List AS [CorePatterns].Verify_SchemaAttribute_SchemaEntitiesForLookupEntityQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[SchemaAttribute_SchemaEntitiesForLookupEntityQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


	-- Association Lookup: DocumentCopyLabel_CulturesForCultureQuery (DocumentCopyLabels | DocumentCopyLabel | DocumentCopyLabel.Culture)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'DocumentCopyLabel_CulturesForCultureQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[DocumentCopyLabel_CulturesForCultureQuery]
GO

	CREATE FUNCTION  [CorePatterns].[DocumentCopyLabel_CulturesForCultureQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].CulturesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- CorePatterns.Verify_DocumentCopyLabel_CulturesForCultureQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_DocumentCopyLabel_CulturesForCultureQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_DocumentCopyLabel_CulturesForCultureQuery]
GO

-- [CorePatterns].Verify_DocumentCopyLabel_CulturesForCultureQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_DocumentCopyLabel_CulturesForCultureQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_DocumentCopyLabel_CulturesForCultureQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_DocumentCopyLabel_CulturesForCultureQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_DocumentCopyLabel_CulturesForCultureQuery

CREATE FUNCTION [CorePatterns].[Verify_DocumentCopyLabel_CulturesForCultureQuery] (
     @List AS [CorePatterns].Verify_DocumentCopyLabel_CulturesForCultureQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[DocumentCopyLabel_CulturesForCultureQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- Association Lookup: Calendar_CalendarEventTypesForCalendarEventsCalendarEventTypeQuery (Calendars | Calendar | (CalendarEvents) CalendarEvent.CalendarEventType)

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'Calendar_CalendarEventTypesForCalendarEventsCalendarEventTypeQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[Calendar_CalendarEventTypesForCalendarEventsCalendarEventTypeQuery]
GO

CREATE FUNCTION  [CorePatterns].[Calendar_CalendarEventTypesForCalendarEventsCalendarEventTypeQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].CalendarEventTypesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO


-- CorePatterns.Verify_Calendar_CalendarEventTypesForCalendarEventsCalendarEventTypeQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_Calendar_CalendarEventTypesForCalendarEventsCalendarEventTypeQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_Calendar_CalendarEventTypesForCalendarEventsCalendarEventTypeQuery]
GO

-- [CorePatterns].Verify_Calendar_CalendarEventTypesForCalendarEventsCalendarEventTypeQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_Calendar_CalendarEventTypesForCalendarEventsCalendarEventTypeQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_Calendar_CalendarEventTypesForCalendarEventsCalendarEventTypeQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_Calendar_CalendarEventTypesForCalendarEventsCalendarEventTypeQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_Calendar_CalendarEventTypesForCalendarEventsCalendarEventTypeQuery

CREATE FUNCTION [CorePatterns].[Verify_Calendar_CalendarEventTypesForCalendarEventsCalendarEventTypeQuery] (
     @List AS [CorePatterns].Verify_Calendar_CalendarEventTypesForCalendarEventsCalendarEventTypeQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[Calendar_CalendarEventTypesForCalendarEventsCalendarEventTypeQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


	-- Association Lookup: SchemaEntityState_SchemaEntitiesForSchemaEntityQuery (SchemaEntityStates | SchemaEntityState | SchemaEntityState.SchemaEntity)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'SchemaEntityState_SchemaEntitiesForSchemaEntityQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[SchemaEntityState_SchemaEntitiesForSchemaEntityQuery]
GO

	CREATE FUNCTION  [CorePatterns].[SchemaEntityState_SchemaEntitiesForSchemaEntityQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].SchemaEntitiesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- Association Lookup: SchemaEntityState_SchemaEntityStatesForSchemaEntityStateTransitionsTargetEntityStateQuery (SchemaEntityStates | SchemaEntityState | (SchemaEntityStateTransitions) SchemaEntityStateTransition.TargetEntityState)

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'SchemaEntityState_SchemaEntityStatesForSchemaEntityStateTransitionsTargetEntityStateQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[SchemaEntityState_SchemaEntityStatesForSchemaEntityStateTransitionsTargetEntityStateQuery]
GO

CREATE FUNCTION  [CorePatterns].[SchemaEntityState_SchemaEntityStatesForSchemaEntityStateTransitionsTargetEntityStateQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].SchemaEntityStatesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO


-- CorePatterns.Verify_SchemaEntityState_SchemaEntitiesForSchemaEntityQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_SchemaEntityState_SchemaEntitiesForSchemaEntityQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_SchemaEntityState_SchemaEntitiesForSchemaEntityQuery]
GO

-- [CorePatterns].Verify_SchemaEntityState_SchemaEntitiesForSchemaEntityQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_SchemaEntityState_SchemaEntitiesForSchemaEntityQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_SchemaEntityState_SchemaEntitiesForSchemaEntityQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_SchemaEntityState_SchemaEntitiesForSchemaEntityQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_SchemaEntityState_SchemaEntitiesForSchemaEntityQuery

CREATE FUNCTION [CorePatterns].[Verify_SchemaEntityState_SchemaEntitiesForSchemaEntityQuery] (
     @List AS [CorePatterns].Verify_SchemaEntityState_SchemaEntitiesForSchemaEntityQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[SchemaEntityState_SchemaEntitiesForSchemaEntityQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- CorePatterns.Verify_SchemaEntityState_SchemaEntityStatesForSchemaEntityStateTransitionsTargetEntityStateQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_SchemaEntityState_SchemaEntityStatesForSchemaEntityStateTransitionsTargetEntityStateQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_SchemaEntityState_SchemaEntityStatesForSchemaEntityStateTransitionsTargetEntityStateQuery]
GO

-- [CorePatterns].Verify_SchemaEntityState_SchemaEntityStatesForSchemaEntityStateTransitionsTargetEntityStateQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_SchemaEntityState_SchemaEntityStatesForSchemaEntityStateTransitionsTargetEntityStateQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_SchemaEntityState_SchemaEntityStatesForSchemaEntityStateTransitionsTargetEntityStateQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_SchemaEntityState_SchemaEntityStatesForSchemaEntityStateTransitionsTargetEntityStateQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_SchemaEntityState_SchemaEntityStatesForSchemaEntityStateTransitionsTargetEntityStateQuery

CREATE FUNCTION [CorePatterns].[Verify_SchemaEntityState_SchemaEntityStatesForSchemaEntityStateTransitionsTargetEntityStateQuery] (
     @List AS [CorePatterns].Verify_SchemaEntityState_SchemaEntityStatesForSchemaEntityStateTransitionsTargetEntityStateQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[SchemaEntityState_SchemaEntityStatesForSchemaEntityStateTransitionsTargetEntityStateQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


	-- Association Lookup: StandardSequence_SchemaEntitiesForEntityQuery (Sequences | StandardSequence | Sequence.Entity)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'StandardSequence_SchemaEntitiesForEntityQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[StandardSequence_SchemaEntitiesForEntityQuery]
GO

	CREATE FUNCTION  [CorePatterns].[StandardSequence_SchemaEntitiesForEntityQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [SRC].[Id], [SRC].[NaturalKey]
FROM (SELECT [T].[Id], [T].[NaturalKey] AS [NaturalKey], [T].[HasSequenceAttribute] AS [HasSequenceAttribute]
FROM [CorePatterns].SchemaEntitiesQuery(@searchTerm, @user, @culture) [T1]
JOIN [CorePatterns].[SchemaEntitiesView] [T] ON [T1].[Id] = [T].[Id]
WHERE [T].[IsActive] = 1) [SRC]
WHERE HasSequenceAttribute = 1)
GO

	
	-- Association Lookup: StandardSequence_SchemaAttributesForEntityAttributeQuery (Sequences | StandardSequence | Sequence.EntityAttribute)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'StandardSequence_SchemaAttributesForEntityAttributeQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[StandardSequence_SchemaAttributesForEntityAttributeQuery]
GO

	CREATE FUNCTION  [CorePatterns].[StandardSequence_SchemaAttributesForEntityAttributeQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL', @SchemaEntityId UNIQUEIDENTIFIER  = '')
RETURNS TABLE
AS
RETURN
(SELECT [SRC].[Id], [SRC].[NaturalKey], [SRC].[Key]
FROM (SELECT [T].[Id], [T].[NaturalKey] AS [NaturalKey], [T].[Key] AS [Key], [T].[IsSequenceManaged] AS [IsSequenceManaged], [T3].[Key] AS [SchemaEntityKey]
FROM [CorePatterns].SchemaAttributesQuery(@searchTerm, @user, @culture) [T1]
JOIN [CorePatterns].[SchemaAttributesView] [T] ON [T1].[Id] = [T].[Id]
LEFT JOIN [CorePatterns].[SchemaEntitiesView] [T3] ON [T].[SchemaEntityId] = [T3].[Id]
WHERE [T].[IsActive] = 1) [SRC]
WHERE IsSequenceManaged = 1 AND 
(Id in 
(SELECT Id FROM [CorePatterns].[SchemaAttributes] WHERE [SchemaEntityId] = @SchemaEntityId)))
GO

	
-- Association Lookup: StandardSequence_SchemaEntitiesForSequenceLinesEntityQuery (Sequences | StandardSequence | (SequenceLines) SequenceLine.Entity)

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'StandardSequence_SchemaEntitiesForSequenceLinesEntityQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[StandardSequence_SchemaEntitiesForSequenceLinesEntityQuery]
GO

CREATE FUNCTION  [CorePatterns].[StandardSequence_SchemaEntitiesForSequenceLinesEntityQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL', @SchemaEntityId UNIQUEIDENTIFIER  = '')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM (SELECT [T].[Id], [T].[NaturalKey] AS [NaturalKey]
FROM [CorePatterns].SchemaEntitiesQuery(@searchTerm, @user, @culture) [T1]
JOIN [CorePatterns].[SchemaEntitiesView] [T] ON [T1].[Id] = [T].[Id]
WHERE [T].[IsActive] = 1) [SRC]
WHERE Id in (
SELECT SEA.TargetId
FROM [COREPATTERNS].[SCHEMAENTITIESASSOCIATIONS] SEA
  INNER JOIN [COREPATTERNS].[SCHEMAATTRIBUTES] SA ON SA.ID = SEA.ATTRIBUTEID
  WHERE SEA.SCHEMAENTITYID = @SchemaEntityId
  AND ISCOMPOSITION = 0))
GO


-- Association Lookup: StandardSequence_SchemaAttributesForSequenceLinesEntityAttributeQuery (Sequences | StandardSequence | (SequenceLines) SequenceLine.EntityAttribute)

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'StandardSequence_SchemaAttributesForSequenceLinesEntityAttributeQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[StandardSequence_SchemaAttributesForSequenceLinesEntityAttributeQuery]
GO

CREATE FUNCTION  [CorePatterns].[StandardSequence_SchemaAttributesForSequenceLinesEntityAttributeQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL', @SchemaEntityId UNIQUEIDENTIFIER  = '')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM (SELECT [T].[Id], [T].[NaturalKey] AS [NaturalKey], [T].[Key] AS [Key]
FROM [CorePatterns].SchemaAttributesQuery(@searchTerm, @user, @culture) [T1]
JOIN [CorePatterns].[SchemaAttributesView] [T] ON [T1].[Id] = [T].[Id]
WHERE [T].[IsActive] = 1) [SRC]
WHERE (Id in 
  (  
     SELECT Id 
     FROM [CorePatterns].[SchemaAttributes] 
     WHERE [SchemaEntityId] = @SchemaEntityId 
     AND [AttributeType] in ('ShortText', 'Text', 'LongText')
     AND [IsSystemBase] <> 1
  )
))
GO


-- CorePatterns.Verify_StandardSequence_SchemaEntitiesForEntityQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_StandardSequence_SchemaEntitiesForEntityQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_StandardSequence_SchemaEntitiesForEntityQuery]
GO

-- [CorePatterns].Verify_StandardSequence_SchemaEntitiesForEntityQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_StandardSequence_SchemaEntitiesForEntityQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_StandardSequence_SchemaEntitiesForEntityQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_StandardSequence_SchemaEntitiesForEntityQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_StandardSequence_SchemaEntitiesForEntityQuery

CREATE FUNCTION [CorePatterns].[Verify_StandardSequence_SchemaEntitiesForEntityQuery] (
     @List AS [CorePatterns].Verify_StandardSequence_SchemaEntitiesForEntityQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[StandardSequence_SchemaEntitiesForEntityQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- CorePatterns.Verify_StandardSequence_SchemaAttributesForEntityAttributeQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_StandardSequence_SchemaAttributesForEntityAttributeQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_StandardSequence_SchemaAttributesForEntityAttributeQuery]
GO

-- [CorePatterns].Verify_StandardSequence_SchemaAttributesForEntityAttributeQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_StandardSequence_SchemaAttributesForEntityAttributeQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_StandardSequence_SchemaAttributesForEntityAttributeQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_StandardSequence_SchemaAttributesForEntityAttributeQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
	,SchemaEntityId uniqueidentifier DEFAULT(NULL)
);
GO

-- CorePatterns.Verify_StandardSequence_SchemaAttributesForEntityAttributeQuery

CREATE FUNCTION [CorePatterns].[Verify_StandardSequence_SchemaAttributesForEntityAttributeQuery] (
     @List AS [CorePatterns].Verify_StandardSequence_SchemaAttributesForEntityAttributeQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[StandardSequence_SchemaAttributesForEntityAttributeQuery](List.NaturalKey, @User, @Culture,List.SchemaEntityId)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- CorePatterns.Verify_StandardSequence_SchemaEntitiesForSequenceLinesEntityQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_StandardSequence_SchemaEntitiesForSequenceLinesEntityQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_StandardSequence_SchemaEntitiesForSequenceLinesEntityQuery]
GO

-- [CorePatterns].Verify_StandardSequence_SchemaEntitiesForSequenceLinesEntityQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_StandardSequence_SchemaEntitiesForSequenceLinesEntityQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_StandardSequence_SchemaEntitiesForSequenceLinesEntityQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_StandardSequence_SchemaEntitiesForSequenceLinesEntityQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
	,SchemaEntityId uniqueidentifier DEFAULT(NULL)
);
GO

-- CorePatterns.Verify_StandardSequence_SchemaEntitiesForSequenceLinesEntityQuery

CREATE FUNCTION [CorePatterns].[Verify_StandardSequence_SchemaEntitiesForSequenceLinesEntityQuery] (
     @List AS [CorePatterns].Verify_StandardSequence_SchemaEntitiesForSequenceLinesEntityQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[StandardSequence_SchemaEntitiesForSequenceLinesEntityQuery](List.NaturalKey, @User, @Culture,List.SchemaEntityId)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- CorePatterns.Verify_StandardSequence_SchemaAttributesForSequenceLinesEntityAttributeQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_StandardSequence_SchemaAttributesForSequenceLinesEntityAttributeQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_StandardSequence_SchemaAttributesForSequenceLinesEntityAttributeQuery]
GO

-- [CorePatterns].Verify_StandardSequence_SchemaAttributesForSequenceLinesEntityAttributeQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_StandardSequence_SchemaAttributesForSequenceLinesEntityAttributeQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_StandardSequence_SchemaAttributesForSequenceLinesEntityAttributeQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_StandardSequence_SchemaAttributesForSequenceLinesEntityAttributeQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
	,SchemaEntityId uniqueidentifier DEFAULT(NULL)
);
GO

-- CorePatterns.Verify_StandardSequence_SchemaAttributesForSequenceLinesEntityAttributeQuery

CREATE FUNCTION [CorePatterns].[Verify_StandardSequence_SchemaAttributesForSequenceLinesEntityAttributeQuery] (
     @List AS [CorePatterns].Verify_StandardSequence_SchemaAttributesForSequenceLinesEntityAttributeQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[StandardSequence_SchemaAttributesForSequenceLinesEntityAttributeQuery](List.NaturalKey, @User, @Culture,List.SchemaEntityId)
         ) AS [MatchId]
    FROM @List AS List
)
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.Sequences_SchemaEntitiesForEntityLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.Sequences_SchemaEntitiesForEntityLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= 'd79f5ae4-9d59-468e-b222-6322061e9fdf')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= 'd79f5ae4-9d59-468e-b222-6322061e9fdf'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    'd79f5ae4-9d59-468e-b222-6322061e9fdf'
    ,'CorePatterns'
    ,'Sequences'
    ,'Sequences_SchemaEntitiesForEntityLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Entitat"},{ "Culture":"es","Data":"Entidad"},{ "Culture":"it","Data":"Entità"},{ "Culture":"pt","Data":"Entidade"},{ "Culture":"en","Data":"Entity"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Seqüència, Descripció)"},{ "Culture":"es","Data":"(Secuencia, Descripción)"},{ "Culture":"it","Data":"(Entità)"},{ "Culture":"pt","Data":"(Sequência, Descrição)"},{ "Culture":"en","Data":"(Entity)"}]}'
    ,1
    ,'f5ce031f-fa96-4c2c-8d44-d71f621e9232'
    ,'d79f5ae4-9d59-468e-b222-6322061e9fdf'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '6f818b42-697b-3fc4-b60b-457c89110b00'
        ,'{"Values":[{ "Culture":"ca","Data":"Entitat"},{ "Culture":"es","Data":"Entidad"},{ "Culture":"it","Data":"Entità"},{ "Culture":"pt","Data":"Entidade"},{ "Culture":"en","Data":"Entity"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'d79f5ae4-9d59-468e-b222-6322061e9fdf'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.Sequences_SchemaAttributesForEntityAttributeLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.Sequences_SchemaAttributesForEntityAttributeLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= 'bd260329-a7df-4251-ba0d-44ee53342ae0')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= 'bd260329-a7df-4251-ba0d-44ee53342ae0'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    'bd260329-a7df-4251-ba0d-44ee53342ae0'
    ,'CorePatterns'
    ,'Sequences'
    ,'Sequences_SchemaAttributesForEntityAttributeLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Atribut de l''Entitat"},{ "Culture":"es","Data":"Atributo de la Entidad"},{ "Culture":"it","Data":"Attributo di entità"},{ "Culture":"pt","Data":"Atributo da Entidade"},{ "Culture":"en","Data":"Entity Attribute"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Atribut de l''Entitat, Clau)"},{ "Culture":"es","Data":"(Atributo de la Entidad, Clave)"},{ "Culture":"it","Data":"(Attributo entità, chiave)"},{ "Culture":"pt","Data":"(Atributo da Entidade, Chave)"},{ "Culture":"en","Data":"(Entity Attribute, Key)"}]}'
    ,1
    ,'e4a3809e-663d-4fbd-82ac-b5b25a95fc4b'
    ,'bd260329-a7df-4251-ba0d-44ee53342ae0'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'cf8250dc-bed7-ce03-4524-5cef4253ee2b'
        ,'{"Values":[{ "Culture":"ca","Data":"Atribut de l''Entitat"},{ "Culture":"es","Data":"Atributo de la Entidad"},{ "Culture":"it","Data":"Attributo di entità"},{ "Culture":"pt","Data":"Atributo da Entidade"},{ "Culture":"en","Data":"Entity Attribute"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'bd260329-a7df-4251-ba0d-44ee53342ae0'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: Key (Key) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '913ed410-16f2-2323-3d7a-e7c9149b071e'
        ,'{"Values":[{ "Culture":"ca","Data":"Clau"},{ "Culture":"es","Data":"Clave"},{ "Culture":"it","Data":"Chiave"},{ "Culture":"pt","Data":"Chave"},{ "Culture":"en","Data":"Key"}]}'
        ,'True'
        ,'False'
        ,1
        ,'Text'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'bd260329-a7df-4251-ba0d-44ee53342ae0'
        ,0
        ,0
        ,1
        ,'Key'
        ,'Key'
        ,'True'
        )
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.Sequences_SchemaEntitiesForSequenceLinesEntityLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.Sequences_SchemaEntitiesForSequenceLinesEntityLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '053e4426-b8ef-40c2-ba7c-e9ed192fb3e9')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '053e4426-b8ef-40c2-ba7c-e9ed192fb3e9'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '053e4426-b8ef-40c2-ba7c-e9ed192fb3e9'
    ,'CorePatterns'
    ,'Sequences'
    ,'Sequences_SchemaEntitiesForSequenceLinesEntityLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Entitat"},{ "Culture":"es","Data":"Entidad"},{ "Culture":"it","Data":"Entità"},{ "Culture":"pt","Data":"Entidade"},{ "Culture":"en","Data":"Entity"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Seqüència, Descripció)"},{ "Culture":"es","Data":"(Secuencia, Descripción)"},{ "Culture":"it","Data":"(Entità)"},{ "Culture":"pt","Data":"(Sequência, Descrição)"},{ "Culture":"en","Data":"(Entity)"}]}'
    ,1
    ,'f5ce031f-fa96-4c2c-8d44-d71f621e9232'
    ,'053e4426-b8ef-40c2-ba7c-e9ed192fb3e9'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '53cb3f0f-0c7c-9d75-9358-e1b0851da04f'
        ,'{"Values":[{ "Culture":"ca","Data":"Entitat"},{ "Culture":"es","Data":"Entidad"},{ "Culture":"it","Data":"Entità"},{ "Culture":"pt","Data":"Entidade"},{ "Culture":"en","Data":"Entity"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'053e4426-b8ef-40c2-ba7c-e9ed192fb3e9'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.Sequences_SchemaAttributesForSequenceLinesEntityAttributeLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.Sequences_SchemaAttributesForSequenceLinesEntityAttributeLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= 'fda33323-45b7-46d3-ae58-db317ad21e93')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= 'fda33323-45b7-46d3-ae58-db317ad21e93'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    'fda33323-45b7-46d3-ae58-db317ad21e93'
    ,'CorePatterns'
    ,'Sequences'
    ,'Sequences_SchemaAttributesForSequenceLinesEntityAttributeLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Atribut de l''Entitat"},{ "Culture":"es","Data":"Atributo de la Entidad"},{ "Culture":"it","Data":"Attributo di entità"},{ "Culture":"pt","Data":"Atributo da Entidade"},{ "Culture":"en","Data":"Entity Attribute"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Atribut de l''Entitat, Clau)"},{ "Culture":"es","Data":"(Atributo de la Entidad, Clave)"},{ "Culture":"it","Data":"(Attributo entità, chiave)"},{ "Culture":"pt","Data":"(Atributo da Entidade, Chave)"},{ "Culture":"en","Data":"(Entity Attribute, Key)"}]}'
    ,1
    ,'e4a3809e-663d-4fbd-82ac-b5b25a95fc4b'
    ,'fda33323-45b7-46d3-ae58-db317ad21e93'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'bc5934b6-dcaa-9051-00af-a4acd12ea0bc'
        ,'{"Values":[{ "Culture":"ca","Data":"Atribut de l''Entitat"},{ "Culture":"es","Data":"Atributo de la Entidad"},{ "Culture":"it","Data":"Attributo di entità"},{ "Culture":"pt","Data":"Atributo da Entidade"},{ "Culture":"en","Data":"Entity Attribute"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'fda33323-45b7-46d3-ae58-db317ad21e93'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: Key (Key) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '50414ee2-c563-9b13-cfd1-8641706129f5'
        ,'{"Values":[{ "Culture":"ca","Data":"Clau"},{ "Culture":"es","Data":"Clave"},{ "Culture":"it","Data":"Chiave"},{ "Culture":"pt","Data":"Chave"},{ "Culture":"en","Data":"Key"}]}'
        ,'True'
        ,'False'
        ,1
        ,'Text'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'fda33323-45b7-46d3-ae58-db317ad21e93'
        ,0
        ,0
        ,1
        ,'Key'
        ,'Key'
        ,'True'
        )
GO


	-- Association Lookup: SchemaEntityExtension_SchemaEntitiesForBaseEntityQuery (SchemaEntityExtensions | SchemaEntityExtension | SchemaEntityExtension.BaseEntity)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'SchemaEntityExtension_SchemaEntitiesForBaseEntityQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[SchemaEntityExtension_SchemaEntitiesForBaseEntityQuery]
GO

	CREATE FUNCTION  [CorePatterns].[SchemaEntityExtension_SchemaEntitiesForBaseEntityQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].SchemaEntitiesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
	-- Association Lookup: SchemaEntityExtension_SchemaEntitiesForExtensionEntityQuery (SchemaEntityExtensions | SchemaEntityExtension | SchemaEntityExtension.ExtensionEntity)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'SchemaEntityExtension_SchemaEntitiesForExtensionEntityQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[SchemaEntityExtension_SchemaEntitiesForExtensionEntityQuery]
GO

	CREATE FUNCTION  [CorePatterns].[SchemaEntityExtension_SchemaEntitiesForExtensionEntityQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].SchemaEntitiesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- CorePatterns.Verify_SchemaEntityExtension_SchemaEntitiesForBaseEntityQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_SchemaEntityExtension_SchemaEntitiesForBaseEntityQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_SchemaEntityExtension_SchemaEntitiesForBaseEntityQuery]
GO

-- [CorePatterns].Verify_SchemaEntityExtension_SchemaEntitiesForBaseEntityQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_SchemaEntityExtension_SchemaEntitiesForBaseEntityQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_SchemaEntityExtension_SchemaEntitiesForBaseEntityQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_SchemaEntityExtension_SchemaEntitiesForBaseEntityQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_SchemaEntityExtension_SchemaEntitiesForBaseEntityQuery

CREATE FUNCTION [CorePatterns].[Verify_SchemaEntityExtension_SchemaEntitiesForBaseEntityQuery] (
     @List AS [CorePatterns].Verify_SchemaEntityExtension_SchemaEntitiesForBaseEntityQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[SchemaEntityExtension_SchemaEntitiesForBaseEntityQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- CorePatterns.Verify_SchemaEntityExtension_SchemaEntitiesForExtensionEntityQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_SchemaEntityExtension_SchemaEntitiesForExtensionEntityQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_SchemaEntityExtension_SchemaEntitiesForExtensionEntityQuery]
GO

-- [CorePatterns].Verify_SchemaEntityExtension_SchemaEntitiesForExtensionEntityQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_SchemaEntityExtension_SchemaEntitiesForExtensionEntityQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_SchemaEntityExtension_SchemaEntitiesForExtensionEntityQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_SchemaEntityExtension_SchemaEntitiesForExtensionEntityQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_SchemaEntityExtension_SchemaEntitiesForExtensionEntityQuery

CREATE FUNCTION [CorePatterns].[Verify_SchemaEntityExtension_SchemaEntitiesForExtensionEntityQuery] (
     @List AS [CorePatterns].Verify_SchemaEntityExtension_SchemaEntitiesForExtensionEntityQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[SchemaEntityExtension_SchemaEntitiesForExtensionEntityQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- Association Lookup: TimeSchedule_SchemaEntitiesForTimeScheduleLinesSourceSchemaEntityQuery (TimeSchedules | TimeSchedule | (TimeScheduleLines) TimeScheduleLine.SourceSchemaEntity)

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'TimeSchedule_SchemaEntitiesForTimeScheduleLinesSourceSchemaEntityQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[TimeSchedule_SchemaEntitiesForTimeScheduleLinesSourceSchemaEntityQuery]
GO

CREATE FUNCTION  [CorePatterns].[TimeSchedule_SchemaEntitiesForTimeScheduleLinesSourceSchemaEntityQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].SchemaEntitiesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO


-- CorePatterns.Verify_TimeSchedule_SchemaEntitiesForTimeScheduleLinesSourceSchemaEntityQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_TimeSchedule_SchemaEntitiesForTimeScheduleLinesSourceSchemaEntityQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_TimeSchedule_SchemaEntitiesForTimeScheduleLinesSourceSchemaEntityQuery]
GO

-- [CorePatterns].Verify_TimeSchedule_SchemaEntitiesForTimeScheduleLinesSourceSchemaEntityQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_TimeSchedule_SchemaEntitiesForTimeScheduleLinesSourceSchemaEntityQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_TimeSchedule_SchemaEntitiesForTimeScheduleLinesSourceSchemaEntityQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_TimeSchedule_SchemaEntitiesForTimeScheduleLinesSourceSchemaEntityQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_TimeSchedule_SchemaEntitiesForTimeScheduleLinesSourceSchemaEntityQuery

CREATE FUNCTION [CorePatterns].[Verify_TimeSchedule_SchemaEntitiesForTimeScheduleLinesSourceSchemaEntityQuery] (
     @List AS [CorePatterns].Verify_TimeSchedule_SchemaEntitiesForTimeScheduleLinesSourceSchemaEntityQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[TimeSchedule_SchemaEntitiesForTimeScheduleLinesSourceSchemaEntityQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


	-- Association Lookup: EntityStateTransitionHistory_SchemaEntitiesForSchemaEntityQuery (EntityStateTransitionHistories | EntityStateTransitionHistory | EntityStateTransitionHistory.SchemaEntity)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'EntityStateTransitionHistory_SchemaEntitiesForSchemaEntityQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[EntityStateTransitionHistory_SchemaEntitiesForSchemaEntityQuery]
GO

	CREATE FUNCTION  [CorePatterns].[EntityStateTransitionHistory_SchemaEntitiesForSchemaEntityQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].SchemaEntitiesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
	-- Association Lookup: EntityStateTransitionHistory_SchemaEntityStatesForPreviousStateQuery (EntityStateTransitionHistories | EntityStateTransitionHistory | EntityStateTransitionHistory.PreviousState)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'EntityStateTransitionHistory_SchemaEntityStatesForPreviousStateQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[EntityStateTransitionHistory_SchemaEntityStatesForPreviousStateQuery]
GO

	CREATE FUNCTION  [CorePatterns].[EntityStateTransitionHistory_SchemaEntityStatesForPreviousStateQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].SchemaEntityStatesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
	-- Association Lookup: EntityStateTransitionHistory_SchemaEntityStatesForNewStateQuery (EntityStateTransitionHistories | EntityStateTransitionHistory | EntityStateTransitionHistory.NewState)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'EntityStateTransitionHistory_SchemaEntityStatesForNewStateQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[EntityStateTransitionHistory_SchemaEntityStatesForNewStateQuery]
GO

	CREATE FUNCTION  [CorePatterns].[EntityStateTransitionHistory_SchemaEntityStatesForNewStateQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].SchemaEntityStatesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- CorePatterns.Verify_EntityStateTransitionHistory_SchemaEntitiesForSchemaEntityQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_EntityStateTransitionHistory_SchemaEntitiesForSchemaEntityQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_EntityStateTransitionHistory_SchemaEntitiesForSchemaEntityQuery]
GO

-- [CorePatterns].Verify_EntityStateTransitionHistory_SchemaEntitiesForSchemaEntityQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_EntityStateTransitionHistory_SchemaEntitiesForSchemaEntityQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_EntityStateTransitionHistory_SchemaEntitiesForSchemaEntityQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_EntityStateTransitionHistory_SchemaEntitiesForSchemaEntityQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_EntityStateTransitionHistory_SchemaEntitiesForSchemaEntityQuery

CREATE FUNCTION [CorePatterns].[Verify_EntityStateTransitionHistory_SchemaEntitiesForSchemaEntityQuery] (
     @List AS [CorePatterns].Verify_EntityStateTransitionHistory_SchemaEntitiesForSchemaEntityQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[EntityStateTransitionHistory_SchemaEntitiesForSchemaEntityQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- CorePatterns.Verify_EntityStateTransitionHistory_SchemaEntityStatesForPreviousStateQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_EntityStateTransitionHistory_SchemaEntityStatesForPreviousStateQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_EntityStateTransitionHistory_SchemaEntityStatesForPreviousStateQuery]
GO

-- [CorePatterns].Verify_EntityStateTransitionHistory_SchemaEntityStatesForPreviousStateQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_EntityStateTransitionHistory_SchemaEntityStatesForPreviousStateQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_EntityStateTransitionHistory_SchemaEntityStatesForPreviousStateQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_EntityStateTransitionHistory_SchemaEntityStatesForPreviousStateQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_EntityStateTransitionHistory_SchemaEntityStatesForPreviousStateQuery

CREATE FUNCTION [CorePatterns].[Verify_EntityStateTransitionHistory_SchemaEntityStatesForPreviousStateQuery] (
     @List AS [CorePatterns].Verify_EntityStateTransitionHistory_SchemaEntityStatesForPreviousStateQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[EntityStateTransitionHistory_SchemaEntityStatesForPreviousStateQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- CorePatterns.Verify_EntityStateTransitionHistory_SchemaEntityStatesForNewStateQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_EntityStateTransitionHistory_SchemaEntityStatesForNewStateQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_EntityStateTransitionHistory_SchemaEntityStatesForNewStateQuery]
GO

-- [CorePatterns].Verify_EntityStateTransitionHistory_SchemaEntityStatesForNewStateQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_EntityStateTransitionHistory_SchemaEntityStatesForNewStateQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_EntityStateTransitionHistory_SchemaEntityStatesForNewStateQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_EntityStateTransitionHistory_SchemaEntityStatesForNewStateQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_EntityStateTransitionHistory_SchemaEntityStatesForNewStateQuery

CREATE FUNCTION [CorePatterns].[Verify_EntityStateTransitionHistory_SchemaEntityStatesForNewStateQuery] (
     @List AS [CorePatterns].Verify_EntityStateTransitionHistory_SchemaEntityStatesForNewStateQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[EntityStateTransitionHistory_SchemaEntityStatesForNewStateQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


	-- Association Lookup: DraftData_OperationsForOperationQuery (Drafts | DraftData | Draft.Operation)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'DraftData_OperationsForOperationQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[DraftData_OperationsForOperationQuery]
GO

	CREATE FUNCTION  [CorePatterns].[DraftData_OperationsForOperationQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].OperationsQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- CorePatterns.Verify_DraftData_OperationsForOperationQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_DraftData_OperationsForOperationQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_DraftData_OperationsForOperationQuery]
GO

-- [CorePatterns].Verify_DraftData_OperationsForOperationQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_DraftData_OperationsForOperationQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_DraftData_OperationsForOperationQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_DraftData_OperationsForOperationQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_DraftData_OperationsForOperationQuery

CREATE FUNCTION [CorePatterns].[Verify_DraftData_OperationsForOperationQuery] (
     @List AS [CorePatterns].Verify_DraftData_OperationsForOperationQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[DraftData_OperationsForOperationQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


	-- Association Lookup: Address_CountriesForCountryQuery (Addresses | Address | Address.Country)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'Address_CountriesForCountryQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[Address_CountriesForCountryQuery]
GO

	CREATE FUNCTION  [CorePatterns].[Address_CountriesForCountryQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].CountriesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
	-- Association Lookup: Address_RegionsForRegionQuery (Addresses | Address | Address.Region)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'Address_RegionsForRegionQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[Address_RegionsForRegionQuery]
GO

	CREATE FUNCTION  [CorePatterns].[Address_RegionsForRegionQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].RegionsQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
	-- Association Lookup: Address_PostalZonesForPostalZoneRefQuery (Addresses | Address | Address.PostalZoneRef)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'Address_PostalZonesForPostalZoneRefQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[Address_PostalZonesForPostalZoneRefQuery]
GO

	CREATE FUNCTION  [CorePatterns].[Address_PostalZonesForPostalZoneRefQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].PostalZonesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- CorePatterns.Verify_Address_CountriesForCountryQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_Address_CountriesForCountryQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_Address_CountriesForCountryQuery]
GO

-- [CorePatterns].Verify_Address_CountriesForCountryQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_Address_CountriesForCountryQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_Address_CountriesForCountryQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_Address_CountriesForCountryQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_Address_CountriesForCountryQuery

CREATE FUNCTION [CorePatterns].[Verify_Address_CountriesForCountryQuery] (
     @List AS [CorePatterns].Verify_Address_CountriesForCountryQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[Address_CountriesForCountryQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- CorePatterns.Verify_Address_RegionsForRegionQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_Address_RegionsForRegionQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_Address_RegionsForRegionQuery]
GO

-- [CorePatterns].Verify_Address_RegionsForRegionQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_Address_RegionsForRegionQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_Address_RegionsForRegionQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_Address_RegionsForRegionQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_Address_RegionsForRegionQuery

CREATE FUNCTION [CorePatterns].[Verify_Address_RegionsForRegionQuery] (
     @List AS [CorePatterns].Verify_Address_RegionsForRegionQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[Address_RegionsForRegionQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- CorePatterns.Verify_Address_PostalZonesForPostalZoneRefQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_Address_PostalZonesForPostalZoneRefQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_Address_PostalZonesForPostalZoneRefQuery]
GO

-- [CorePatterns].Verify_Address_PostalZonesForPostalZoneRefQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_Address_PostalZonesForPostalZoneRefQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_Address_PostalZonesForPostalZoneRefQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_Address_PostalZonesForPostalZoneRefQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_Address_PostalZonesForPostalZoneRefQuery

CREATE FUNCTION [CorePatterns].[Verify_Address_PostalZonesForPostalZoneRefQuery] (
     @List AS [CorePatterns].Verify_Address_PostalZonesForPostalZoneRefQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[Address_PostalZonesForPostalZoneRefQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


	-- Association Lookup: Country_CulturesForCultureQuery (Countries | Country | Country.Culture)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'Country_CulturesForCultureQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[Country_CulturesForCultureQuery]
GO

	CREATE FUNCTION  [CorePatterns].[Country_CulturesForCultureQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].CulturesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- CorePatterns.Verify_Country_CulturesForCultureQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_Country_CulturesForCultureQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_Country_CulturesForCultureQuery]
GO

-- [CorePatterns].Verify_Country_CulturesForCultureQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_Country_CulturesForCultureQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_Country_CulturesForCultureQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_Country_CulturesForCultureQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_Country_CulturesForCultureQuery

CREATE FUNCTION [CorePatterns].[Verify_Country_CulturesForCultureQuery] (
     @List AS [CorePatterns].Verify_Country_CulturesForCultureQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[Country_CulturesForCultureQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


	-- Association Lookup: PostalZone_CountriesForCountryQuery (PostalZones | PostalZone | PostalZone.Country)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'PostalZone_CountriesForCountryQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[PostalZone_CountriesForCountryQuery]
GO

	CREATE FUNCTION  [CorePatterns].[PostalZone_CountriesForCountryQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].CountriesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
	-- Association Lookup: PostalZone_RegionsForRegionQuery (PostalZones | PostalZone | PostalZone.Region)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'PostalZone_RegionsForRegionQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[PostalZone_RegionsForRegionQuery]
GO

	CREATE FUNCTION  [CorePatterns].[PostalZone_RegionsForRegionQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].RegionsQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- CorePatterns.Verify_PostalZone_CountriesForCountryQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_PostalZone_CountriesForCountryQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_PostalZone_CountriesForCountryQuery]
GO

-- [CorePatterns].Verify_PostalZone_CountriesForCountryQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_PostalZone_CountriesForCountryQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_PostalZone_CountriesForCountryQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_PostalZone_CountriesForCountryQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_PostalZone_CountriesForCountryQuery

CREATE FUNCTION [CorePatterns].[Verify_PostalZone_CountriesForCountryQuery] (
     @List AS [CorePatterns].Verify_PostalZone_CountriesForCountryQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[PostalZone_CountriesForCountryQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- CorePatterns.Verify_PostalZone_RegionsForRegionQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_PostalZone_RegionsForRegionQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_PostalZone_RegionsForRegionQuery]
GO

-- [CorePatterns].Verify_PostalZone_RegionsForRegionQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_PostalZone_RegionsForRegionQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_PostalZone_RegionsForRegionQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_PostalZone_RegionsForRegionQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_PostalZone_RegionsForRegionQuery

CREATE FUNCTION [CorePatterns].[Verify_PostalZone_RegionsForRegionQuery] (
     @List AS [CorePatterns].Verify_PostalZone_RegionsForRegionQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[PostalZone_RegionsForRegionQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


	-- Association Lookup: Region_CountriesForCountryQuery (Regions | Region | Region.Country)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'Region_CountriesForCountryQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[Region_CountriesForCountryQuery]
GO

	CREATE FUNCTION  [CorePatterns].[Region_CountriesForCountryQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].CountriesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
	-- Association Lookup: Region_CulturesForCultureQuery (Regions | Region | Region.Culture)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'Region_CulturesForCultureQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[Region_CulturesForCultureQuery]
GO

	CREATE FUNCTION  [CorePatterns].[Region_CulturesForCultureQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].CulturesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- CorePatterns.Verify_Region_CountriesForCountryQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_Region_CountriesForCountryQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_Region_CountriesForCountryQuery]
GO

-- [CorePatterns].Verify_Region_CountriesForCountryQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_Region_CountriesForCountryQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_Region_CountriesForCountryQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_Region_CountriesForCountryQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_Region_CountriesForCountryQuery

CREATE FUNCTION [CorePatterns].[Verify_Region_CountriesForCountryQuery] (
     @List AS [CorePatterns].Verify_Region_CountriesForCountryQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[Region_CountriesForCountryQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- CorePatterns.Verify_Region_CulturesForCultureQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_Region_CulturesForCultureQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_Region_CulturesForCultureQuery]
GO

-- [CorePatterns].Verify_Region_CulturesForCultureQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_Region_CulturesForCultureQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_Region_CulturesForCultureQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_Region_CulturesForCultureQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_Region_CulturesForCultureQuery

CREATE FUNCTION [CorePatterns].[Verify_Region_CulturesForCultureQuery] (
     @List AS [CorePatterns].Verify_Region_CulturesForCultureQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[Region_CulturesForCultureQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


	-- Association Lookup: Currency_CurrenciesForFixedRateReferenceCurrencyQuery (Currencies | Currency | Currency.FixedRateReferenceCurrency)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'Currency_CurrenciesForFixedRateReferenceCurrencyQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[Currency_CurrenciesForFixedRateReferenceCurrencyQuery]
GO

	CREATE FUNCTION  [CorePatterns].[Currency_CurrenciesForFixedRateReferenceCurrencyQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].CurrenciesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- Association Lookup: Currency_CurrenciesForCurrencyRatesTargetCurrencyQuery (Currencies | Currency | (CurrencyRates) CurrencyRate.TargetCurrency)

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'Currency_CurrenciesForCurrencyRatesTargetCurrencyQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[Currency_CurrenciesForCurrencyRatesTargetCurrencyQuery]
GO

CREATE FUNCTION  [CorePatterns].[Currency_CurrenciesForCurrencyRatesTargetCurrencyQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].CurrenciesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO


-- CorePatterns.Verify_Currency_CurrenciesForFixedRateReferenceCurrencyQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_Currency_CurrenciesForFixedRateReferenceCurrencyQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_Currency_CurrenciesForFixedRateReferenceCurrencyQuery]
GO

-- [CorePatterns].Verify_Currency_CurrenciesForFixedRateReferenceCurrencyQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_Currency_CurrenciesForFixedRateReferenceCurrencyQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_Currency_CurrenciesForFixedRateReferenceCurrencyQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_Currency_CurrenciesForFixedRateReferenceCurrencyQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_Currency_CurrenciesForFixedRateReferenceCurrencyQuery

CREATE FUNCTION [CorePatterns].[Verify_Currency_CurrenciesForFixedRateReferenceCurrencyQuery] (
     @List AS [CorePatterns].Verify_Currency_CurrenciesForFixedRateReferenceCurrencyQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[Currency_CurrenciesForFixedRateReferenceCurrencyQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- CorePatterns.Verify_Currency_CurrenciesForCurrencyRatesTargetCurrencyQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_Currency_CurrenciesForCurrencyRatesTargetCurrencyQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_Currency_CurrenciesForCurrencyRatesTargetCurrencyQuery]
GO

-- [CorePatterns].Verify_Currency_CurrenciesForCurrencyRatesTargetCurrencyQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_Currency_CurrenciesForCurrencyRatesTargetCurrencyQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_Currency_CurrenciesForCurrencyRatesTargetCurrencyQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_Currency_CurrenciesForCurrencyRatesTargetCurrencyQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_Currency_CurrenciesForCurrencyRatesTargetCurrencyQuery

CREATE FUNCTION [CorePatterns].[Verify_Currency_CurrenciesForCurrencyRatesTargetCurrencyQuery] (
     @List AS [CorePatterns].Verify_Currency_CurrenciesForCurrencyRatesTargetCurrencyQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[Currency_CurrenciesForCurrencyRatesTargetCurrencyQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


	-- Association Lookup: Company_CountriesForCountryQuery (Companies | Company | Company.Country)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'Company_CountriesForCountryQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[Company_CountriesForCountryQuery]
GO

	CREATE FUNCTION  [CorePatterns].[Company_CountriesForCountryQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].CountriesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
	-- Association Lookup: Company_CurrenciesForBaseCurrencyQuery (Companies | Company | Company.BaseCurrency)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'Company_CurrenciesForBaseCurrencyQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[Company_CurrenciesForBaseCurrencyQuery]
GO

	CREATE FUNCTION  [CorePatterns].[Company_CurrenciesForBaseCurrencyQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].CurrenciesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
	-- Association Lookup: Company_AddressesForAddressQuery (Companies | Company | Company.Address)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'Company_AddressesForAddressQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[Company_AddressesForAddressQuery]
GO

	CREATE FUNCTION  [CorePatterns].[Company_AddressesForAddressQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].AddressesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- CorePatterns.Verify_Company_CountriesForCountryQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_Company_CountriesForCountryQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_Company_CountriesForCountryQuery]
GO

-- [CorePatterns].Verify_Company_CountriesForCountryQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_Company_CountriesForCountryQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_Company_CountriesForCountryQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_Company_CountriesForCountryQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_Company_CountriesForCountryQuery

CREATE FUNCTION [CorePatterns].[Verify_Company_CountriesForCountryQuery] (
     @List AS [CorePatterns].Verify_Company_CountriesForCountryQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[Company_CountriesForCountryQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- CorePatterns.Verify_Company_CurrenciesForBaseCurrencyQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_Company_CurrenciesForBaseCurrencyQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_Company_CurrenciesForBaseCurrencyQuery]
GO

-- [CorePatterns].Verify_Company_CurrenciesForBaseCurrencyQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_Company_CurrenciesForBaseCurrencyQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_Company_CurrenciesForBaseCurrencyQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_Company_CurrenciesForBaseCurrencyQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_Company_CurrenciesForBaseCurrencyQuery

CREATE FUNCTION [CorePatterns].[Verify_Company_CurrenciesForBaseCurrencyQuery] (
     @List AS [CorePatterns].Verify_Company_CurrenciesForBaseCurrencyQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[Company_CurrenciesForBaseCurrencyQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- CorePatterns.Verify_Company_AddressesForAddressQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_Company_AddressesForAddressQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_Company_AddressesForAddressQuery]
GO

-- [CorePatterns].Verify_Company_AddressesForAddressQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_Company_AddressesForAddressQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_Company_AddressesForAddressQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_Company_AddressesForAddressQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_Company_AddressesForAddressQuery

CREATE FUNCTION [CorePatterns].[Verify_Company_AddressesForAddressQuery] (
     @List AS [CorePatterns].Verify_Company_AddressesForAddressQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[Company_AddressesForAddressQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


	-- Association Lookup: ExchangeRate_CurrenciesForFromCurrencyQuery (ExchangeRates | ExchangeRate | ExchangeRate.FromCurrency)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'ExchangeRate_CurrenciesForFromCurrencyQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[ExchangeRate_CurrenciesForFromCurrencyQuery]
GO

	CREATE FUNCTION  [CorePatterns].[ExchangeRate_CurrenciesForFromCurrencyQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].CurrenciesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
	-- Association Lookup: ExchangeRate_CurrenciesForToCurrencyQuery (ExchangeRates | ExchangeRate | ExchangeRate.ToCurrency)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'ExchangeRate_CurrenciesForToCurrencyQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[ExchangeRate_CurrenciesForToCurrencyQuery]
GO

	CREATE FUNCTION  [CorePatterns].[ExchangeRate_CurrenciesForToCurrencyQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].CurrenciesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- CorePatterns.Verify_ExchangeRate_CurrenciesForFromCurrencyQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_ExchangeRate_CurrenciesForFromCurrencyQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_ExchangeRate_CurrenciesForFromCurrencyQuery]
GO

-- [CorePatterns].Verify_ExchangeRate_CurrenciesForFromCurrencyQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_ExchangeRate_CurrenciesForFromCurrencyQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_ExchangeRate_CurrenciesForFromCurrencyQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_ExchangeRate_CurrenciesForFromCurrencyQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_ExchangeRate_CurrenciesForFromCurrencyQuery

CREATE FUNCTION [CorePatterns].[Verify_ExchangeRate_CurrenciesForFromCurrencyQuery] (
     @List AS [CorePatterns].Verify_ExchangeRate_CurrenciesForFromCurrencyQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[ExchangeRate_CurrenciesForFromCurrencyQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- CorePatterns.Verify_ExchangeRate_CurrenciesForToCurrencyQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_ExchangeRate_CurrenciesForToCurrencyQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_ExchangeRate_CurrenciesForToCurrencyQuery]
GO

-- [CorePatterns].Verify_ExchangeRate_CurrenciesForToCurrencyQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_ExchangeRate_CurrenciesForToCurrencyQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_ExchangeRate_CurrenciesForToCurrencyQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_ExchangeRate_CurrenciesForToCurrencyQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_ExchangeRate_CurrenciesForToCurrencyQuery

CREATE FUNCTION [CorePatterns].[Verify_ExchangeRate_CurrenciesForToCurrencyQuery] (
     @List AS [CorePatterns].Verify_ExchangeRate_CurrenciesForToCurrencyQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[ExchangeRate_CurrenciesForToCurrencyQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


	-- Association Lookup: Unit_UnitDimensionsForDimensionQuery (Units | Unit | Unit.Dimension)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'Unit_UnitDimensionsForDimensionQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[Unit_UnitDimensionsForDimensionQuery]
GO

	CREATE FUNCTION  [CorePatterns].[Unit_UnitDimensionsForDimensionQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].UnitDimensionsQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
	-- Association Lookup: Unit_UnitsForBaseUnitQuery (Units | Unit | Unit.BaseUnit)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'Unit_UnitsForBaseUnitQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[Unit_UnitsForBaseUnitQuery]
GO

	CREATE FUNCTION  [CorePatterns].[Unit_UnitsForBaseUnitQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].UnitsQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- CorePatterns.Verify_Unit_UnitDimensionsForDimensionQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_Unit_UnitDimensionsForDimensionQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_Unit_UnitDimensionsForDimensionQuery]
GO

-- [CorePatterns].Verify_Unit_UnitDimensionsForDimensionQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_Unit_UnitDimensionsForDimensionQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_Unit_UnitDimensionsForDimensionQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_Unit_UnitDimensionsForDimensionQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_Unit_UnitDimensionsForDimensionQuery

CREATE FUNCTION [CorePatterns].[Verify_Unit_UnitDimensionsForDimensionQuery] (
     @List AS [CorePatterns].Verify_Unit_UnitDimensionsForDimensionQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[Unit_UnitDimensionsForDimensionQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- CorePatterns.Verify_Unit_UnitsForBaseUnitQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_Unit_UnitsForBaseUnitQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_Unit_UnitsForBaseUnitQuery]
GO

-- [CorePatterns].Verify_Unit_UnitsForBaseUnitQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_Unit_UnitsForBaseUnitQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_Unit_UnitsForBaseUnitQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_Unit_UnitsForBaseUnitQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_Unit_UnitsForBaseUnitQuery

CREATE FUNCTION [CorePatterns].[Verify_Unit_UnitsForBaseUnitQuery] (
     @List AS [CorePatterns].Verify_Unit_UnitsForBaseUnitQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[Unit_UnitsForBaseUnitQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


	-- Association Lookup: UnitDimension_UnitsForBaseUnitQuery (UnitDimensions | UnitDimension | UnitDimension.BaseUnit)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'UnitDimension_UnitsForBaseUnitQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[UnitDimension_UnitsForBaseUnitQuery]
GO

	CREATE FUNCTION  [CorePatterns].[UnitDimension_UnitsForBaseUnitQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].UnitsQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- CorePatterns.Verify_UnitDimension_UnitsForBaseUnitQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_UnitDimension_UnitsForBaseUnitQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_UnitDimension_UnitsForBaseUnitQuery]
GO

-- [CorePatterns].Verify_UnitDimension_UnitsForBaseUnitQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_UnitDimension_UnitsForBaseUnitQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_UnitDimension_UnitsForBaseUnitQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_UnitDimension_UnitsForBaseUnitQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_UnitDimension_UnitsForBaseUnitQuery

CREATE FUNCTION [CorePatterns].[Verify_UnitDimension_UnitsForBaseUnitQuery] (
     @List AS [CorePatterns].Verify_UnitDimension_UnitsForBaseUnitQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[UnitDimension_UnitsForBaseUnitQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


	-- Association Lookup: OrganizationConfiguration_CurrenciesForReportingCurrencyQuery (OrganizationConfigurations | OrganizationConfiguration | OrganizationConfiguration.ReportingCurrency)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'OrganizationConfiguration_CurrenciesForReportingCurrencyQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[OrganizationConfiguration_CurrenciesForReportingCurrencyQuery]
GO

	CREATE FUNCTION  [CorePatterns].[OrganizationConfiguration_CurrenciesForReportingCurrencyQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].CurrenciesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
	-- Association Lookup: OrganizationConfiguration_CountriesForTaxAuthorityCountryQuery (OrganizationConfigurations | OrganizationConfiguration | OrganizationConfiguration.TaxAuthorityCountry)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'OrganizationConfiguration_CountriesForTaxAuthorityCountryQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[OrganizationConfiguration_CountriesForTaxAuthorityCountryQuery]
GO

	CREATE FUNCTION  [CorePatterns].[OrganizationConfiguration_CountriesForTaxAuthorityCountryQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].CountriesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
	-- Association Lookup: OrganizationConfiguration_CurrenciesForTaxAuthorityCurrencyQuery (OrganizationConfigurations | OrganizationConfiguration | OrganizationConfiguration.TaxAuthorityCurrency)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'OrganizationConfiguration_CurrenciesForTaxAuthorityCurrencyQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[OrganizationConfiguration_CurrenciesForTaxAuthorityCurrencyQuery]
GO

	CREATE FUNCTION  [CorePatterns].[OrganizationConfiguration_CurrenciesForTaxAuthorityCurrencyQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].CurrenciesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- CorePatterns.Verify_OrganizationConfiguration_CurrenciesForReportingCurrencyQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_OrganizationConfiguration_CurrenciesForReportingCurrencyQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_OrganizationConfiguration_CurrenciesForReportingCurrencyQuery]
GO

-- [CorePatterns].Verify_OrganizationConfiguration_CurrenciesForReportingCurrencyQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_OrganizationConfiguration_CurrenciesForReportingCurrencyQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_OrganizationConfiguration_CurrenciesForReportingCurrencyQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_OrganizationConfiguration_CurrenciesForReportingCurrencyQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_OrganizationConfiguration_CurrenciesForReportingCurrencyQuery

CREATE FUNCTION [CorePatterns].[Verify_OrganizationConfiguration_CurrenciesForReportingCurrencyQuery] (
     @List AS [CorePatterns].Verify_OrganizationConfiguration_CurrenciesForReportingCurrencyQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[OrganizationConfiguration_CurrenciesForReportingCurrencyQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- CorePatterns.Verify_OrganizationConfiguration_CountriesForTaxAuthorityCountryQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_OrganizationConfiguration_CountriesForTaxAuthorityCountryQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_OrganizationConfiguration_CountriesForTaxAuthorityCountryQuery]
GO

-- [CorePatterns].Verify_OrganizationConfiguration_CountriesForTaxAuthorityCountryQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_OrganizationConfiguration_CountriesForTaxAuthorityCountryQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_OrganizationConfiguration_CountriesForTaxAuthorityCountryQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_OrganizationConfiguration_CountriesForTaxAuthorityCountryQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_OrganizationConfiguration_CountriesForTaxAuthorityCountryQuery

CREATE FUNCTION [CorePatterns].[Verify_OrganizationConfiguration_CountriesForTaxAuthorityCountryQuery] (
     @List AS [CorePatterns].Verify_OrganizationConfiguration_CountriesForTaxAuthorityCountryQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[OrganizationConfiguration_CountriesForTaxAuthorityCountryQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- CorePatterns.Verify_OrganizationConfiguration_CurrenciesForTaxAuthorityCurrencyQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_OrganizationConfiguration_CurrenciesForTaxAuthorityCurrencyQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_OrganizationConfiguration_CurrenciesForTaxAuthorityCurrencyQuery]
GO

-- [CorePatterns].Verify_OrganizationConfiguration_CurrenciesForTaxAuthorityCurrencyQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_OrganizationConfiguration_CurrenciesForTaxAuthorityCurrencyQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_OrganizationConfiguration_CurrenciesForTaxAuthorityCurrencyQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_OrganizationConfiguration_CurrenciesForTaxAuthorityCurrencyQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_OrganizationConfiguration_CurrenciesForTaxAuthorityCurrencyQuery

CREATE FUNCTION [CorePatterns].[Verify_OrganizationConfiguration_CurrenciesForTaxAuthorityCurrencyQuery] (
     @List AS [CorePatterns].Verify_OrganizationConfiguration_CurrenciesForTaxAuthorityCurrencyQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[OrganizationConfiguration_CurrenciesForTaxAuthorityCurrencyQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


	-- Association Lookup: Contact_CountriesForCountryQuery (Contacts | Contact | Contact.Country)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'Contact_CountriesForCountryQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[Contact_CountriesForCountryQuery]
GO

	CREATE FUNCTION  [CorePatterns].[Contact_CountriesForCountryQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].CountriesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
	-- Association Lookup: Contact_AddressesForAddressQuery (Contacts | Contact | Contact.Address)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'Contact_AddressesForAddressQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[Contact_AddressesForAddressQuery]
GO

	CREATE FUNCTION  [CorePatterns].[Contact_AddressesForAddressQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].AddressesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
	-- Association Lookup: Contact_ContactTypesForContactTypeQuery (Contacts | Contact | Contact.ContactType)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'Contact_ContactTypesForContactTypeQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[Contact_ContactTypesForContactTypeQuery]
GO

	CREATE FUNCTION  [CorePatterns].[Contact_ContactTypesForContactTypeQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].ContactTypesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
	-- Association Lookup: Contact_CulturesForCultureQuery (Contacts | Contact | Contact.Culture)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'Contact_CulturesForCultureQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[Contact_CulturesForCultureQuery]
GO

	CREATE FUNCTION  [CorePatterns].[Contact_CulturesForCultureQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].CulturesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- CorePatterns.Verify_Contact_CountriesForCountryQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_Contact_CountriesForCountryQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_Contact_CountriesForCountryQuery]
GO

-- [CorePatterns].Verify_Contact_CountriesForCountryQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_Contact_CountriesForCountryQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_Contact_CountriesForCountryQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_Contact_CountriesForCountryQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_Contact_CountriesForCountryQuery

CREATE FUNCTION [CorePatterns].[Verify_Contact_CountriesForCountryQuery] (
     @List AS [CorePatterns].Verify_Contact_CountriesForCountryQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[Contact_CountriesForCountryQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- CorePatterns.Verify_Contact_AddressesForAddressQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_Contact_AddressesForAddressQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_Contact_AddressesForAddressQuery]
GO

-- [CorePatterns].Verify_Contact_AddressesForAddressQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_Contact_AddressesForAddressQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_Contact_AddressesForAddressQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_Contact_AddressesForAddressQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_Contact_AddressesForAddressQuery

CREATE FUNCTION [CorePatterns].[Verify_Contact_AddressesForAddressQuery] (
     @List AS [CorePatterns].Verify_Contact_AddressesForAddressQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[Contact_AddressesForAddressQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- CorePatterns.Verify_Contact_ContactTypesForContactTypeQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_Contact_ContactTypesForContactTypeQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_Contact_ContactTypesForContactTypeQuery]
GO

-- [CorePatterns].Verify_Contact_ContactTypesForContactTypeQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_Contact_ContactTypesForContactTypeQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_Contact_ContactTypesForContactTypeQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_Contact_ContactTypesForContactTypeQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_Contact_ContactTypesForContactTypeQuery

CREATE FUNCTION [CorePatterns].[Verify_Contact_ContactTypesForContactTypeQuery] (
     @List AS [CorePatterns].Verify_Contact_ContactTypesForContactTypeQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[Contact_ContactTypesForContactTypeQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- CorePatterns.Verify_Contact_CulturesForCultureQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_Contact_CulturesForCultureQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_Contact_CulturesForCultureQuery]
GO

-- [CorePatterns].Verify_Contact_CulturesForCultureQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_Contact_CulturesForCultureQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_Contact_CulturesForCultureQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_Contact_CulturesForCultureQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_Contact_CulturesForCultureQuery

CREATE FUNCTION [CorePatterns].[Verify_Contact_CulturesForCultureQuery] (
     @List AS [CorePatterns].Verify_Contact_CulturesForCultureQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[Contact_CulturesForCultureQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- Association Lookup: ContactGroup_ContactsForGroupContactsContactQuery (ContactGroups | ContactGroup | (GroupContacts) GroupContact.Contact)

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'ContactGroup_ContactsForGroupContactsContactQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[ContactGroup_ContactsForGroupContactsContactQuery]
GO

CREATE FUNCTION  [CorePatterns].[ContactGroup_ContactsForGroupContactsContactQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].ContactsQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO


-- CorePatterns.Verify_ContactGroup_ContactsForGroupContactsContactQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_ContactGroup_ContactsForGroupContactsContactQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_ContactGroup_ContactsForGroupContactsContactQuery]
GO

-- [CorePatterns].Verify_ContactGroup_ContactsForGroupContactsContactQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_ContactGroup_ContactsForGroupContactsContactQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_ContactGroup_ContactsForGroupContactsContactQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_ContactGroup_ContactsForGroupContactsContactQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_ContactGroup_ContactsForGroupContactsContactQuery

CREATE FUNCTION [CorePatterns].[Verify_ContactGroup_ContactsForGroupContactsContactQuery] (
     @List AS [CorePatterns].Verify_ContactGroup_ContactsForGroupContactsContactQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[ContactGroup_ContactsForGroupContactsContactQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


	-- Association Lookup: Operation_ProcessesForProcessQuery (Operations | Operation | Operation.Process)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'Operation_ProcessesForProcessQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[Operation_ProcessesForProcessQuery]
GO

	CREATE FUNCTION  [CorePatterns].[Operation_ProcessesForProcessQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].ProcessesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
	-- Association Lookup: Operation_SchemaEntitiesForSchemaEntityQuery (Operations | Operation | Operation.SchemaEntity)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'Operation_SchemaEntitiesForSchemaEntityQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[Operation_SchemaEntitiesForSchemaEntityQuery]
GO

	CREATE FUNCTION  [CorePatterns].[Operation_SchemaEntitiesForSchemaEntityQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].SchemaEntitiesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- CorePatterns.Verify_Operation_ProcessesForProcessQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_Operation_ProcessesForProcessQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_Operation_ProcessesForProcessQuery]
GO

-- [CorePatterns].Verify_Operation_ProcessesForProcessQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_Operation_ProcessesForProcessQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_Operation_ProcessesForProcessQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_Operation_ProcessesForProcessQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_Operation_ProcessesForProcessQuery

CREATE FUNCTION [CorePatterns].[Verify_Operation_ProcessesForProcessQuery] (
     @List AS [CorePatterns].Verify_Operation_ProcessesForProcessQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[Operation_ProcessesForProcessQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- CorePatterns.Verify_Operation_SchemaEntitiesForSchemaEntityQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_Operation_SchemaEntitiesForSchemaEntityQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_Operation_SchemaEntitiesForSchemaEntityQuery]
GO

-- [CorePatterns].Verify_Operation_SchemaEntitiesForSchemaEntityQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_Operation_SchemaEntitiesForSchemaEntityQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_Operation_SchemaEntitiesForSchemaEntityQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_Operation_SchemaEntitiesForSchemaEntityQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_Operation_SchemaEntitiesForSchemaEntityQuery

CREATE FUNCTION [CorePatterns].[Verify_Operation_SchemaEntitiesForSchemaEntityQuery] (
     @List AS [CorePatterns].Verify_Operation_SchemaEntitiesForSchemaEntityQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[Operation_SchemaEntitiesForSchemaEntityQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


	-- Association Lookup: Attachment_SchemaEntitiesForSchemaEntityQuery (Attachments | Attachment | Attachment.SchemaEntity)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'Attachment_SchemaEntitiesForSchemaEntityQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[Attachment_SchemaEntitiesForSchemaEntityQuery]
GO

	CREATE FUNCTION  [CorePatterns].[Attachment_SchemaEntitiesForSchemaEntityQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].SchemaEntitiesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- CorePatterns.Verify_Attachment_SchemaEntitiesForSchemaEntityQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_Attachment_SchemaEntitiesForSchemaEntityQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_Attachment_SchemaEntitiesForSchemaEntityQuery]
GO

-- [CorePatterns].Verify_Attachment_SchemaEntitiesForSchemaEntityQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_Attachment_SchemaEntitiesForSchemaEntityQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_Attachment_SchemaEntitiesForSchemaEntityQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_Attachment_SchemaEntitiesForSchemaEntityQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_Attachment_SchemaEntitiesForSchemaEntityQuery

CREATE FUNCTION [CorePatterns].[Verify_Attachment_SchemaEntitiesForSchemaEntityQuery] (
     @List AS [CorePatterns].Verify_Attachment_SchemaEntitiesForSchemaEntityQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[Attachment_SchemaEntitiesForSchemaEntityQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


	-- Association Lookup: ImportDataInfo_ImportDataTemplatesForImportDataTemplateQuery (ImportDataInfos | ImportDataInfo | ImportDataInfo.ImportDataTemplate)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'ImportDataInfo_ImportDataTemplatesForImportDataTemplateQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[ImportDataInfo_ImportDataTemplatesForImportDataTemplateQuery]
GO

	CREATE FUNCTION  [CorePatterns].[ImportDataInfo_ImportDataTemplatesForImportDataTemplateQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].ImportDataTemplatesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- CorePatterns.Verify_ImportDataInfo_ImportDataTemplatesForImportDataTemplateQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_ImportDataInfo_ImportDataTemplatesForImportDataTemplateQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_ImportDataInfo_ImportDataTemplatesForImportDataTemplateQuery]
GO

-- [CorePatterns].Verify_ImportDataInfo_ImportDataTemplatesForImportDataTemplateQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_ImportDataInfo_ImportDataTemplatesForImportDataTemplateQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_ImportDataInfo_ImportDataTemplatesForImportDataTemplateQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_ImportDataInfo_ImportDataTemplatesForImportDataTemplateQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_ImportDataInfo_ImportDataTemplatesForImportDataTemplateQuery

CREATE FUNCTION [CorePatterns].[Verify_ImportDataInfo_ImportDataTemplatesForImportDataTemplateQuery] (
     @List AS [CorePatterns].Verify_ImportDataInfo_ImportDataTemplatesForImportDataTemplateQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[ImportDataInfo_ImportDataTemplatesForImportDataTemplateQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


	-- Association Lookup: CustomEntityRecord_SchemaEntitiesForSchemaEntityQuery (CustomEntityRecords | CustomEntityRecord | CustomEntityRecord.SchemaEntity)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'CustomEntityRecord_SchemaEntitiesForSchemaEntityQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[CustomEntityRecord_SchemaEntitiesForSchemaEntityQuery]
GO

	CREATE FUNCTION  [CorePatterns].[CustomEntityRecord_SchemaEntitiesForSchemaEntityQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].SchemaEntitiesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
	-- Association Lookup: CustomEntityRecord_CompaniesForCompanyQuery (CustomEntityRecords | CustomEntityRecord | CustomEntityRecord.Company)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'CustomEntityRecord_CompaniesForCompanyQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[CustomEntityRecord_CompaniesForCompanyQuery]
GO

	CREATE FUNCTION  [CorePatterns].[CustomEntityRecord_CompaniesForCompanyQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].CompaniesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- CorePatterns.Verify_CustomEntityRecord_SchemaEntitiesForSchemaEntityQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_CustomEntityRecord_SchemaEntitiesForSchemaEntityQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_CustomEntityRecord_SchemaEntitiesForSchemaEntityQuery]
GO

-- [CorePatterns].Verify_CustomEntityRecord_SchemaEntitiesForSchemaEntityQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_CustomEntityRecord_SchemaEntitiesForSchemaEntityQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_CustomEntityRecord_SchemaEntitiesForSchemaEntityQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_CustomEntityRecord_SchemaEntitiesForSchemaEntityQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_CustomEntityRecord_SchemaEntitiesForSchemaEntityQuery

CREATE FUNCTION [CorePatterns].[Verify_CustomEntityRecord_SchemaEntitiesForSchemaEntityQuery] (
     @List AS [CorePatterns].Verify_CustomEntityRecord_SchemaEntitiesForSchemaEntityQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[CustomEntityRecord_SchemaEntitiesForSchemaEntityQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- CorePatterns.Verify_CustomEntityRecord_CompaniesForCompanyQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_CustomEntityRecord_CompaniesForCompanyQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_CustomEntityRecord_CompaniesForCompanyQuery]
GO

-- [CorePatterns].Verify_CustomEntityRecord_CompaniesForCompanyQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_CustomEntityRecord_CompaniesForCompanyQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_CustomEntityRecord_CompaniesForCompanyQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_CustomEntityRecord_CompaniesForCompanyQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_CustomEntityRecord_CompaniesForCompanyQuery

CREATE FUNCTION [CorePatterns].[Verify_CustomEntityRecord_CompaniesForCompanyQuery] (
     @List AS [CorePatterns].Verify_CustomEntityRecord_CompaniesForCompanyQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[CustomEntityRecord_CompaniesForCompanyQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


	-- Association Lookup: BackgroundOperation_OperationsForOperationQuery (BackgroundOperations | BackgroundOperation | BackgroundOperation.Operation)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'BackgroundOperation_OperationsForOperationQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[BackgroundOperation_OperationsForOperationQuery]
GO

	CREATE FUNCTION  [CorePatterns].[BackgroundOperation_OperationsForOperationQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].OperationsQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
	-- Association Lookup: BackgroundOperation_SchemaEntitiesForSchemaEntityQuery (BackgroundOperations | BackgroundOperation | BackgroundOperation.SchemaEntity)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'BackgroundOperation_SchemaEntitiesForSchemaEntityQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[BackgroundOperation_SchemaEntitiesForSchemaEntityQuery]
GO

	CREATE FUNCTION  [CorePatterns].[BackgroundOperation_SchemaEntitiesForSchemaEntityQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].SchemaEntitiesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- CorePatterns.Verify_BackgroundOperation_OperationsForOperationQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_BackgroundOperation_OperationsForOperationQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_BackgroundOperation_OperationsForOperationQuery]
GO

-- [CorePatterns].Verify_BackgroundOperation_OperationsForOperationQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_BackgroundOperation_OperationsForOperationQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_BackgroundOperation_OperationsForOperationQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_BackgroundOperation_OperationsForOperationQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_BackgroundOperation_OperationsForOperationQuery

CREATE FUNCTION [CorePatterns].[Verify_BackgroundOperation_OperationsForOperationQuery] (
     @List AS [CorePatterns].Verify_BackgroundOperation_OperationsForOperationQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[BackgroundOperation_OperationsForOperationQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- CorePatterns.Verify_BackgroundOperation_SchemaEntitiesForSchemaEntityQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_BackgroundOperation_SchemaEntitiesForSchemaEntityQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_BackgroundOperation_SchemaEntitiesForSchemaEntityQuery]
GO

-- [CorePatterns].Verify_BackgroundOperation_SchemaEntitiesForSchemaEntityQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_BackgroundOperation_SchemaEntitiesForSchemaEntityQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_BackgroundOperation_SchemaEntitiesForSchemaEntityQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_BackgroundOperation_SchemaEntitiesForSchemaEntityQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_BackgroundOperation_SchemaEntitiesForSchemaEntityQuery

CREATE FUNCTION [CorePatterns].[Verify_BackgroundOperation_SchemaEntitiesForSchemaEntityQuery] (
     @List AS [CorePatterns].Verify_BackgroundOperation_SchemaEntitiesForSchemaEntityQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[BackgroundOperation_SchemaEntitiesForSchemaEntityQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


	-- Association Lookup: ExtensibilityViewDefinition_SchemaEntitiesForSchemaEntityQuery (ExtensibilityViewDefinitions | ExtensibilityViewDefinition | ExtensibilityViewDefinition.SchemaEntity)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'ExtensibilityViewDefinition_SchemaEntitiesForSchemaEntityQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[ExtensibilityViewDefinition_SchemaEntitiesForSchemaEntityQuery]
GO

	CREATE FUNCTION  [CorePatterns].[ExtensibilityViewDefinition_SchemaEntitiesForSchemaEntityQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].SchemaEntitiesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- CorePatterns.Verify_ExtensibilityViewDefinition_SchemaEntitiesForSchemaEntityQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_ExtensibilityViewDefinition_SchemaEntitiesForSchemaEntityQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_ExtensibilityViewDefinition_SchemaEntitiesForSchemaEntityQuery]
GO

-- [CorePatterns].Verify_ExtensibilityViewDefinition_SchemaEntitiesForSchemaEntityQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_ExtensibilityViewDefinition_SchemaEntitiesForSchemaEntityQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_ExtensibilityViewDefinition_SchemaEntitiesForSchemaEntityQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_ExtensibilityViewDefinition_SchemaEntitiesForSchemaEntityQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_ExtensibilityViewDefinition_SchemaEntitiesForSchemaEntityQuery

CREATE FUNCTION [CorePatterns].[Verify_ExtensibilityViewDefinition_SchemaEntitiesForSchemaEntityQuery] (
     @List AS [CorePatterns].Verify_ExtensibilityViewDefinition_SchemaEntitiesForSchemaEntityQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[ExtensibilityViewDefinition_SchemaEntitiesForSchemaEntityQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO



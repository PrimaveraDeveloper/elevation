﻿-- Entity Lookups

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [QueryBuilder].[QueryBuilder.ListModelsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [QueryBuilder].[QueryBuilder.ListModelsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= 'f8ded5d8-0aa4-4092-8d95-e551567a8a38')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= 'f8ded5d8-0aa4-4092-8d95-e551567a8a38'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    'f8ded5d8-0aa4-4092-8d95-e551567a8a38'
    ,'QueryBuilder'
    ,'ListModels'
    ,'ListModelsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Model de la Llista"},{ "Culture":"es","Data":"Modelo de la Lista"},{ "Culture":"it","Data":"Elenco modello"},{ "Culture":"pt","Data":"Modelo da Lista"},{ "Culture":"en","Data":"List Model"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Model de la Llista)"},{ "Culture":"es","Data":"(Modelo de la Lista)"},{ "Culture":"it","Data":"(Modello di elenco)"},{ "Culture":"pt","Data":"(Modelo da Lista)"},{ "Culture":"en","Data":"(List Model)"}]}'
    ,1
    ,'f8ded5d8-0aa4-4092-8d95-e551567a8a38'
    ,'f8ded5d8-0aa4-4092-8d95-e551567a8a38'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '94a14610-2d2b-2fca-8ac2-8d1e9c2dd17b'
        ,'{"Values":[{ "Culture":"ca","Data":"Model de la Llista"},{ "Culture":"es","Data":"Modelo de la Lista"},{ "Culture":"it","Data":"Elenco modello"},{ "Culture":"pt","Data":"Modelo da Lista"},{ "Culture":"en","Data":"List Model"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'f8ded5d8-0aa4-4092-8d95-e551567a8a38'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: ListModelsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'QueryBuilder' AND 
                    specific_name = 'ListModelsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [QueryBuilder].[ListModelsQuery]
GO

CREATE FUNCTION  [QueryBuilder].[ListModelsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [QueryBuilder].[ListModelsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO


-- Associations Lookups


	-- Association Lookup: ListModel_SchemaEntitiesForMainEntityQuery (ListModels | ListModel | ListModel.MainEntity)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'QueryBuilder' AND 
                    specific_name = 'ListModel_SchemaEntitiesForMainEntityQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [QueryBuilder].[ListModel_SchemaEntitiesForMainEntityQuery]
GO

	CREATE FUNCTION  [QueryBuilder].[ListModel_SchemaEntitiesForMainEntityQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].SchemaEntitiesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- Association Lookup: ListModel_SchemaAttributesForColumnsSchemaAttributeQuery (ListModels | ListModel | (Columns) ListModelColumn.SchemaAttribute)

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'QueryBuilder' AND 
                    specific_name = 'ListModel_SchemaAttributesForColumnsSchemaAttributeQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [QueryBuilder].[ListModel_SchemaAttributesForColumnsSchemaAttributeQuery]
GO

CREATE FUNCTION  [QueryBuilder].[ListModel_SchemaAttributesForColumnsSchemaAttributeQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].SchemaAttributesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO


-- QueryBuilder.Verify_ListModel_SchemaEntitiesForMainEntityQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'QueryBuilder' AND 
                    [SPECIFIC_NAME] = 'Verify_ListModel_SchemaEntitiesForMainEntityQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [QueryBuilder].[Verify_ListModel_SchemaEntitiesForMainEntityQuery]
GO

-- [QueryBuilder].Verify_ListModel_SchemaEntitiesForMainEntityQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'QueryBuilder' AND 
                    [DOMAIN_NAME] = 'Verify_ListModel_SchemaEntitiesForMainEntityQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [QueryBuilder].Verify_ListModel_SchemaEntitiesForMainEntityQuery_Parameters
GO

CREATE TYPE [QueryBuilder].Verify_ListModel_SchemaEntitiesForMainEntityQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- QueryBuilder.Verify_ListModel_SchemaEntitiesForMainEntityQuery

CREATE FUNCTION [QueryBuilder].[Verify_ListModel_SchemaEntitiesForMainEntityQuery] (
     @List AS [QueryBuilder].Verify_ListModel_SchemaEntitiesForMainEntityQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [QueryBuilder].[ListModel_SchemaEntitiesForMainEntityQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- QueryBuilder.Verify_ListModel_SchemaAttributesForColumnsSchemaAttributeQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'QueryBuilder' AND 
                    [SPECIFIC_NAME] = 'Verify_ListModel_SchemaAttributesForColumnsSchemaAttributeQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [QueryBuilder].[Verify_ListModel_SchemaAttributesForColumnsSchemaAttributeQuery]
GO

-- [QueryBuilder].Verify_ListModel_SchemaAttributesForColumnsSchemaAttributeQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'QueryBuilder' AND 
                    [DOMAIN_NAME] = 'Verify_ListModel_SchemaAttributesForColumnsSchemaAttributeQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [QueryBuilder].Verify_ListModel_SchemaAttributesForColumnsSchemaAttributeQuery_Parameters
GO

CREATE TYPE [QueryBuilder].Verify_ListModel_SchemaAttributesForColumnsSchemaAttributeQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- QueryBuilder.Verify_ListModel_SchemaAttributesForColumnsSchemaAttributeQuery

CREATE FUNCTION [QueryBuilder].[Verify_ListModel_SchemaAttributesForColumnsSchemaAttributeQuery] (
     @List AS [QueryBuilder].Verify_ListModel_SchemaAttributesForColumnsSchemaAttributeQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [QueryBuilder].[ListModel_SchemaAttributesForColumnsSchemaAttributeQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO



﻿-- Entity Lookups

-- List Query TVF: DbVersionsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Operations' AND 
                    specific_name = 'DbVersionsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Operations].[DbVersionsQuery]
GO

CREATE FUNCTION  [Operations].[DbVersionsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [Operations].[DbVersionsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [Operations].[Operations.NotificationsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [Operations].[Operations.NotificationsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= 'a546d23e-2552-4f06-a78f-b7b41bca151f')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= 'a546d23e-2552-4f06-a78f-b7b41bca151f'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    'a546d23e-2552-4f06-a78f-b7b41bca151f'
    ,'Operations'
    ,'Notifications'
    ,'NotificationsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Notificació"},{ "Culture":"es","Data":"Notificación"},{ "Culture":"it","Data":"Notifica"},{ "Culture":"pt","Data":"Notificação"},{ "Culture":"en","Data":"Notification"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Notificació, Descripció)"},{ "Culture":"es","Data":"(Notificación, Descripción)"},{ "Culture":"it","Data":"(Notifica, descrizione)"},{ "Culture":"pt","Data":"(Notificação, Descrição)"},{ "Culture":"en","Data":"(Notification, Description)"}]}'
    ,1
    ,'a546d23e-2552-4f06-a78f-b7b41bca151f'
    ,'a546d23e-2552-4f06-a78f-b7b41bca151f'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '751f3de4-617c-191e-feed-8883572cceba'
        ,'{"Values":[{ "Culture":"ca","Data":"Notificació"},{ "Culture":"es","Data":"Notificación"},{ "Culture":"it","Data":"Notifica"},{ "Culture":"pt","Data":"Notificação"},{ "Culture":"en","Data":"Notification"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'a546d23e-2552-4f06-a78f-b7b41bca151f'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: Description (Description) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '47f06fb9-18c0-ea3c-3ce3-0c1593baabd7'
        ,'{"Values":[{ "Culture":"ca","Data":"Descripció"},{ "Culture":"es","Data":"Descripción"},{ "Culture":"it","Data":"Descrizione"},{ "Culture":"pt","Data":"Descrição"},{ "Culture":"en","Data":"Description"}]}'
        ,'True'
        ,'False'
        ,1
        ,'Text'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'a546d23e-2552-4f06-a78f-b7b41bca151f'
        ,0
        ,0
        ,1
        ,'Description'
        ,'Description'
        ,'True'
        )
GO

-- List Query TVF: NotificationsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Operations' AND 
                    specific_name = 'NotificationsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Operations].[NotificationsQuery]
GO

CREATE FUNCTION  [Operations].[NotificationsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey], [T1].[Description] AS [Description]
FROM [Operations].[NotificationsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[Description] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [Operations].[Operations.EmailTemplatesLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [Operations].[Operations.EmailTemplatesLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '6161ba49-cfe9-4d45-96c4-b4de24fb4303')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '6161ba49-cfe9-4d45-96c4-b4de24fb4303'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '6161ba49-cfe9-4d45-96c4-b4de24fb4303'
    ,'Operations'
    ,'EmailTemplates'
    ,'EmailTemplatesLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Plantilla de E-mail"},{ "Culture":"es","Data":"Plantilla de Email"},{ "Culture":"it","Data":"Modello di posta elettronica."},{ "Culture":"pt","Data":"Modelo de Email"},{ "Culture":"en","Data":"Email Template"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Plantilla d''E-mail, Descripció)"},{ "Culture":"es","Data":"(Plantilla de Email, Descripción)"},{ "Culture":"it","Data":"(Modello di posta elettronica, Descrizione)"},{ "Culture":"pt","Data":"(Modelo de Email, Descrição)"},{ "Culture":"en","Data":"(Email Template, Description)"}]}'
    ,1
    ,'6161ba49-cfe9-4d45-96c4-b4de24fb4303'
    ,'6161ba49-cfe9-4d45-96c4-b4de24fb4303'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'b16f013d-c734-a1b8-37ec-5c293ccfbc95'
        ,'{"Values":[{ "Culture":"ca","Data":"Plantilla d''E-mail"},{ "Culture":"es","Data":"Plantilla de Email"},{ "Culture":"it","Data":"Modello di posta elettronica."},{ "Culture":"pt","Data":"Modelo de Email"},{ "Culture":"en","Data":"Email Template"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'6161ba49-cfe9-4d45-96c4-b4de24fb4303'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: Description (Description) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '0c31318d-2e4d-3e5e-b179-c96318f830f0'
        ,'{"Values":[{ "Culture":"ca","Data":"Descripció"},{ "Culture":"es","Data":"Descripción"},{ "Culture":"it","Data":"Descrizione"},{ "Culture":"pt","Data":"Descrição"},{ "Culture":"en","Data":"Description"}]}'
        ,'True'
        ,'False'
        ,1
        ,'Text'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'6161ba49-cfe9-4d45-96c4-b4de24fb4303'
        ,0
        ,0
        ,1
        ,'Description'
        ,'Description'
        ,'True'
        )
GO

-- List Query TVF: EmailTemplatesQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Operations' AND 
                    specific_name = 'EmailTemplatesQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Operations].[EmailTemplatesQuery]
GO

CREATE FUNCTION  [Operations].[EmailTemplatesQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey], [T1].[Description] AS [Description]
FROM [Operations].[EmailTemplatesView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[Description] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [Operations].[Operations.NotificationGroupsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [Operations].[Operations.NotificationGroupsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '15c241a6-43cd-400b-9858-28e470b4a9fc')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '15c241a6-43cd-400b-9858-28e470b4a9fc'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '15c241a6-43cd-400b-9858-28e470b4a9fc'
    ,'Operations'
    ,'NotificationGroups'
    ,'NotificationGroupsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Grup de la Notificació"},{ "Culture":"es","Data":"Grupo de la Notificación"},{ "Culture":"it","Data":"Gruppo di notifica"},{ "Culture":"pt","Data":"Grupo da Notificação"},{ "Culture":"en","Data":"Notification Group"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Grup de Notificació, Descripció)"},{ "Culture":"es","Data":"(Grupo de Notificación, Descripción)"},{ "Culture":"it","Data":"(Gruppo di notifica, descrizione)"},{ "Culture":"pt","Data":"(Grupo da Notificação, Descrição)"},{ "Culture":"en","Data":"(Notification Group, Description)"}]}'
    ,1
    ,'15c241a6-43cd-400b-9858-28e470b4a9fc'
    ,'15c241a6-43cd-400b-9858-28e470b4a9fc'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '96a1bc5a-81b7-aacb-fc41-d7e410a5e848'
        ,'{"Values":[{ "Culture":"ca","Data":"Grup de la Notificació"},{ "Culture":"es","Data":"Grupo de la Notificación"},{ "Culture":"it","Data":"Gruppo di notifica"},{ "Culture":"pt","Data":"Grupo da Notificação"},{ "Culture":"en","Data":"Notification Group"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'15c241a6-43cd-400b-9858-28e470b4a9fc'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: Description (Description) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'f45ba797-202a-fcfd-f7d3-c8d58c522583'
        ,'{"Values":[{ "Culture":"ca","Data":"Descripció"},{ "Culture":"es","Data":"Descripción"},{ "Culture":"it","Data":"Descrizione"},{ "Culture":"pt","Data":"Descrição"},{ "Culture":"en","Data":"Description"}]}'
        ,'True'
        ,'False'
        ,1
        ,'Text'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'15c241a6-43cd-400b-9858-28e470b4a9fc'
        ,0
        ,0
        ,1
        ,'Description'
        ,'Description'
        ,'True'
        )
GO

-- List Query TVF: NotificationGroupsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Operations' AND 
                    specific_name = 'NotificationGroupsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Operations].[NotificationGroupsQuery]
GO

CREATE FUNCTION  [Operations].[NotificationGroupsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey], [T1].[Description] AS [Description]
FROM [Operations].[NotificationGroupsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[Description] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [Operations].[Operations.NotificationEntityGroupsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [Operations].[Operations.NotificationEntityGroupsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '0102967c-ffe0-4361-95d8-964d45dcd0a9')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '0102967c-ffe0-4361-95d8-964d45dcd0a9'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '0102967c-ffe0-4361-95d8-964d45dcd0a9'
    ,'Operations'
    ,'NotificationEntityGroups'
    ,'NotificationEntityGroupsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Grup d''Entitat de Notificació"},{ "Culture":"es","Data":"Grupo de Entidad de Notificación"},{ "Culture":"it","Data":"Notification Entity Group."},{ "Culture":"pt","Data":"Grupo de Entidade de Notificação"},{ "Culture":"en","Data":"Notification Entity Group"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Grup d''Entitat de Notificació)"},{ "Culture":"es","Data":"(Grupo de Entidad de Notificación)"},{ "Culture":"it","Data":"(Gruppo di entità di notifica)"},{ "Culture":"pt","Data":"(Grupo de Entidade de Notificação)"},{ "Culture":"en","Data":"(Notification Entity Group)"}]}'
    ,1
    ,'0102967c-ffe0-4361-95d8-964d45dcd0a9'
    ,'0102967c-ffe0-4361-95d8-964d45dcd0a9'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '326e0910-bc1d-0ed9-65c8-a690c0dbc06d'
        ,'{"Values":[{ "Culture":"ca","Data":"Grup d''Entitat de Notificació"},{ "Culture":"es","Data":"Grupo de Entidad de Notificación"},{ "Culture":"it","Data":"Notification Entity Group."},{ "Culture":"pt","Data":"Grupo de Entidade de Notificação"},{ "Culture":"en","Data":"Notification Entity Group"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'0102967c-ffe0-4361-95d8-964d45dcd0a9'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: NotificationEntityGroupsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Operations' AND 
                    specific_name = 'NotificationEntityGroupsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Operations].[NotificationEntityGroupsQuery]
GO

CREATE FUNCTION  [Operations].[NotificationEntityGroupsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [Operations].[NotificationEntityGroupsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO


-- Associations Lookups


-- Association Lookup: Notification_CulturesForNotificationUsersCultureQuery (Notifications | Notification | (NotificationUsers) NotificationUser.Culture)

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Operations' AND 
                    specific_name = 'Notification_CulturesForNotificationUsersCultureQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Operations].[Notification_CulturesForNotificationUsersCultureQuery]
GO

CREATE FUNCTION  [Operations].[Notification_CulturesForNotificationUsersCultureQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].CulturesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO


-- Association Lookup: Notification_UsersForNotificationUsersUserQuery (Notifications | Notification | (NotificationUsers) NotificationUser.User)

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Operations' AND 
                    specific_name = 'Notification_UsersForNotificationUsersUserQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Operations].[Notification_UsersForNotificationUsersUserQuery]
GO

CREATE FUNCTION  [Operations].[Notification_UsersForNotificationUsersUserQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [Identity].UsersQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO


-- Association Lookup: Notification_CulturesForNotificationContactsCultureQuery (Notifications | Notification | (NotificationContacts) NotificationContact.Culture)

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Operations' AND 
                    specific_name = 'Notification_CulturesForNotificationContactsCultureQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Operations].[Notification_CulturesForNotificationContactsCultureQuery]
GO

CREATE FUNCTION  [Operations].[Notification_CulturesForNotificationContactsCultureQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].CulturesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO


-- Association Lookup: Notification_ContactsForNotificationContactsContactQuery (Notifications | Notification | (NotificationContacts) NotificationContact.Contact)

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Operations' AND 
                    specific_name = 'Notification_ContactsForNotificationContactsContactQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Operations].[Notification_ContactsForNotificationContactsContactQuery]
GO

CREATE FUNCTION  [Operations].[Notification_ContactsForNotificationContactsContactQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].ContactsQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO


-- Association Lookup: Notification_EmailTemplatesForEmailTemplateListsEmailTemplateQuery (Notifications | Notification | (EmailTemplateLists) EmailTemplateList.EmailTemplate)

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Operations' AND 
                    specific_name = 'Notification_EmailTemplatesForEmailTemplateListsEmailTemplateQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Operations].[Notification_EmailTemplatesForEmailTemplateListsEmailTemplateQuery]
GO

CREATE FUNCTION  [Operations].[Notification_EmailTemplatesForEmailTemplateListsEmailTemplateQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [Operations].EmailTemplatesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO


-- Association Lookup: Notification_CulturesForEmailTemplateListsCultureQuery (Notifications | Notification | (EmailTemplateLists) EmailTemplateList.Culture)

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Operations' AND 
                    specific_name = 'Notification_CulturesForEmailTemplateListsCultureQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Operations].[Notification_CulturesForEmailTemplateListsCultureQuery]
GO

CREATE FUNCTION  [Operations].[Notification_CulturesForEmailTemplateListsCultureQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].CulturesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO


-- Operations.Verify_Notification_CulturesForNotificationUsersCultureQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'Operations' AND 
                    [SPECIFIC_NAME] = 'Verify_Notification_CulturesForNotificationUsersCultureQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [Operations].[Verify_Notification_CulturesForNotificationUsersCultureQuery]
GO

-- [Operations].Verify_Notification_CulturesForNotificationUsersCultureQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'Operations' AND 
                    [DOMAIN_NAME] = 'Verify_Notification_CulturesForNotificationUsersCultureQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [Operations].Verify_Notification_CulturesForNotificationUsersCultureQuery_Parameters
GO

CREATE TYPE [Operations].Verify_Notification_CulturesForNotificationUsersCultureQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- Operations.Verify_Notification_CulturesForNotificationUsersCultureQuery

CREATE FUNCTION [Operations].[Verify_Notification_CulturesForNotificationUsersCultureQuery] (
     @List AS [Operations].Verify_Notification_CulturesForNotificationUsersCultureQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Operations].[Notification_CulturesForNotificationUsersCultureQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- Operations.Verify_Notification_UsersForNotificationUsersUserQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'Operations' AND 
                    [SPECIFIC_NAME] = 'Verify_Notification_UsersForNotificationUsersUserQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [Operations].[Verify_Notification_UsersForNotificationUsersUserQuery]
GO

-- [Operations].Verify_Notification_UsersForNotificationUsersUserQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'Operations' AND 
                    [DOMAIN_NAME] = 'Verify_Notification_UsersForNotificationUsersUserQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [Operations].Verify_Notification_UsersForNotificationUsersUserQuery_Parameters
GO

CREATE TYPE [Operations].Verify_Notification_UsersForNotificationUsersUserQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- Operations.Verify_Notification_UsersForNotificationUsersUserQuery

CREATE FUNCTION [Operations].[Verify_Notification_UsersForNotificationUsersUserQuery] (
     @List AS [Operations].Verify_Notification_UsersForNotificationUsersUserQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Operations].[Notification_UsersForNotificationUsersUserQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- Operations.Verify_Notification_CulturesForNotificationContactsCultureQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'Operations' AND 
                    [SPECIFIC_NAME] = 'Verify_Notification_CulturesForNotificationContactsCultureQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [Operations].[Verify_Notification_CulturesForNotificationContactsCultureQuery]
GO

-- [Operations].Verify_Notification_CulturesForNotificationContactsCultureQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'Operations' AND 
                    [DOMAIN_NAME] = 'Verify_Notification_CulturesForNotificationContactsCultureQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [Operations].Verify_Notification_CulturesForNotificationContactsCultureQuery_Parameters
GO

CREATE TYPE [Operations].Verify_Notification_CulturesForNotificationContactsCultureQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- Operations.Verify_Notification_CulturesForNotificationContactsCultureQuery

CREATE FUNCTION [Operations].[Verify_Notification_CulturesForNotificationContactsCultureQuery] (
     @List AS [Operations].Verify_Notification_CulturesForNotificationContactsCultureQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Operations].[Notification_CulturesForNotificationContactsCultureQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- Operations.Verify_Notification_ContactsForNotificationContactsContactQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'Operations' AND 
                    [SPECIFIC_NAME] = 'Verify_Notification_ContactsForNotificationContactsContactQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [Operations].[Verify_Notification_ContactsForNotificationContactsContactQuery]
GO

-- [Operations].Verify_Notification_ContactsForNotificationContactsContactQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'Operations' AND 
                    [DOMAIN_NAME] = 'Verify_Notification_ContactsForNotificationContactsContactQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [Operations].Verify_Notification_ContactsForNotificationContactsContactQuery_Parameters
GO

CREATE TYPE [Operations].Verify_Notification_ContactsForNotificationContactsContactQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- Operations.Verify_Notification_ContactsForNotificationContactsContactQuery

CREATE FUNCTION [Operations].[Verify_Notification_ContactsForNotificationContactsContactQuery] (
     @List AS [Operations].Verify_Notification_ContactsForNotificationContactsContactQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Operations].[Notification_ContactsForNotificationContactsContactQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- Operations.Verify_Notification_EmailTemplatesForEmailTemplateListsEmailTemplateQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'Operations' AND 
                    [SPECIFIC_NAME] = 'Verify_Notification_EmailTemplatesForEmailTemplateListsEmailTemplateQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [Operations].[Verify_Notification_EmailTemplatesForEmailTemplateListsEmailTemplateQuery]
GO

-- [Operations].Verify_Notification_EmailTemplatesForEmailTemplateListsEmailTemplateQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'Operations' AND 
                    [DOMAIN_NAME] = 'Verify_Notification_EmailTemplatesForEmailTemplateListsEmailTemplateQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [Operations].Verify_Notification_EmailTemplatesForEmailTemplateListsEmailTemplateQuery_Parameters
GO

CREATE TYPE [Operations].Verify_Notification_EmailTemplatesForEmailTemplateListsEmailTemplateQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- Operations.Verify_Notification_EmailTemplatesForEmailTemplateListsEmailTemplateQuery

CREATE FUNCTION [Operations].[Verify_Notification_EmailTemplatesForEmailTemplateListsEmailTemplateQuery] (
     @List AS [Operations].Verify_Notification_EmailTemplatesForEmailTemplateListsEmailTemplateQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Operations].[Notification_EmailTemplatesForEmailTemplateListsEmailTemplateQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- Operations.Verify_Notification_CulturesForEmailTemplateListsCultureQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'Operations' AND 
                    [SPECIFIC_NAME] = 'Verify_Notification_CulturesForEmailTemplateListsCultureQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [Operations].[Verify_Notification_CulturesForEmailTemplateListsCultureQuery]
GO

-- [Operations].Verify_Notification_CulturesForEmailTemplateListsCultureQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'Operations' AND 
                    [DOMAIN_NAME] = 'Verify_Notification_CulturesForEmailTemplateListsCultureQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [Operations].Verify_Notification_CulturesForEmailTemplateListsCultureQuery_Parameters
GO

CREATE TYPE [Operations].Verify_Notification_CulturesForEmailTemplateListsCultureQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- Operations.Verify_Notification_CulturesForEmailTemplateListsCultureQuery

CREATE FUNCTION [Operations].[Verify_Notification_CulturesForEmailTemplateListsCultureQuery] (
     @List AS [Operations].Verify_Notification_CulturesForEmailTemplateListsCultureQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Operations].[Notification_CulturesForEmailTemplateListsCultureQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


	-- Association Lookup: EmailTemplate_CulturesForCultureQuery (EmailTemplates | EmailTemplate | EmailTemplate.Culture)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Operations' AND 
                    specific_name = 'EmailTemplate_CulturesForCultureQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Operations].[EmailTemplate_CulturesForCultureQuery]
GO

	CREATE FUNCTION  [Operations].[EmailTemplate_CulturesForCultureQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].CulturesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- Operations.Verify_EmailTemplate_CulturesForCultureQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'Operations' AND 
                    [SPECIFIC_NAME] = 'Verify_EmailTemplate_CulturesForCultureQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [Operations].[Verify_EmailTemplate_CulturesForCultureQuery]
GO

-- [Operations].Verify_EmailTemplate_CulturesForCultureQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'Operations' AND 
                    [DOMAIN_NAME] = 'Verify_EmailTemplate_CulturesForCultureQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [Operations].Verify_EmailTemplate_CulturesForCultureQuery_Parameters
GO

CREATE TYPE [Operations].Verify_EmailTemplate_CulturesForCultureQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- Operations.Verify_EmailTemplate_CulturesForCultureQuery

CREATE FUNCTION [Operations].[Verify_EmailTemplate_CulturesForCultureQuery] (
     @List AS [Operations].Verify_EmailTemplate_CulturesForCultureQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Operations].[EmailTemplate_CulturesForCultureQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- Association Lookup: NotificationGroup_NotificationsForNotificationGroupListsNotificationQuery (NotificationGroups | NotificationGroup | (NotificationGroupLists) NotificationGroupList.Notification)

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Operations' AND 
                    specific_name = 'NotificationGroup_NotificationsForNotificationGroupListsNotificationQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Operations].[NotificationGroup_NotificationsForNotificationGroupListsNotificationQuery]
GO

CREATE FUNCTION  [Operations].[NotificationGroup_NotificationsForNotificationGroupListsNotificationQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [Operations].NotificationsQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO


-- Operations.Verify_NotificationGroup_NotificationsForNotificationGroupListsNotificationQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'Operations' AND 
                    [SPECIFIC_NAME] = 'Verify_NotificationGroup_NotificationsForNotificationGroupListsNotificationQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [Operations].[Verify_NotificationGroup_NotificationsForNotificationGroupListsNotificationQuery]
GO

-- [Operations].Verify_NotificationGroup_NotificationsForNotificationGroupListsNotificationQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'Operations' AND 
                    [DOMAIN_NAME] = 'Verify_NotificationGroup_NotificationsForNotificationGroupListsNotificationQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [Operations].Verify_NotificationGroup_NotificationsForNotificationGroupListsNotificationQuery_Parameters
GO

CREATE TYPE [Operations].Verify_NotificationGroup_NotificationsForNotificationGroupListsNotificationQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- Operations.Verify_NotificationGroup_NotificationsForNotificationGroupListsNotificationQuery

CREATE FUNCTION [Operations].[Verify_NotificationGroup_NotificationsForNotificationGroupListsNotificationQuery] (
     @List AS [Operations].Verify_NotificationGroup_NotificationsForNotificationGroupListsNotificationQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Operations].[NotificationGroup_NotificationsForNotificationGroupListsNotificationQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


	-- Association Lookup: NotificationEntityGroup_NotificationsForNotificationQuery (NotificationEntityGroups | NotificationEntityGroup | NotificationEntityGroup.Notification)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Operations' AND 
                    specific_name = 'NotificationEntityGroup_NotificationsForNotificationQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Operations].[NotificationEntityGroup_NotificationsForNotificationQuery]
GO

	CREATE FUNCTION  [Operations].[NotificationEntityGroup_NotificationsForNotificationQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [Operations].NotificationsQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- Association Lookup: NotificationEntityGroup_SchemaEntitiesForGroupSchemaEntitiesSchemaEntityQuery (NotificationEntityGroups | NotificationEntityGroup | (GroupSchemaEntities) GroupSchemaEntity.SchemaEntity)

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Operations' AND 
                    specific_name = 'NotificationEntityGroup_SchemaEntitiesForGroupSchemaEntitiesSchemaEntityQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Operations].[NotificationEntityGroup_SchemaEntitiesForGroupSchemaEntitiesSchemaEntityQuery]
GO

CREATE FUNCTION  [Operations].[NotificationEntityGroup_SchemaEntitiesForGroupSchemaEntitiesSchemaEntityQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].SchemaEntitiesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO


-- Operations.Verify_NotificationEntityGroup_NotificationsForNotificationQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'Operations' AND 
                    [SPECIFIC_NAME] = 'Verify_NotificationEntityGroup_NotificationsForNotificationQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [Operations].[Verify_NotificationEntityGroup_NotificationsForNotificationQuery]
GO

-- [Operations].Verify_NotificationEntityGroup_NotificationsForNotificationQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'Operations' AND 
                    [DOMAIN_NAME] = 'Verify_NotificationEntityGroup_NotificationsForNotificationQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [Operations].Verify_NotificationEntityGroup_NotificationsForNotificationQuery_Parameters
GO

CREATE TYPE [Operations].Verify_NotificationEntityGroup_NotificationsForNotificationQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- Operations.Verify_NotificationEntityGroup_NotificationsForNotificationQuery

CREATE FUNCTION [Operations].[Verify_NotificationEntityGroup_NotificationsForNotificationQuery] (
     @List AS [Operations].Verify_NotificationEntityGroup_NotificationsForNotificationQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Operations].[NotificationEntityGroup_NotificationsForNotificationQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- Operations.Verify_NotificationEntityGroup_SchemaEntitiesForGroupSchemaEntitiesSchemaEntityQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'Operations' AND 
                    [SPECIFIC_NAME] = 'Verify_NotificationEntityGroup_SchemaEntitiesForGroupSchemaEntitiesSchemaEntityQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [Operations].[Verify_NotificationEntityGroup_SchemaEntitiesForGroupSchemaEntitiesSchemaEntityQuery]
GO

-- [Operations].Verify_NotificationEntityGroup_SchemaEntitiesForGroupSchemaEntitiesSchemaEntityQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'Operations' AND 
                    [DOMAIN_NAME] = 'Verify_NotificationEntityGroup_SchemaEntitiesForGroupSchemaEntitiesSchemaEntityQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [Operations].Verify_NotificationEntityGroup_SchemaEntitiesForGroupSchemaEntitiesSchemaEntityQuery_Parameters
GO

CREATE TYPE [Operations].Verify_NotificationEntityGroup_SchemaEntitiesForGroupSchemaEntitiesSchemaEntityQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- Operations.Verify_NotificationEntityGroup_SchemaEntitiesForGroupSchemaEntitiesSchemaEntityQuery

CREATE FUNCTION [Operations].[Verify_NotificationEntityGroup_SchemaEntitiesForGroupSchemaEntitiesSchemaEntityQuery] (
     @List AS [Operations].Verify_NotificationEntityGroup_SchemaEntitiesForGroupSchemaEntitiesSchemaEntityQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Operations].[NotificationEntityGroup_SchemaEntitiesForGroupSchemaEntitiesSchemaEntityQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO



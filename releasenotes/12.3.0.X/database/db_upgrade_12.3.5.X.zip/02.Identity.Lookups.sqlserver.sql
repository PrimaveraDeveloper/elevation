﻿-- Entity Lookups

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [Identity].[Identity.UsersLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [Identity].[Identity.UsersLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '737af993-cd13-42d3-819f-77ee667da957')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '737af993-cd13-42d3-819f-77ee667da957'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '737af993-cd13-42d3-819f-77ee667da957'
    ,'Identity'
    ,'Users'
    ,'UsersLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Usuari"},{ "Culture":"es","Data":"Usuario"},{ "Culture":"it","Data":"Utente"},{ "Culture":"pt","Data":"Utilizador"},{ "Culture":"en","Data":"User"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Usuari, Nom, Perfil Predefinit)"},{ "Culture":"es","Data":"(Usuario, Nombre, Perfil Predefinido)"},{ "Culture":"it","Data":"(Utente, nome, ruolo predefinito)"},{ "Culture":"pt","Data":"(Utilizador, Nome, Perfil Predefinido)"},{ "Culture":"en","Data":"(User, Name, Default Role)"}]}'
    ,1
    ,'737af993-cd13-42d3-819f-77ee667da957'
    ,'737af993-cd13-42d3-819f-77ee667da957'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'e680694f-16ee-a02f-7532-f7b773abc5c7'
        ,'{"Values":[{ "Culture":"ca","Data":"Usuari"},{ "Culture":"es","Data":"Usuario"},{ "Culture":"it","Data":"Utente"},{ "Culture":"pt","Data":"Utilizador"},{ "Culture":"en","Data":"User"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'737af993-cd13-42d3-819f-77ee667da957'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'False'
        )
GO


-- Column: Picture (Picture) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '238f7ba4-aaa9-65e7-88e6-0b70e1a4d235'
        ,'{"Values":[{ "Culture":"ca","Data":"Imatge"},{ "Culture":"es","Data":"Imagen"},{ "Culture":"it","Data":"Foto"},{ "Culture":"pt","Data":"Imagem"},{ "Culture":"en","Data":"Picture"}]}'
        ,'True'
        ,'False'
        ,1
        ,'Image'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'737af993-cd13-42d3-819f-77ee667da957'
        ,0
        ,0
        ,1
        ,'Picture'
        ,'Picture'
        ,'True'
        )
GO


-- Column: Name (Name) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '99600130-7705-a6ac-8837-238be426ad9a'
        ,'{"Values":[{ "Culture":"ca","Data":"Nom"},{ "Culture":"es","Data":"Nombre"},{ "Culture":"it","Data":"Nome"},{ "Culture":"pt","Data":"Nome"},{ "Culture":"en","Data":"Name"}]}'
        ,'True'
        ,'False'
        ,2
        ,'Text'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'737af993-cd13-42d3-819f-77ee667da957'
        ,0
        ,0
        ,1
        ,'Name'
        ,'Name'
        ,'True'
        )
GO


-- Column: NaturalKey (DefaultRoleNaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'ecde39f5-fa71-c2ac-6cfe-9a17087e6fb2'
        ,'{"Values":[{ "Culture":"ca","Data":"Perfil Predefinit"},{ "Culture":"es","Data":"Perfil Predefinido"},{ "Culture":"it","Data":"Ruolo predefinito"},{ "Culture":"pt","Data":"Perfil Predefinido"},{ "Culture":"en","Data":"Default Role"}]}'
        ,'True'
        ,'False'
        ,3
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'737af993-cd13-42d3-819f-77ee667da957'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'DefaultRoleNaturalKey'
        ,'True'
        )
GO

-- List Query TVF: UsersQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Identity' AND 
                    specific_name = 'UsersQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Identity].[UsersQuery]
GO

CREATE FUNCTION  [Identity].[UsersQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey], [T1].[PictureThumbnail] AS [Picture], [T1].[Name] AS [Name], [T2].[NaturalKey] AS [DefaultRoleNaturalKey]
FROM [Identity].[UsersView] [T1]
LEFT JOIN [Identity].[RolesView] [T2] ON [T2].[Id] = [T1].[DefaultRoleId]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[Name] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T2].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [Identity].[Identity.RolesLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [Identity].[Identity.RolesLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '41615546-ecb4-4ab8-85a1-e9dac8a4c7c5')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '41615546-ecb4-4ab8-85a1-e9dac8a4c7c5'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '41615546-ecb4-4ab8-85a1-e9dac8a4c7c5'
    ,'Identity'
    ,'Roles'
    ,'RolesLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Perfil"},{ "Culture":"es","Data":"Perfil"},{ "Culture":"it","Data":"Ruolo"},{ "Culture":"pt","Data":"Perfil"},{ "Culture":"en","Data":"Role"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Perfil, Descripció)"},{ "Culture":"es","Data":"(Perfil, Descripción)"},{ "Culture":"it","Data":"(Ruolo, descrizione)"},{ "Culture":"pt","Data":"(Perfil, Descrição)"},{ "Culture":"en","Data":"(Role, Description)"}]}'
    ,1
    ,'41615546-ecb4-4ab8-85a1-e9dac8a4c7c5'
    ,'41615546-ecb4-4ab8-85a1-e9dac8a4c7c5'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '3be51a95-088d-59c4-a40a-77984eefa300'
        ,'{"Values":[{ "Culture":"ca","Data":"Perfil"},{ "Culture":"es","Data":"Perfil"},{ "Culture":"it","Data":"Ruolo"},{ "Culture":"pt","Data":"Perfil"},{ "Culture":"en","Data":"Role"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'41615546-ecb4-4ab8-85a1-e9dac8a4c7c5'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: Description (Description) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'e735b8a3-2e45-051d-b6bc-15a2e6fa2fe4'
        ,'{"Values":[{ "Culture":"ca","Data":"Descripció"},{ "Culture":"es","Data":"Descripción"},{ "Culture":"it","Data":"Descrizione"},{ "Culture":"pt","Data":"Descrição"},{ "Culture":"en","Data":"Description"}]}'
        ,'True'
        ,'False'
        ,1
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'41615546-ecb4-4ab8-85a1-e9dac8a4c7c5'
        ,0
        ,0
        ,1
        ,'Description'
        ,'Description'
        ,'True'
        )
GO

-- List Query TVF: RolesQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Identity' AND 
                    specific_name = 'RolesQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Identity].[RolesQuery]
GO

CREATE FUNCTION  [Identity].[RolesQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey], [T1].[Description] AS [Description]
FROM [Identity].[RolesView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[Description] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [Identity].[Identity.GroupsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [Identity].[Identity.GroupsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '49a1ddb2-f031-4cd2-870a-390ef0db206c')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '49a1ddb2-f031-4cd2-870a-390ef0db206c'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '49a1ddb2-f031-4cd2-870a-390ef0db206c'
    ,'Identity'
    ,'Groups'
    ,'GroupsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Grup"},{ "Culture":"es","Data":"Grupo"},{ "Culture":"it","Data":"Gruppo"},{ "Culture":"pt","Data":"Grupo"},{ "Culture":"en","Data":"Group"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Grup, Nom)"},{ "Culture":"es","Data":"(Grupo, Nombre)"},{ "Culture":"it","Data":"(Nome del gruppo)"},{ "Culture":"pt","Data":"(Grupo, Nome)"},{ "Culture":"en","Data":"(Group, Name)"}]}'
    ,1
    ,'49a1ddb2-f031-4cd2-870a-390ef0db206c'
    ,'49a1ddb2-f031-4cd2-870a-390ef0db206c'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'cd8dbed0-df1a-19f7-3cab-4e392775b928'
        ,'{"Values":[{ "Culture":"ca","Data":"Grup"},{ "Culture":"es","Data":"Grupo"},{ "Culture":"it","Data":"Gruppo"},{ "Culture":"pt","Data":"Grupo"},{ "Culture":"en","Data":"Group"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'49a1ddb2-f031-4cd2-870a-390ef0db206c'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: Name (Name) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '7a42157b-8cbd-0a17-5d8c-9d132868bb8c'
        ,'{"Values":[{ "Culture":"ca","Data":"Nom"},{ "Culture":"es","Data":"Nombre"},{ "Culture":"it","Data":"Nome"},{ "Culture":"pt","Data":"Nome"},{ "Culture":"en","Data":"Name"}]}'
        ,'True'
        ,'False'
        ,1
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'49a1ddb2-f031-4cd2-870a-390ef0db206c'
        ,0
        ,0
        ,1
        ,'Name'
        ,'Name'
        ,'True'
        )
GO

-- List Query TVF: GroupsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Identity' AND 
                    specific_name = 'GroupsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Identity].[GroupsQuery]
GO

CREATE FUNCTION  [Identity].[GroupsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey], [T1].[Name] AS [Name]
FROM [Identity].[GroupsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[Name] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [Identity].[Identity.SupportRequestsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [Identity].[Identity.SupportRequestsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '41561f76-e26e-4a86-9d42-a563e22727ee')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '41561f76-e26e-4a86-9d42-a563e22727ee'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '41561f76-e26e-4a86-9d42-a563e22727ee'
    ,'Identity'
    ,'SupportRequests'
    ,'SupportRequestsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Sol·licitud de Suport"},{ "Culture":"es","Data":"Solicitud de Soporte"},{ "Culture":"it","Data":"Richiesta di supporto"},{ "Culture":"pt","Data":"Pedido de Suporte"},{ "Culture":"en","Data":"Support Request"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Sol·licitud de Suport)"},{ "Culture":"es","Data":"(Solicitud de Soporte)"},{ "Culture":"it","Data":"(Richiesta di supporto)"},{ "Culture":"pt","Data":"(Pedido de Suporte)"},{ "Culture":"en","Data":"(Support Request)"}]}'
    ,1
    ,'41561f76-e26e-4a86-9d42-a563e22727ee'
    ,'41561f76-e26e-4a86-9d42-a563e22727ee'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'a6a2d8a4-8e14-0302-ff45-8266d148fa59'
        ,'{"Values":[{ "Culture":"ca","Data":"Sol·licitud de Suport"},{ "Culture":"es","Data":"Solicitud de Soporte"},{ "Culture":"it","Data":"Richiesta di supporto"},{ "Culture":"pt","Data":"Pedido de Suporte"},{ "Culture":"en","Data":"Support Request"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'41561f76-e26e-4a86-9d42-a563e22727ee'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: SupportRequestsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Identity' AND 
                    specific_name = 'SupportRequestsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Identity].[SupportRequestsQuery]
GO

CREATE FUNCTION  [Identity].[SupportRequestsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [Identity].[SupportRequestsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [Identity].[Identity.RoleClaimsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [Identity].[Identity.RoleClaimsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '5b4f047c-1aea-4a3c-bbdf-22c149864d3d')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '5b4f047c-1aea-4a3c-bbdf-22c149864d3d'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '5b4f047c-1aea-4a3c-bbdf-22c149864d3d'
    ,'Identity'
    ,'RoleClaims'
    ,'RoleClaimsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Claim de Perfil"},{ "Culture":"es","Data":"Claim de Perfil"},{ "Culture":"it","Data":"Rivendicazione di ruolo"},{ "Culture":"pt","Data":"Claim de Perfil"},{ "Culture":"en","Data":"Role Claim"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Claim de Perfil)"},{ "Culture":"es","Data":"(Claim de Perfil)"},{ "Culture":"it","Data":"(Reclamo di ruolo)"},{ "Culture":"pt","Data":"(Claim de Perfil)"},{ "Culture":"en","Data":"(Role Claim)"}]}'
    ,1
    ,'5b4f047c-1aea-4a3c-bbdf-22c149864d3d'
    ,'5b4f047c-1aea-4a3c-bbdf-22c149864d3d'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'c7821414-c3f3-01b7-3b5e-638b4bdf01b4'
        ,'{"Values":[{ "Culture":"ca","Data":"Claim de Perfil"},{ "Culture":"es","Data":"Claim de Perfil"},{ "Culture":"it","Data":"Rivendicazione di ruolo"},{ "Culture":"pt","Data":"Claim de Perfil"},{ "Culture":"en","Data":"Role Claim"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'5b4f047c-1aea-4a3c-bbdf-22c149864d3d'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: RoleClaimsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Identity' AND 
                    specific_name = 'RoleClaimsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Identity].[RoleClaimsQuery]
GO

CREATE FUNCTION  [Identity].[RoleClaimsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [Identity].[RoleClaimsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [Identity].[Identity.CompanyAccessRestrictionsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [Identity].[Identity.CompanyAccessRestrictionsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= 'f3ca66b7-4c22-4828-8507-c88920a7d3ea')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= 'f3ca66b7-4c22-4828-8507-c88920a7d3ea'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    'f3ca66b7-4c22-4828-8507-c88920a7d3ea'
    ,'Identity'
    ,'CompanyAccessRestrictions'
    ,'CompanyAccessRestrictionsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Restricció d''Accés a l''Empresa"},{ "Culture":"es","Data":"Restricción de Acceso a la Empresa"},{ "Culture":"it","Data":"Limitazione dell''accesso all''azienda"},{ "Culture":"pt","Data":"Restrição de Acesso à Empresa"},{ "Culture":"en","Data":"Company Access Restriction"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Empresa, Nom de l''Empresa)"},{ "Culture":"es","Data":"(Empresa, Nombre de la Empresa)"},{ "Culture":"it","Data":"(Azienda, Nome dell''azienda)"},{ "Culture":"pt","Data":"(Empresa, Nome da Empresa)"},{ "Culture":"en","Data":"(Company, Company Name)"}]}'
    ,1
    ,'f3ca66b7-4c22-4828-8507-c88920a7d3ea'
    ,'f3ca66b7-4c22-4828-8507-c88920a7d3ea'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: Company.NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '6018cc63-6c92-0189-5e96-eb85dd8f6d94'
        ,'{"Values":[{ "Culture":"ca","Data":"Empresa"},{ "Culture":"es","Data":"Empresa"},{ "Culture":"it","Data":"Società"},{ "Culture":"pt","Data":"Empresa"},{ "Culture":"en","Data":"Company"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'f3ca66b7-4c22-4828-8507-c88920a7d3ea'
        ,0
        ,0
        ,1
        ,'Company.NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: Company.Name (CompanyName) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '0a0c900f-aad4-3ad1-dc21-88353438bf18'
        ,'{"Values":[{ "Culture":"ca","Data":"Nom de l''Empresa"},{ "Culture":"es","Data":"Nombre de la Empresa"},{ "Culture":"it","Data":"Nome della ditta"},{ "Culture":"pt","Data":"Nome da Empresa"},{ "Culture":"en","Data":"Company Name"}]}'
        ,'True'
        ,'False'
        ,1
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'f3ca66b7-4c22-4828-8507-c88920a7d3ea'
        ,0
        ,0
        ,1
        ,'Company.Name'
        ,'CompanyName'
        ,'True'
        )
GO

-- List Query TVF: CompanyAccessRestrictionsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Identity' AND 
                    specific_name = 'CompanyAccessRestrictionsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Identity].[CompanyAccessRestrictionsQuery]
GO

CREATE FUNCTION  [Identity].[CompanyAccessRestrictionsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T2].[Id], [T1].[Id] AS [ExtensionId], [T1].[IsActive], [T2].[NaturalKey] AS [NaturalKey], [T2].[Name] AS [CompanyName]
FROM [Identity].[CompanyAccessRestrictionsView] [T1]
JOIN [CorePatterns].[CompaniesView] [T2] ON ([T2].[Id] = [T1].[BaseEntityId]
AND [T2].[IsActive] = 1)
WHERE ([T2].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T2].[Name] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [Identity].[Identity.RowLevelSecurityClaimsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [Identity].[Identity.RowLevelSecurityClaimsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= 'b001ddb4-d863-4ae3-b2b0-e343bb7f1313')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= 'b001ddb4-d863-4ae3-b2b0-e343bb7f1313'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    'b001ddb4-d863-4ae3-b2b0-e343bb7f1313'
    ,'Identity'
    ,'RowLevelSecurityClaims'
    ,'RowLevelSecurityClaimsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Claim Seguretat Nivell Línia"},{ "Culture":"es","Data":"Claim Seguridad Nivel Línea"},{ "Culture":"it","Data":"Reclamo di sicurezza a livello di riga"},{ "Culture":"pt","Data":"Claim Segurança Nível Linha"},{ "Culture":"en","Data":"Row Level Security Claim"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Claim Seguretat Nivell Línia)"},{ "Culture":"es","Data":"(Claim Seguridad Nivel Línea)"},{ "Culture":"it","Data":"(Reclamo di sicurezza a livello di riga)"},{ "Culture":"pt","Data":"(Claim Segurança Nível Linha)"},{ "Culture":"en","Data":"(Row Level Security Claim)"}]}'
    ,1
    ,'b001ddb4-d863-4ae3-b2b0-e343bb7f1313'
    ,'b001ddb4-d863-4ae3-b2b0-e343bb7f1313'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '7ffd870a-8479-ba2f-2b15-4ed7cba6d5b9'
        ,'{"Values":[{ "Culture":"ca","Data":"Claim Seguretat Nivell Línia"},{ "Culture":"es","Data":"Claim Seguridad Nivel Línea"},{ "Culture":"it","Data":"Reclamo di sicurezza a livello di riga"},{ "Culture":"pt","Data":"Claim Segurança Nível Linha"},{ "Culture":"en","Data":"Row Level Security Claim"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'b001ddb4-d863-4ae3-b2b0-e343bb7f1313'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: RowLevelSecurityClaimsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Identity' AND 
                    specific_name = 'RowLevelSecurityClaimsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Identity].[RowLevelSecurityClaimsQuery]
GO

CREATE FUNCTION  [Identity].[RowLevelSecurityClaimsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [Identity].[RowLevelSecurityClaimsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [Identity].[Identity.UserAccessClaimsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [Identity].[Identity.UserAccessClaimsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '299712c3-be35-4461-95ae-1a334f922784')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '299712c3-be35-4461-95ae-1a334f922784'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '299712c3-be35-4461-95ae-1a334f922784'
    ,'Identity'
    ,'UserAccessClaims'
    ,'UserAccessClaimsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Claim d''Accés d''Usuari"},{ "Culture":"es","Data":"Claim de Acceso de Usuario"},{ "Culture":"it","Data":"Reclamo di accesso all''utente"},{ "Culture":"pt","Data":"Claim de Acesso do Utilizador"},{ "Culture":"en","Data":"User Access Claim"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Claim d''Accés d''Usuari)"},{ "Culture":"es","Data":"(Claim de Acceso de Usuario)"},{ "Culture":"it","Data":"(Reclamo di accesso all''utente)"},{ "Culture":"pt","Data":"(Claim de Acesso do Utilizador)"},{ "Culture":"en","Data":"(User Access Claim)"}]}'
    ,1
    ,'299712c3-be35-4461-95ae-1a334f922784'
    ,'299712c3-be35-4461-95ae-1a334f922784'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '87234eb2-c8f3-066e-9a40-c1ddbe6021fa'
        ,'{"Values":[{ "Culture":"ca","Data":"Claim d''Accés d''Usuari"},{ "Culture":"es","Data":"Claim de Acceso de Usuario"},{ "Culture":"it","Data":"Reclamo di accesso all''utente"},{ "Culture":"pt","Data":"Claim de Acesso do Utilizador"},{ "Culture":"en","Data":"User Access Claim"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'299712c3-be35-4461-95ae-1a334f922784'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: UserAccessClaimsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Identity' AND 
                    specific_name = 'UserAccessClaimsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Identity].[UserAccessClaimsQuery]
GO

CREATE FUNCTION  [Identity].[UserAccessClaimsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [Identity].[UserAccessClaimsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO


-- Associations Lookups


	-- Association Lookup: User_RolesForDefaultRoleQuery (Users | User | User.DefaultRole)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Identity' AND 
                    specific_name = 'User_RolesForDefaultRoleQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Identity].[User_RolesForDefaultRoleQuery]
GO

	CREATE FUNCTION  [Identity].[User_RolesForDefaultRoleQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL', @Roles NVARCHAR(255)  = '')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM (SELECT [T].[Id], [T].[NaturalKey] AS [NaturalKey], [T].[Description] AS [Description]
FROM [Identity].RolesQuery(@searchTerm, @user, @culture) [T1]
JOIN [Identity].[RolesView] [T] ON [T1].[Id] = [T].[Id]
WHERE [T].[IsActive] = 1) [SRC]
WHERE @Roles like '%' + [NaturalKey] + '%')
GO

	
	-- Association Lookup: User_CulturesForCultureQuery (Users | User | User.Culture)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Identity' AND 
                    specific_name = 'User_CulturesForCultureQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Identity].[User_CulturesForCultureQuery]
GO

	CREATE FUNCTION  [Identity].[User_CulturesForCultureQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].CulturesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- Identity.Verify_User_RolesForDefaultRoleQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'Identity' AND 
                    [SPECIFIC_NAME] = 'Verify_User_RolesForDefaultRoleQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [Identity].[Verify_User_RolesForDefaultRoleQuery]
GO

-- [Identity].Verify_User_RolesForDefaultRoleQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'Identity' AND 
                    [DOMAIN_NAME] = 'Verify_User_RolesForDefaultRoleQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [Identity].Verify_User_RolesForDefaultRoleQuery_Parameters
GO

CREATE TYPE [Identity].Verify_User_RolesForDefaultRoleQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
	,Roles nvarchar(255) DEFAULT(NULL)
);
GO

-- Identity.Verify_User_RolesForDefaultRoleQuery

CREATE FUNCTION [Identity].[Verify_User_RolesForDefaultRoleQuery] (
     @List AS [Identity].Verify_User_RolesForDefaultRoleQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Identity].[User_RolesForDefaultRoleQuery](List.NaturalKey, @User, @Culture,List.Roles)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- Identity.Verify_User_CulturesForCultureQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'Identity' AND 
                    [SPECIFIC_NAME] = 'Verify_User_CulturesForCultureQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [Identity].[Verify_User_CulturesForCultureQuery]
GO

-- [Identity].Verify_User_CulturesForCultureQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'Identity' AND 
                    [DOMAIN_NAME] = 'Verify_User_CulturesForCultureQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [Identity].Verify_User_CulturesForCultureQuery_Parameters
GO

CREATE TYPE [Identity].Verify_User_CulturesForCultureQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- Identity.Verify_User_CulturesForCultureQuery

CREATE FUNCTION [Identity].[Verify_User_CulturesForCultureQuery] (
     @List AS [Identity].Verify_User_CulturesForCultureQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Identity].[User_CulturesForCultureQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [Identity].[Identity.Users_RolesForDefaultRoleLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [Identity].[Identity.Users_RolesForDefaultRoleLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= 'e29a8e1b-5762-4eba-a98c-c15e2fbeb9fb')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= 'e29a8e1b-5762-4eba-a98c-c15e2fbeb9fb'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    'e29a8e1b-5762-4eba-a98c-c15e2fbeb9fb'
    ,'Identity'
    ,'Users'
    ,'Users_RolesForDefaultRoleLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Perfil"},{ "Culture":"es","Data":"Perfil"},{ "Culture":"it","Data":"Ruolo"},{ "Culture":"pt","Data":"Perfil"},{ "Culture":"en","Data":"Role"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Perfil, Descripció)"},{ "Culture":"es","Data":"(Perfil, Descripción)"},{ "Culture":"it","Data":"(Ruolo, descrizione)"},{ "Culture":"pt","Data":"(Perfil, Descrição)"},{ "Culture":"en","Data":"(Role, Description)"}]}'
    ,1
    ,'41615546-ecb4-4ab8-85a1-e9dac8a4c7c5'
    ,'e29a8e1b-5762-4eba-a98c-c15e2fbeb9fb'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'd5cc87ca-d314-c76b-e58d-a6be80b65f41'
        ,'{"Values":[{ "Culture":"ca","Data":"Perfil"},{ "Culture":"es","Data":"Perfil"},{ "Culture":"it","Data":"Ruolo"},{ "Culture":"pt","Data":"Perfil"},{ "Culture":"en","Data":"Role"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'e29a8e1b-5762-4eba-a98c-c15e2fbeb9fb'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: Description (Description) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '386361e3-ab12-05c1-3822-385c7a699f19'
        ,'{"Values":[{ "Culture":"ca","Data":"Descripció"},{ "Culture":"es","Data":"Descripción"},{ "Culture":"it","Data":"Descrizione"},{ "Culture":"pt","Data":"Descrição"},{ "Culture":"en","Data":"Description"}]}'
        ,'True'
        ,'False'
        ,1
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'e29a8e1b-5762-4eba-a98c-c15e2fbeb9fb'
        ,0
        ,0
        ,1
        ,'Description'
        ,'Description'
        ,'True'
        )
GO


	-- Association Lookup: RoleClaim_RolesForRoleQuery (RoleClaims | RoleClaim | RoleClaim.Role)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Identity' AND 
                    specific_name = 'RoleClaim_RolesForRoleQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Identity].[RoleClaim_RolesForRoleQuery]
GO

	CREATE FUNCTION  [Identity].[RoleClaim_RolesForRoleQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [Identity].RolesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
	-- Association Lookup: RoleClaim_OperationsForOperationQuery (RoleClaims | RoleClaim | RoleClaim.Operation)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Identity' AND 
                    specific_name = 'RoleClaim_OperationsForOperationQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Identity].[RoleClaim_OperationsForOperationQuery]
GO

	CREATE FUNCTION  [Identity].[RoleClaim_OperationsForOperationQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].OperationsQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- Identity.Verify_RoleClaim_RolesForRoleQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'Identity' AND 
                    [SPECIFIC_NAME] = 'Verify_RoleClaim_RolesForRoleQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [Identity].[Verify_RoleClaim_RolesForRoleQuery]
GO

-- [Identity].Verify_RoleClaim_RolesForRoleQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'Identity' AND 
                    [DOMAIN_NAME] = 'Verify_RoleClaim_RolesForRoleQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [Identity].Verify_RoleClaim_RolesForRoleQuery_Parameters
GO

CREATE TYPE [Identity].Verify_RoleClaim_RolesForRoleQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- Identity.Verify_RoleClaim_RolesForRoleQuery

CREATE FUNCTION [Identity].[Verify_RoleClaim_RolesForRoleQuery] (
     @List AS [Identity].Verify_RoleClaim_RolesForRoleQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Identity].[RoleClaim_RolesForRoleQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- Identity.Verify_RoleClaim_OperationsForOperationQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'Identity' AND 
                    [SPECIFIC_NAME] = 'Verify_RoleClaim_OperationsForOperationQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [Identity].[Verify_RoleClaim_OperationsForOperationQuery]
GO

-- [Identity].Verify_RoleClaim_OperationsForOperationQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'Identity' AND 
                    [DOMAIN_NAME] = 'Verify_RoleClaim_OperationsForOperationQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [Identity].Verify_RoleClaim_OperationsForOperationQuery_Parameters
GO

CREATE TYPE [Identity].Verify_RoleClaim_OperationsForOperationQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- Identity.Verify_RoleClaim_OperationsForOperationQuery

CREATE FUNCTION [Identity].[Verify_RoleClaim_OperationsForOperationQuery] (
     @List AS [Identity].Verify_RoleClaim_OperationsForOperationQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Identity].[RoleClaim_OperationsForOperationQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- Association Lookup: CompanyAccessRestriction_GroupsForRestrictedGroupsGroupQuery (CompanyAccessRestrictions | CompanyAccessRestriction | (RestrictedGroups) RestrictedGroup.Group)

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Identity' AND 
                    specific_name = 'CompanyAccessRestriction_GroupsForRestrictedGroupsGroupQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Identity].[CompanyAccessRestriction_GroupsForRestrictedGroupsGroupQuery]
GO

CREATE FUNCTION  [Identity].[CompanyAccessRestriction_GroupsForRestrictedGroupsGroupQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [Identity].GroupsQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO


-- Identity.Verify_CompanyAccessRestriction_GroupsForRestrictedGroupsGroupQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'Identity' AND 
                    [SPECIFIC_NAME] = 'Verify_CompanyAccessRestriction_GroupsForRestrictedGroupsGroupQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [Identity].[Verify_CompanyAccessRestriction_GroupsForRestrictedGroupsGroupQuery]
GO

-- [Identity].Verify_CompanyAccessRestriction_GroupsForRestrictedGroupsGroupQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'Identity' AND 
                    [DOMAIN_NAME] = 'Verify_CompanyAccessRestriction_GroupsForRestrictedGroupsGroupQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [Identity].Verify_CompanyAccessRestriction_GroupsForRestrictedGroupsGroupQuery_Parameters
GO

CREATE TYPE [Identity].Verify_CompanyAccessRestriction_GroupsForRestrictedGroupsGroupQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- Identity.Verify_CompanyAccessRestriction_GroupsForRestrictedGroupsGroupQuery

CREATE FUNCTION [Identity].[Verify_CompanyAccessRestriction_GroupsForRestrictedGroupsGroupQuery] (
     @List AS [Identity].Verify_CompanyAccessRestriction_GroupsForRestrictedGroupsGroupQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Identity].[CompanyAccessRestriction_GroupsForRestrictedGroupsGroupQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


	-- Association Lookup: RowLevelSecurityClaim_SchemaEntitiesForSchemaEntityQuery (RowLevelSecurityClaims | RowLevelSecurityClaim | RowLevelSecurityClaim.SchemaEntity)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Identity' AND 
                    specific_name = 'RowLevelSecurityClaim_SchemaEntitiesForSchemaEntityQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Identity].[RowLevelSecurityClaim_SchemaEntitiesForSchemaEntityQuery]
GO

	CREATE FUNCTION  [Identity].[RowLevelSecurityClaim_SchemaEntitiesForSchemaEntityQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].SchemaEntitiesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- Identity.Verify_RowLevelSecurityClaim_SchemaEntitiesForSchemaEntityQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'Identity' AND 
                    [SPECIFIC_NAME] = 'Verify_RowLevelSecurityClaim_SchemaEntitiesForSchemaEntityQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [Identity].[Verify_RowLevelSecurityClaim_SchemaEntitiesForSchemaEntityQuery]
GO

-- [Identity].Verify_RowLevelSecurityClaim_SchemaEntitiesForSchemaEntityQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'Identity' AND 
                    [DOMAIN_NAME] = 'Verify_RowLevelSecurityClaim_SchemaEntitiesForSchemaEntityQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [Identity].Verify_RowLevelSecurityClaim_SchemaEntitiesForSchemaEntityQuery_Parameters
GO

CREATE TYPE [Identity].Verify_RowLevelSecurityClaim_SchemaEntitiesForSchemaEntityQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- Identity.Verify_RowLevelSecurityClaim_SchemaEntitiesForSchemaEntityQuery

CREATE FUNCTION [Identity].[Verify_RowLevelSecurityClaim_SchemaEntitiesForSchemaEntityQuery] (
     @List AS [Identity].Verify_RowLevelSecurityClaim_SchemaEntitiesForSchemaEntityQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Identity].[RowLevelSecurityClaim_SchemaEntitiesForSchemaEntityQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


	-- Association Lookup: UserAccessClaim_UsersForUserQuery (UserAccessClaims | UserAccessClaim | UserAccessClaim.User)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Identity' AND 
                    specific_name = 'UserAccessClaim_UsersForUserQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Identity].[UserAccessClaim_UsersForUserQuery]
GO

	CREATE FUNCTION  [Identity].[UserAccessClaim_UsersForUserQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [Identity].UsersQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- Identity.Verify_UserAccessClaim_UsersForUserQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'Identity' AND 
                    [SPECIFIC_NAME] = 'Verify_UserAccessClaim_UsersForUserQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [Identity].[Verify_UserAccessClaim_UsersForUserQuery]
GO

-- [Identity].Verify_UserAccessClaim_UsersForUserQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'Identity' AND 
                    [DOMAIN_NAME] = 'Verify_UserAccessClaim_UsersForUserQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [Identity].Verify_UserAccessClaim_UsersForUserQuery_Parameters
GO

CREATE TYPE [Identity].Verify_UserAccessClaim_UsersForUserQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- Identity.Verify_UserAccessClaim_UsersForUserQuery

CREATE FUNCTION [Identity].[Verify_UserAccessClaim_UsersForUserQuery] (
     @List AS [Identity].Verify_UserAccessClaim_UsersForUserQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Identity].[UserAccessClaim_UsersForUserQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO



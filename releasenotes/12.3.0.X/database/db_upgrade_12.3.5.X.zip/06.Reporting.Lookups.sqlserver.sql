﻿-- Entity Lookups

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [Reporting].[Reporting.TemplatesLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [Reporting].[Reporting.TemplatesLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= 'be80e138-7b33-42ed-a634-485a47977aa9')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= 'be80e138-7b33-42ed-a634-485a47977aa9'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    'be80e138-7b33-42ed-a634-485a47977aa9'
    ,'Reporting'
    ,'Templates'
    ,'TemplatesLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Plantilla"},{ "Culture":"es","Data":"Plantilla"},{ "Culture":"it","Data":"Modello"},{ "Culture":"pt","Data":"Modelo"},{ "Culture":"en","Data":"Template"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Plantilla)"},{ "Culture":"es","Data":"(Plantilla)"},{ "Culture":"it","Data":"(Modello)"},{ "Culture":"pt","Data":"(Modelo)"},{ "Culture":"en","Data":"(Template)"}]}'
    ,1
    ,'be80e138-7b33-42ed-a634-485a47977aa9'
    ,'be80e138-7b33-42ed-a634-485a47977aa9'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'd2989aae-c93f-2acf-ad0b-aed88a704454'
        ,'{"Values":[{ "Culture":"ca","Data":"Plantilla"},{ "Culture":"es","Data":"Plantilla"},{ "Culture":"it","Data":"Modello"},{ "Culture":"pt","Data":"Modelo"},{ "Culture":"en","Data":"Template"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'be80e138-7b33-42ed-a634-485a47977aa9'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: TemplatesQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Reporting' AND 
                    specific_name = 'TemplatesQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Reporting].[TemplatesQuery]
GO

CREATE FUNCTION  [Reporting].[TemplatesQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [Reporting].[TemplatesView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [Reporting].[Reporting.ReportModelDefinitionsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [Reporting].[Reporting.ReportModelDefinitionsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '4b4f2b3a-c6e9-43e3-8879-a81dc1642c7a')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '4b4f2b3a-c6e9-43e3-8879-a81dc1642c7a'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '4b4f2b3a-c6e9-43e3-8879-a81dc1642c7a'
    ,'Reporting'
    ,'ReportModelDefinitions'
    ,'ReportModelDefinitionsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Definició del Model d''Informe"},{ "Culture":"es","Data":"Definición del Modelo de Informe"},{ "Culture":"it","Data":"Segnala la definizione del modello."},{ "Culture":"pt","Data":"Definição do Modelo de Relatório"},{ "Culture":"en","Data":"Report Model Definition"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"Definició del Model d''Informe"},{ "Culture":"es","Data":"Definición del Modelo de Informe"},{ "Culture":"it","Data":"(Definizione del modello di report)"},{ "Culture":"pt","Data":"Definição do Modelo de Relatório"},{ "Culture":"en","Data":"(Report Model Definition)"}]}'
    ,1
    ,'4b4f2b3a-c6e9-43e3-8879-a81dc1642c7a'
    ,'4b4f2b3a-c6e9-43e3-8879-a81dc1642c7a'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '5dd61319-40bd-a86f-97cc-cc6babcd5b01'
        ,'{"Values":[{ "Culture":"ca","Data":"Definició del Model d''Informe"},{ "Culture":"es","Data":"Definición del Modelo de Informe"},{ "Culture":"it","Data":"Segnala la definizione del modello."},{ "Culture":"pt","Data":"Definição do Modelo de Relatório"},{ "Culture":"en","Data":"Report Model Definition"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'4b4f2b3a-c6e9-43e3-8879-a81dc1642c7a'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: ReportModelDefinitionsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Reporting' AND 
                    specific_name = 'ReportModelDefinitionsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Reporting].[ReportModelDefinitionsQuery]
GO

CREATE FUNCTION  [Reporting].[ReportModelDefinitionsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [Reporting].[ReportModelDefinitionsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [Reporting].[Reporting.TemplateEntityGroupsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [Reporting].[Reporting.TemplateEntityGroupsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '51bc9fa1-acc8-4452-beac-059f7c52bf87')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '51bc9fa1-acc8-4452-beac-059f7c52bf87'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '51bc9fa1-acc8-4452-beac-059f7c52bf87'
    ,'Reporting'
    ,'TemplateEntityGroups'
    ,'TemplateEntityGroupsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Grup d''Entitat de Plantilla"},{ "Culture":"es","Data":"Grupo de Entidad de Plantilla"},{ "Culture":"it","Data":"Gruppo di entità del modello"},{ "Culture":"pt","Data":"Grupo de Entidade de Modelo"},{ "Culture":"en","Data":"Template Entity Group"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Grup d''Entitat de Plantilla, Descripció)"},{ "Culture":"es","Data":"(Grupo de Entidad de Plantilla, Descripción)"},{ "Culture":"it","Data":"(Gruppo di entità del modello, Descrizione)"},{ "Culture":"pt","Data":"(Grupo de Entidade de Modelo, Descrição)"},{ "Culture":"en","Data":"(Template Entity Group, Description)"}]}'
    ,1
    ,'51bc9fa1-acc8-4452-beac-059f7c52bf87'
    ,'51bc9fa1-acc8-4452-beac-059f7c52bf87'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '3d12cef2-38f3-44be-dcb0-a6019e660167'
        ,'{"Values":[{ "Culture":"ca","Data":"Grup d''Entitat de Plantilla"},{ "Culture":"es","Data":"Grupo de Entidad de Plantilla"},{ "Culture":"it","Data":"Gruppo di entità del modello"},{ "Culture":"pt","Data":"Grupo de Entidade de Modelo"},{ "Culture":"en","Data":"Template Entity Group"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'51bc9fa1-acc8-4452-beac-059f7c52bf87'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: Description (Description) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '0858b1c8-50b2-ae03-51ba-408380b540d5'
        ,'{"Values":[{ "Culture":"ca","Data":"Descripció"},{ "Culture":"es","Data":"Descripción"},{ "Culture":"it","Data":"Descrizione"},{ "Culture":"pt","Data":"Descrição"},{ "Culture":"en","Data":"Description"}]}'
        ,'True'
        ,'False'
        ,1
        ,'Text'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'51bc9fa1-acc8-4452-beac-059f7c52bf87'
        ,0
        ,0
        ,1
        ,'Description'
        ,'Description'
        ,'True'
        )
GO

-- List Query TVF: TemplateEntityGroupsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Reporting' AND 
                    specific_name = 'TemplateEntityGroupsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Reporting].[TemplateEntityGroupsQuery]
GO

CREATE FUNCTION  [Reporting].[TemplateEntityGroupsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey], [T1].[Description] AS [Description]
FROM [Reporting].[TemplateEntityGroupsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[Description] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- List Query TVF: OperationReportsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Reporting' AND 
                    specific_name = 'OperationReportsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Reporting].[OperationReportsQuery]
GO

CREATE FUNCTION  [Reporting].[OperationReportsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [Reporting].[OperationReportsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [Reporting].[Reporting.OfflineReportsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [Reporting].[Reporting.OfflineReportsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= 'fd3ffcbc-7c71-482f-b1de-ae71afb33dbd')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= 'fd3ffcbc-7c71-482f-b1de-ae71afb33dbd'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    'fd3ffcbc-7c71-482f-b1de-ae71afb33dbd'
    ,'Reporting'
    ,'OfflineReports'
    ,'OfflineReportsLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Informe de Dades"},{ "Culture":"es","Data":"Informe de Datos"},{ "Culture":"it","Data":"Rapporto dei dati"},{ "Culture":"pt","Data":"Relatório de Dados"},{ "Culture":"en","Data":"Data Report"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Informe de Dades, Descripció)"},{ "Culture":"es","Data":"(Informe de Datos, Descripción)"},{ "Culture":"it","Data":"(Rapporto dati, Descrizione)"},{ "Culture":"pt","Data":"(Relatório de Dados, Descrição)"},{ "Culture":"en","Data":"(Data Report, Description)"}]}'
    ,1
    ,'fd3ffcbc-7c71-482f-b1de-ae71afb33dbd'
    ,'fd3ffcbc-7c71-482f-b1de-ae71afb33dbd'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'a488aa07-9afd-0197-b145-e1be9adf0abb'
        ,'{"Values":[{ "Culture":"ca","Data":"Informe de Dades"},{ "Culture":"es","Data":"Informe de Datos"},{ "Culture":"it","Data":"Rapporto dei dati"},{ "Culture":"pt","Data":"Relatório de Dados"},{ "Culture":"en","Data":"Data Report"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'fd3ffcbc-7c71-482f-b1de-ae71afb33dbd'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: Description (Description) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'f72aa2a4-799b-a911-8436-06c913e340c3'
        ,'{"Values":[{ "Culture":"ca","Data":"Descripció"},{ "Culture":"es","Data":"Descripción"},{ "Culture":"it","Data":"Descrizione"},{ "Culture":"pt","Data":"Descrição"},{ "Culture":"en","Data":"Description"}]}'
        ,'True'
        ,'False'
        ,1
        ,'Text'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'fd3ffcbc-7c71-482f-b1de-ae71afb33dbd'
        ,0
        ,0
        ,1
        ,'Description'
        ,'Description'
        ,'True'
        )
GO

-- List Query TVF: OfflineReportsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Reporting' AND 
                    specific_name = 'OfflineReportsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Reporting].[OfflineReportsQuery]
GO

CREATE FUNCTION  [Reporting].[OfflineReportsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey], [T1].[Description] AS [Description]
FROM [Reporting].[OfflineReportsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[Description] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO


-- Associations Lookups


-- Association Lookup: TemplateEntityGroup_SchemaEntitiesForGroupSchemaEntitiesSchemaEntityQuery (TemplateEntityGroups | TemplateEntityGroup | (GroupSchemaEntities) GroupSchemaEntity.SchemaEntity)

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Reporting' AND 
                    specific_name = 'TemplateEntityGroup_SchemaEntitiesForGroupSchemaEntitiesSchemaEntityQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Reporting].[TemplateEntityGroup_SchemaEntitiesForGroupSchemaEntitiesSchemaEntityQuery]
GO

CREATE FUNCTION  [Reporting].[TemplateEntityGroup_SchemaEntitiesForGroupSchemaEntitiesSchemaEntityQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].SchemaEntitiesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO


-- Association Lookup: TemplateEntityGroup_TemplatesForGroupTemplatesTemplateQuery (TemplateEntityGroups | TemplateEntityGroup | (GroupTemplates) GroupTemplate.Template)

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Reporting' AND 
                    specific_name = 'TemplateEntityGroup_TemplatesForGroupTemplatesTemplateQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Reporting].[TemplateEntityGroup_TemplatesForGroupTemplatesTemplateQuery]
GO

CREATE FUNCTION  [Reporting].[TemplateEntityGroup_TemplatesForGroupTemplatesTemplateQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL', @TemplateType NVARCHAR(20)  = '')
RETURNS TABLE
AS
RETURN
(SELECT [SRC].[Id], [SRC].[NaturalKey], [SRC].[TemplateKey], [SRC].[Description], [SRC].[ReportTypeValue]
FROM (SELECT [T].[Id], [T].[NaturalKey] AS [NaturalKey], [T].[TemplateKey] AS [TemplateKey], [T].[Description] AS [Description], [T3].[Name] AS [ReportType], [CorePatterns].[GetLocalizedValue]([T3].[Description], @culture) AS [ReportTypeValue]
FROM [Reporting].TemplatesQuery(@searchTerm, @user, @culture) [T1]
JOIN [Reporting].[TemplatesView] [T] ON [T1].[Id] = [T].[Id]
LEFT JOIN [Reporting].[ReportTypesView] [T3] ON [T].[ReportTypeId] = [T3].[Id]
WHERE [T].[IsActive] = 1) [SRC]
WHERE ReportType = @TemplateType)
GO


-- Reporting.Verify_TemplateEntityGroup_SchemaEntitiesForGroupSchemaEntitiesSchemaEntityQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'Reporting' AND 
                    [SPECIFIC_NAME] = 'Verify_TemplateEntityGroup_SchemaEntitiesForGroupSchemaEntitiesSchemaEntityQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [Reporting].[Verify_TemplateEntityGroup_SchemaEntitiesForGroupSchemaEntitiesSchemaEntityQuery]
GO

-- [Reporting].Verify_TemplateEntityGroup_SchemaEntitiesForGroupSchemaEntitiesSchemaEntityQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'Reporting' AND 
                    [DOMAIN_NAME] = 'Verify_TemplateEntityGroup_SchemaEntitiesForGroupSchemaEntitiesSchemaEntityQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [Reporting].Verify_TemplateEntityGroup_SchemaEntitiesForGroupSchemaEntitiesSchemaEntityQuery_Parameters
GO

CREATE TYPE [Reporting].Verify_TemplateEntityGroup_SchemaEntitiesForGroupSchemaEntitiesSchemaEntityQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- Reporting.Verify_TemplateEntityGroup_SchemaEntitiesForGroupSchemaEntitiesSchemaEntityQuery

CREATE FUNCTION [Reporting].[Verify_TemplateEntityGroup_SchemaEntitiesForGroupSchemaEntitiesSchemaEntityQuery] (
     @List AS [Reporting].Verify_TemplateEntityGroup_SchemaEntitiesForGroupSchemaEntitiesSchemaEntityQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Reporting].[TemplateEntityGroup_SchemaEntitiesForGroupSchemaEntitiesSchemaEntityQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- Reporting.Verify_TemplateEntityGroup_TemplatesForGroupTemplatesTemplateQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'Reporting' AND 
                    [SPECIFIC_NAME] = 'Verify_TemplateEntityGroup_TemplatesForGroupTemplatesTemplateQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [Reporting].[Verify_TemplateEntityGroup_TemplatesForGroupTemplatesTemplateQuery]
GO

-- [Reporting].Verify_TemplateEntityGroup_TemplatesForGroupTemplatesTemplateQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'Reporting' AND 
                    [DOMAIN_NAME] = 'Verify_TemplateEntityGroup_TemplatesForGroupTemplatesTemplateQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [Reporting].Verify_TemplateEntityGroup_TemplatesForGroupTemplatesTemplateQuery_Parameters
GO

CREATE TYPE [Reporting].Verify_TemplateEntityGroup_TemplatesForGroupTemplatesTemplateQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
	,TemplateType nvarchar(20) DEFAULT(NULL)
);
GO

-- Reporting.Verify_TemplateEntityGroup_TemplatesForGroupTemplatesTemplateQuery

CREATE FUNCTION [Reporting].[Verify_TemplateEntityGroup_TemplatesForGroupTemplatesTemplateQuery] (
     @List AS [Reporting].Verify_TemplateEntityGroup_TemplatesForGroupTemplatesTemplateQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Reporting].[TemplateEntityGroup_TemplatesForGroupTemplatesTemplateQuery](List.NaturalKey, @User, @Culture,List.TemplateType)
         ) AS [MatchId]
    FROM @List AS List
)
GO

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [Reporting].[Reporting.TemplateEntityGroups_TemplatesForGroupTemplatesTemplateLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [Reporting].[Reporting.TemplateEntityGroups_TemplatesForGroupTemplatesTemplateLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= '63174023-a5e1-4eba-a733-b03af28acf40')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= '63174023-a5e1-4eba-a733-b03af28acf40'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    '63174023-a5e1-4eba-a733-b03af28acf40'
    ,'Reporting'
    ,'TemplateEntityGroups'
    ,'TemplateEntityGroups_TemplatesForGroupTemplatesTemplateLookup'
	,'{"Values":[{ "Culture":"ca","Data":"Plantilla"},{ "Culture":"es","Data":"Plantilla"},{ "Culture":"it","Data":"Modello"},{ "Culture":"pt","Data":"Modelo"},{ "Culture":"en","Data":"Template"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"ca","Data":"(Plantilla)"},{ "Culture":"es","Data":"(Plantilla)"},{ "Culture":"it","Data":"(Modello)"},{ "Culture":"pt","Data":"(Modelo)"},{ "Culture":"en","Data":"(Template)"}]}'
    ,1
    ,'be80e138-7b33-42ed-a634-485a47977aa9'
    ,'63174023-a5e1-4eba-a733-b03af28acf40'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '91fb7c7f-71d2-742b-d7e6-138e1685d815'
        ,'{"Values":[{ "Culture":"ca","Data":"Plantilla"},{ "Culture":"es","Data":"Plantilla"},{ "Culture":"it","Data":"Modello"},{ "Culture":"pt","Data":"Modelo"},{ "Culture":"en","Data":"Template"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'63174023-a5e1-4eba-a733-b03af28acf40'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO


-- Column: TemplateKey (TemplateKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'e1291452-cea7-75b2-1a26-482248508a29'
        ,'{"Values":[{ "Culture":"ca","Data":"Plantilla"},{ "Culture":"es","Data":"Plantilla"},{ "Culture":"it","Data":"Modello"},{ "Culture":"pt","Data":"Modelo"},{ "Culture":"en","Data":"Template"}]}'
        ,'True'
        ,'False'
        ,1
        ,'Text'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'63174023-a5e1-4eba-a733-b03af28acf40'
        ,0
        ,0
        ,1
        ,'TemplateKey'
        ,'TemplateKey'
        ,'True'
        )
GO


-- Column: Description (Description) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'cb1907b1-0fd6-e1ca-e65f-f01775597352'
        ,'{"Values":[{ "Culture":"ca","Data":"Descripció"},{ "Culture":"es","Data":"Descripción"},{ "Culture":"it","Data":"Descrizione"},{ "Culture":"pt","Data":"Descrição"},{ "Culture":"en","Data":"Description"}]}'
        ,'True'
        ,'False'
        ,2
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'63174023-a5e1-4eba-a733-b03af28acf40'
        ,0
        ,0
        ,1
        ,'Description'
        ,'Description'
        ,'True'
        )
GO


-- Column: ReportType (ReportTypeValue) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '06c27129-c703-b867-08f7-462ca4d596d3'
        ,'{"Values":[{ "Culture":"ca","Data":"Tipus d''Informe"},{ "Culture":"es","Data":"Tipo de Informe"},{ "Culture":"it","Data":"Tipo di rapporto"},{ "Culture":"pt","Data":"Tipo de Relatório"},{ "Culture":"en","Data":"Report Type"}]}'
        ,'True'
        ,'False'
        ,3
        ,'ValueListItem'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'63174023-a5e1-4eba-a733-b03af28acf40'
        ,0
        ,0
        ,1
        ,'ReportType'
        ,'ReportTypeValue'
        ,'True'
        )
GO


	-- Association Lookup: ReportModelDefinition_SchemaEntitiesForEntityQuery (ReportModelDefinitions | ReportModelDefinition | ReportModelDefinition.Entity)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Reporting' AND 
                    specific_name = 'ReportModelDefinition_SchemaEntitiesForEntityQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Reporting].[ReportModelDefinition_SchemaEntitiesForEntityQuery]
GO

	CREATE FUNCTION  [Reporting].[ReportModelDefinition_SchemaEntitiesForEntityQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].SchemaEntitiesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
	-- Association Lookup: ReportModelDefinition_TemplatesForTemplateQuery (ReportModelDefinitions | ReportModelDefinition | ReportModelDefinition.Template)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Reporting' AND 
                    specific_name = 'ReportModelDefinition_TemplatesForTemplateQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Reporting].[ReportModelDefinition_TemplatesForTemplateQuery]
GO

	CREATE FUNCTION  [Reporting].[ReportModelDefinition_TemplatesForTemplateQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [Reporting].TemplatesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- Reporting.Verify_ReportModelDefinition_SchemaEntitiesForEntityQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'Reporting' AND 
                    [SPECIFIC_NAME] = 'Verify_ReportModelDefinition_SchemaEntitiesForEntityQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [Reporting].[Verify_ReportModelDefinition_SchemaEntitiesForEntityQuery]
GO

-- [Reporting].Verify_ReportModelDefinition_SchemaEntitiesForEntityQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'Reporting' AND 
                    [DOMAIN_NAME] = 'Verify_ReportModelDefinition_SchemaEntitiesForEntityQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [Reporting].Verify_ReportModelDefinition_SchemaEntitiesForEntityQuery_Parameters
GO

CREATE TYPE [Reporting].Verify_ReportModelDefinition_SchemaEntitiesForEntityQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- Reporting.Verify_ReportModelDefinition_SchemaEntitiesForEntityQuery

CREATE FUNCTION [Reporting].[Verify_ReportModelDefinition_SchemaEntitiesForEntityQuery] (
     @List AS [Reporting].Verify_ReportModelDefinition_SchemaEntitiesForEntityQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Reporting].[ReportModelDefinition_SchemaEntitiesForEntityQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- Reporting.Verify_ReportModelDefinition_TemplatesForTemplateQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'Reporting' AND 
                    [SPECIFIC_NAME] = 'Verify_ReportModelDefinition_TemplatesForTemplateQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [Reporting].[Verify_ReportModelDefinition_TemplatesForTemplateQuery]
GO

-- [Reporting].Verify_ReportModelDefinition_TemplatesForTemplateQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'Reporting' AND 
                    [DOMAIN_NAME] = 'Verify_ReportModelDefinition_TemplatesForTemplateQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [Reporting].Verify_ReportModelDefinition_TemplatesForTemplateQuery_Parameters
GO

CREATE TYPE [Reporting].Verify_ReportModelDefinition_TemplatesForTemplateQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- Reporting.Verify_ReportModelDefinition_TemplatesForTemplateQuery

CREATE FUNCTION [Reporting].[Verify_ReportModelDefinition_TemplatesForTemplateQuery] (
     @List AS [Reporting].Verify_ReportModelDefinition_TemplatesForTemplateQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Reporting].[ReportModelDefinition_TemplatesForTemplateQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


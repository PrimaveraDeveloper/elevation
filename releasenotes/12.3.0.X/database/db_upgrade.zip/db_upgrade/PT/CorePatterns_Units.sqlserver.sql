﻿
IF EXISTS (select 1 from [CorePatterns].[Units] where Id = N'e10f8d79-480f-44ee-a799-0d98cfe65442')
BEGIN
	update [CorePatterns].[Units] set UnecerEc20Code = N'C62' where Id = N'e10f8d79-480f-44ee-a799-0d98cfe65442'
END

IF EXISTS (select 1 from [CorePatterns].[Units] where Id = N'21707f0c-1546-45f9-a047-efe03f2dae4c')
BEGIN
	update [CorePatterns].[Units] set UnecerEc20Code = N'KGM' where Id = N'21707f0c-1546-45f9-a047-efe03f2dae4c'
END

IF EXISTS (select 1 from [CorePatterns].[Units] where Id = N'1510235a-56ea-43f9-8640-ced9a6da731f')
BEGIN
	update [CorePatterns].[Units] set UnecerEc20Code = N'SEC' where Id = N'1510235a-56ea-43f9-8640-ced9a6da731f'
END

IF EXISTS (select 1 from [CorePatterns].[Units] where Id = N'321e71be-01c5-4406-986e-2950e98cd7e9')
BEGIN
	update [CorePatterns].[Units] set UnecerEc20Code = N'HUR' where Id = N'321e71be-01c5-4406-986e-2950e98cd7e9'
END

IF EXISTS (select 1 from [CorePatterns].[Units] where Id = N'68acd6a3-2bb4-45d9-a0b6-1958f9e3e8d8')
BEGIN
	update [CorePatterns].[Units] set UnecerEc20Code = N'MTR' where Id = N'68acd6a3-2bb4-45d9-a0b6-1958f9e3e8d8'
END

IF EXISTS (select 1 from [CorePatterns].[Units] where Id = N'880b1125-0014-44af-a973-10177260e6a1')
BEGIN
	update [CorePatterns].[Units] set UnecerEc20Code = N'KMT' where Id = N'880b1125-0014-44af-a973-10177260e6a1'
END
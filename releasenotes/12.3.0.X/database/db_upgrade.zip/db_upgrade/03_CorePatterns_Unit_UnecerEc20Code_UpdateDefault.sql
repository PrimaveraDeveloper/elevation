UPDATE CorePatterns.Units
SET UnecerEc20Code = CASE UnitKey 
WHEN 'UN' THEN 'C62'
WHEN 'KG' THEN 'KGM'
WHEN 'S' THEN 'SEC'
WHEN 'HR' THEN 'HUR'
WHEN 'MT' THEN 'MTR'
WHEN 'KM' THEN 'KMT'
ELSE UnecerEc20Code
END
FROM CorePatterns.Units
GO
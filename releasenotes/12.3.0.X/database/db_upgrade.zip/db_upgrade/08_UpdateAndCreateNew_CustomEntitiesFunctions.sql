-- List Query TVF: CustomEntityRecordsQuery

IF EXISTS 
( 
	SELECT 1
	FROM Information_schema.Routines
	WHERE Specific_schema = 'CorePatterns' AND
		  specific_name = 'CustomEntityRecordsQuery' AND
		  Routine_Type = 'FUNCTION' 
)
BEGIN
	DROP Function [CorePatterns].[CustomEntityRecordsQuery]
END
GO

CREATE FUNCTION [CorePatterns].[CustomEntityRecordsQuery]
(@searchTerm NVARCHAR(100) = '%', @user NVARCHAR(100) = 'NULL', @culture NVARCHAR(100) = 'NULL', @companyId UNIQUEIDENTIFIER = NULL)
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[NaturalKey] AS [NaturalKey], [T1].[Description] AS [Description]
FROM [CorePatterns].[CustomEntityRecordsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[Description] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI))
AND (@companyId IS NULL
OR [T1].[CompanyId] = @companyId))
GO

---------------------------------------------------------------

-- Association Lookup: CustomEntityRecord_CompaniesForCompanyQuery (CustomEntityRecords | CustomEntityRecord | CustomEntityRecord.Company)

IF EXISTS 
( 
	SELECT 1
	FROM Information_schema.Routines
	WHERE Specific_schema = 'CorePatterns' AND
		  specific_name = 'CustomEntityRecord_CompaniesForCompanyQuery' AND
          Routine_Type = 'FUNCTION' 
)
BEGIN
	DROP Function [CorePatterns].[CustomEntityRecord_CompaniesForCompanyQuery]
END
GO

CREATE FUNCTION [CorePatterns].[CustomEntityRecord_CompaniesForCompanyQuery]
(@searchTerm NVARCHAR(100) = '%', @user NVARCHAR(100) = 'NULL', @culture NVARCHAR(100) = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[NaturalKey], [T1].[Name]
FROM [CorePatterns].CompaniesQuery(@searchTerm, @user, @culture) [T1]
JOIN [CorePatterns].[CompaniesView] [T] ON [T1].[Id] = [T].[Id]
WHERE [T].[IsActive] = 1)
GO

----------------------------------------------------------------

-- CorePatterns.Verify_CustomEntityRecord_CompaniesForCompanyQuery

IF EXISTS 
( 
	SELECT 1
	FROM INFORMATION_SCHEMA.ROUTINES
	WHERE [SPECIFIC_SCHEMA] = 'CorePatterns' AND
		  [SPECIFIC_NAME] = 'Verify_CustomEntityRecord_CompaniesForCompanyQuery' AND
		  [ROUTINE_TYPE] = 'FUNCTION' 
)
BEGIN
	DROP FUNCTION [CorePatterns].[Verify_CustomEntityRecord_CompaniesForCompanyQuery]
END
GO

-- [CorePatterns].Verify_CustomEntityRecord_CompaniesForCompanyQuery_Parameters

IF EXISTS 
( 
	SELECT 1
	FROM Information_schema.DOMAINS
	WHERE [DOMAIN_SCHEMA] = 'CorePatterns' AND
		  [DOMAIN_NAME] = 'Verify_CustomEntityRecord_CompaniesForCompanyQuery_Parameters' AND
		  [DATA_TYPE] = 'table type' 
)
BEGIN
	DROP TYPE [CorePatterns].Verify_CustomEntityRecord_CompaniesForCompanyQuery_Parameters
END
GO

CREATE TYPE [CorePatterns].Verify_CustomEntityRecord_CompaniesForCompanyQuery_Parameters
AS
TABLE 
(
	NaturalKey NVARCHAR(100)
);
GO

-------------------------------------------------------------

-- CorePatterns.Verify_CustomEntityRecord_CompaniesForCompanyQuery

CREATE FUNCTION [CorePatterns].[Verify_CustomEntityRecord_CompaniesForCompanyQuery] (
@List AS [CorePatterns].Verify_CustomEntityRecord_CompaniesForCompanyQuery_Parameters READONLY
,@User AS NVARCHAR(100)
,@Culture AS NVARCHAR(100)
)
RETURNS TABLE
AS
RETURN
(
SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
,[NaturalKey]
,(
SELECT TOP 1 [Id]
FROM [CorePatterns].[CustomEntityRecord_CompaniesForCompanyQuery](List.NaturalKey, @User, @Culture)
) AS [MatchId]
FROM @List AS List
)
GO
---- ElectronicCertificateStatuses

IF (Not EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Reporting' AND  TABLE_NAME = 'ElectronicCertificateStatuses'))
BEGIN 

CREATE TABLE [Reporting].[ElectronicCertificateStatuses]
(
    [Id] uniqueidentifier NOT NULL
    , [Name] nvarchar(100) NOT NULL
	, [Value] int NOT NULL
	, [Description] nvarchar(MAX) NOT NULL
) ON [PRIMARY]

ALTER TABLE [Reporting].[ElectronicCertificateStatuses] ADD CONSTRAINT [ElectronicCertificateStatuses_PK] PRIMARY KEY NONCLUSTERED ([Id])
ALTER TABLE [Reporting].[ElectronicCertificateStatuses] ADD CONSTRAINT [ElectronicCertificateStatuses_Name_UK] UNIQUE NONCLUSTERED ([Name])
ALTER TABLE [Reporting].[ElectronicCertificateStatuses] ADD CONSTRAINT [ElectronicCertificateStatuses_Value_UK] UNIQUE NONCLUSTERED ([Value])

CREATE CLUSTERED INDEX [ElectronicCertificateStatuses_IDX1] ON [Reporting].[ElectronicCertificateStatuses] ([Value])

ALTER TABLE [Reporting].[ElectronicCertificateStatuses] ADD CONSTRAINT [ElectronicCertificateStatuses_Id_DF] DEFAULT (newsequentialid()) FOR [Id]

-- Value List: ElectronicCertificateStatuses
INSERT INTO [Reporting].[ElectronicCertificateStatuses] ([Id], [Name], [Value], [Description]) VALUES ('00000000-0000-0000-0000-000000000000', 'None', 0, '{"Values":[{ "Culture":"en","Data":"None"}]}')
INSERT INTO [Reporting].[ElectronicCertificateStatuses] ([Id], [Name], [Value], [Description]) VALUES ('e4855ee8-7766-4b20-855d-3eb304da9b79', 'Inactive', 1, '{"Values":[{ "Culture":"en","Data":"Inactive"}]}')
INSERT INTO [Reporting].[ElectronicCertificateStatuses] ([Id], [Name], [Value], [Description]) VALUES ('3c044181-354f-460e-8dc0-046a202207b2', 'Active', 2, '{"Values":[{ "Culture":"en","Data":"Active"}]}')

END
GO

IF NOT EXISTS(SELECT 1 FROM sys.views WHERE Name = 'ElectronicCertificateStatusesView')
BEGIN

EXEC('CREATE VIEW [Reporting].[ElectronicCertificateStatusesView]
WITH SCHEMABINDING AS
SELECT
    E.[Id]
    , E.[Name]
	, E.[Value]
	, E.[Description]
FROM [Reporting].[ElectronicCertificateStatuses] E')

END
GO

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaEntities] WHERE Id = '06d85592-2f5a-42d0-a3c2-cf515beb37f2')
BEGIN
    INSERT INTO [CorePatterns].[SchemaEntities] ([Id], [Key], [ModuleName], [Title], [EntityTypeId], [EntityName], [Database], [BaseEntityId], [IsGenericExtension], [LockingEnabled], [HasSequenceAttribute], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [IsRestrictable]) 
    VALUES ('06d85592-2f5a-42d0-a3c2-cf515beb37f2', 'ElectronicCertificateStatuses', 'Reporting', N'{"Values":[{ "Culture":"en","Data":"Electronic Certificate Status"}]}', (SELECT Id from [CorePatterns].[SchemaEntityTypes] WHERE Name = 'ValueList'), 'Primavera.Reporting.Domain.ElectronicCertificateStatus', 'Enterprise', NULL, 0, 0, 0, 1, 0, 1, 'ELECTRONICCERTIFICATESTATUSES.REPORTING', 0)
END
GO


----------------------------------------------- ElectronicCertificates----------------------------------------------------------------------------------

IF (Not EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Reporting' AND  TABLE_NAME = 'ElectronicCertificates'))
BEGIN 

CREATE TABLE [Reporting].[ElectronicCertificates]
(
    [Id] uniqueidentifier NOT NULL
    , [CompanyId] uniqueidentifier NOT NULL
	, [AuthorizerID] nvarchar(100) NULL
	, [Secret] nvarchar(100) NULL
	, [ElectronicCertificateStatusId] uniqueidentifier NOT NULL
	, [NaturalKey] nvarchar(255) NOT NULL
	, [IsDraft] bit NOT NULL
	, [CreatedBy] nvarchar(255) NOT NULL
	, [CreatedOn] datetimeoffset(7) NOT NULL
	, [ModifiedBy] nvarchar(255) NOT NULL
	, [ModifiedOn] datetimeoffset(7) NOT NULL
	, [IsActive] bit NOT NULL
	, [IsDeleted] bit NOT NULL
	, [IsSystem] bit NOT NULL
	, [Version] timestamp NOT NULL
) ON [PRIMARY]


ALTER TABLE [Reporting].[ElectronicCertificates] ADD CONSTRAINT [ElectronicCertificates_PK] PRIMARY KEY NONCLUSTERED ([Id])
ALTER TABLE [Reporting].[ElectronicCertificates] ADD CONSTRAINT [ElectronicCertificates_UK] UNIQUE NONCLUSTERED ([CompanyId])
ALTER TABLE [Reporting].[ElectronicCertificates] ADD CONSTRAINT [ElectronicCertificates_UK2] UNIQUE NONCLUSTERED ([NaturalKey], [CompanyId])

CREATE CLUSTERED INDEX [ElectronicCertificates_IDX0] ON [Reporting].[ElectronicCertificates] ([CreatedOn])

ALTER TABLE [Reporting].[ElectronicCertificates] ADD CONSTRAINT [ElectronicCertificates_Id_DF] DEFAULT (NEWSEQUENTIALID()) FOR [Id]
ALTER TABLE [Reporting].[ElectronicCertificates] ADD CONSTRAINT [ElectronicCertificates_IsDraft_DF] DEFAULT (0) FOR [IsDraft]
ALTER TABLE [Reporting].[ElectronicCertificates] ADD CONSTRAINT [ElectronicCertificates_CreatedBy_DF] DEFAULT ('<Sys>') FOR [CreatedBy]
ALTER TABLE [Reporting].[ElectronicCertificates] ADD CONSTRAINT [ElectronicCertificates_CreatedOn_DF] DEFAULT (SYSDATETIMEOFFSET()) FOR [CreatedOn]
ALTER TABLE [Reporting].[ElectronicCertificates] ADD CONSTRAINT [ElectronicCertificates_ModifiedBy_DF] DEFAULT ('<Sys>') FOR [ModifiedBy]
ALTER TABLE [Reporting].[ElectronicCertificates] ADD CONSTRAINT [ElectronicCertificates_ModifiedOn_DF] DEFAULT (SYSDATETIMEOFFSET()) FOR [ModifiedOn]
ALTER TABLE [Reporting].[ElectronicCertificates] ADD CONSTRAINT [ElectronicCertificates_IsActive_DF] DEFAULT (1) FOR [IsActive]
ALTER TABLE [Reporting].[ElectronicCertificates] ADD CONSTRAINT [ElectronicCertificates_IsDeleted_DF] DEFAULT (0) FOR [IsDeleted]
ALTER TABLE [Reporting].[ElectronicCertificates] ADD CONSTRAINT [ElectronicCertificates_IsSystem_DF] DEFAULT (0) FOR [IsSystem]

ALTER TABLE [Reporting].[ElectronicCertificates] ADD CONSTRAINT [ElectronicCertificates_Companies_CompanyId_FK]
FOREIGN KEY ([CompanyId]) REFERENCES [CorePatterns].[Companies] ([Id])

ALTER TABLE [Reporting].[ElectronicCertificates] ADD CONSTRAINT [ElectronicCertificates_ElectronicCertificateStatuses_ElectronicCertificateStatusId_FK]
FOREIGN KEY ([ElectronicCertificateStatusId]) REFERENCES [Reporting].[ElectronicCertificateStatuses] ([Id])

END
GO

IF NOT EXISTS(SELECT 1 FROM sys.views WHERE Name = 'ElectronicCertificatesView')
BEGIN

EXEC('CREATE VIEW [Reporting].[ElectronicCertificatesView] 
WITH SCHEMABINDING AS
SELECT
    E.[Id]
    , E.[CompanyId]
	, E.[AuthorizerID]
	, E.[Secret]
	, E.[ElectronicCertificateStatusId]
	, E.[NaturalKey]
	, E.[IsDraft]
	, E.[CreatedBy]
	, E.[CreatedOn]
	, E.[ModifiedBy]
	, E.[ModifiedOn]
	, E.[IsActive]
	, E.[IsDeleted]
	, E.[IsSystem]
	, E.[Version]
	FROM [Reporting].[ElectronicCertificates] E
	WHERE E.[IsDeleted] = 0')

END
GO

IF NOT EXISTS(SELECT 1 FROM sys.views WHERE Name = 'ElectronicCertificateResourcesView')
BEGIN

EXEC('CREATE VIEW [Reporting].[ElectronicCertificateResourcesView] 
WITH SCHEMABINDING AS
SELECT
    E.[Id]
	, T0.NaturalKey as [Company]
    , E.[CompanyId]
	, T0.[Name] as [CompanyDescription]
    , E.[AuthorizerID]
    , E.[Secret]
	, T1.Value as [ElectronicCertificateStatus]
    , E.[ElectronicCertificateStatusId]
	, T1.Description as [ElectronicCertificateStatusDescription]
    , E.[NaturalKey]
    , E.[IsDraft]
    , E.[CreatedBy]
    , E.[CreatedOn]
    , E.[ModifiedBy]
    , E.[ModifiedOn]
    , E.[IsActive] 
    , E.[IsDeleted]
    , E.[IsSystem]
    , E.[Version]
FROM [Reporting].[ElectronicCertificates] E
		left join [CorePatterns].[Companies] T0 on E.CompanyId = T0.Id
		left join [Reporting].[ElectronicCertificateStatuses] T1 on E.ElectronicCertificateStatusId = T1.Id
WHERE E.[IsDeleted] = 0')

END
GO

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaEntities] WHERE Id = 'b9240a02-c628-4c24-b6a8-ea9b2f1ff290')
BEGIN
    INSERT INTO [CorePatterns].[SchemaEntities] ([Id], [Key], [ModuleName], [Title], [EntityTypeId], [EntityName], [Database], [BaseEntityId], [IsGenericExtension], [LockingEnabled], [HasSequenceAttribute], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [IsRestrictable]) 
    VALUES ('b9240a02-c628-4c24-b6a8-ea9b2f1ff290', 'ElectronicCertificates', 'Reporting', '{"Values":[{ "Culture":"en","Data":"Electronic Certificate"}]}', (SELECT Id from [CorePatterns].[SchemaEntityTypes] WHERE Id = 'd4ed5adc-1618-4e79-9263-e02e3dd6fc79'), 'Primavera.Reporting.Domain.ElectronicCertificate', 'Enterprise', NULL, 0, 0, 0, 1, 0, 1, 'ELECTRONICCERTIFICATES.REPORTING', 0 )
END
GO

-- SchemaEntityPatterns for : ElectronicCertificate
	
IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaEntityPatterns] WHERE SchemaEntityId = 'b9240a02-c628-4c24-b6a8-ea9b2f1ff290' AND InterfaceType = 'ICompanyDependent')
BEGIN
    INSERT INTO [CorePatterns].[SchemaEntityPatterns] ([Id], [Key], [InterfaceType], [SchemaEntityId], [IsActive], [IsDeleted], [IsSystem]) 
    VALUES ('c7214eb3-f33a-6d3f-3166-2f8088f43cc9', 'ICompanyDependent', 'ICompanyDependent', 'b9240a02-c628-4c24-b6a8-ea9b2f1ff290', 1, 0, 1)
END
GO

-- ElectronicCertificate.Id

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '34914ae0-b27d-4f74-b491-24f19599a20c')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Id"}]}', '34914ae0-b27d-4f74-b491-24f19599a20c', 'Id', 'UniqueIdentifier', 'False', 'False' , 1, 'b9240a02-c628-4c24-b6a8-ea9b2f1ff290', 'True', 'True', 'False', 'True', 1, 0, 1, 'ELECTRONICCERTIFICATES.REPORTING.ID', NULL, 0, 'False', 0, 0)
END
GO

-- ElectronicCertificate.NaturalKey

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'fbf533c8-7d49-4f44-9945-b6b3b1063ed0')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Electronic Certificate"}]}', 'fbf533c8-7d49-4f44-9945-b6b3b1063ed0', 'NaturalKey', 'LongText', 'False', 'False' , 1, 'b9240a02-c628-4c24-b6a8-ea9b2f1ff290', 'True', 'True', 'False', 'True', 1, 0, 1, 'ELECTRONICCERTIFICATES.REPORTING.NATURALKEY', NULL, 0, 'False', 0, 0)
END
GO

-- ElectronicCertificate.IsDraft

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'df02829f-a070-4f7b-a588-b15052136efc')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Draft"}]}', 'df02829f-a070-4f7b-a588-b15052136efc', 'IsDraft', 'Boolean', 'False', 'False' , 1, 'b9240a02-c628-4c24-b6a8-ea9b2f1ff290', 'True', 'True', 'False', 'True', 1, 0, 1, 'ELECTRONICCERTIFICATES.REPORTING.ISDRAFT', NULL, 0, 'False', 0, 0)
END
GO

-- ElectronicCertificate.CreatedBy

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'f3cfdefa-07c6-49ec-a803-13b4421628e3')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Created By"}]}', 'f3cfdefa-07c6-49ec-a803-13b4421628e3', 'CreatedBy', 'LongText', 'False', 'False' , 1, 'b9240a02-c628-4c24-b6a8-ea9b2f1ff290', 'True', 'True', 'False', 'True', 1, 0, 1, 'ELECTRONICCERTIFICATES.REPORTING.CREATEDBY', NULL, 0, 'False', 0, 0)
END
GO

-- ElectronicCertificate.CreatedOn

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '92327f7e-e5ce-40ab-9f7c-022470c7adbe')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Created On"}]}', '92327f7e-e5ce-40ab-9f7c-022470c7adbe', 'CreatedOn', 'Datetime', 'False', 'False' , 1, 'b9240a02-c628-4c24-b6a8-ea9b2f1ff290', 'True', 'True', 'False', 'True', 1, 0, 1, 'ELECTRONICCERTIFICATES.REPORTING.CREATEDON', NULL, 0, 'False', 0, 0)
END
GO

-- ElectronicCertificate.ModifiedBy

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'b68ea311-2e60-4c96-bbe1-b44c924a211e')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Modified By"}]}', 'b68ea311-2e60-4c96-bbe1-b44c924a211e', 'ModifiedBy', 'LongText', 'False', 'False' , 1, 'b9240a02-c628-4c24-b6a8-ea9b2f1ff290', 'True', 'True', 'False', 'True', 1, 0, 1, 'ELECTRONICCERTIFICATES.REPORTING.MODIFIEDBY', NULL, 0, 'False', 0, 0)
END
GO

-- ElectronicCertificate.ModifiedOn

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '67c4e84d-3bdf-4310-ba47-f5706f73a5a1')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Modified On"}]}', '67c4e84d-3bdf-4310-ba47-f5706f73a5a1', 'ModifiedOn', 'Datetime', 'False', 'False' , 1, 'b9240a02-c628-4c24-b6a8-ea9b2f1ff290', 'True', 'True', 'False', 'True', 1, 0, 1, 'ELECTRONICCERTIFICATES.REPORTING.MODIFIEDON', NULL, 0, 'False', 0, 0)
END
GO

-- ElectronicCertificate.IsActive

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '81e23d5f-ad57-486c-84f9-dbbc1f5edad4')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Active"}]}', '81e23d5f-ad57-486c-84f9-dbbc1f5edad4', 'IsActive', 'Boolean', 'False', 'False' , 1, 'b9240a02-c628-4c24-b6a8-ea9b2f1ff290', 'True', 'True', 'False', 'True', 1, 0, 1, 'ELECTRONICCERTIFICATES.REPORTING.ISACTIVE', NULL, 0, 'False', 0, 0)
END
GO

-- ElectronicCertificate.IsDeleted

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '2e5e2eed-53d1-4c54-b37a-e97053c8665d')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Deleted"}]}', '2e5e2eed-53d1-4c54-b37a-e97053c8665d', 'IsDeleted', 'Boolean', 'False', 'False' , 1, 'b9240a02-c628-4c24-b6a8-ea9b2f1ff290', 'True', 'True', 'True', 'True', 1, 0, 1, 'ELECTRONICCERTIFICATES.REPORTING.ISDELETED', NULL, 0, 'False', 0, 0)
END
GO

-- ElectronicCertificate.IsSystem

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '574c8ad3-5986-4cea-ad6c-8fc1751d83e5')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"System"}]}', '574c8ad3-5986-4cea-ad6c-8fc1751d83e5', 'IsSystem', 'Boolean', 'False', 'False' , 1, 'b9240a02-c628-4c24-b6a8-ea9b2f1ff290', 'True', 'True', 'False', 'True', 1, 0, 1, 'ELECTRONICCERTIFICATES.REPORTING.ISSYSTEM', NULL, 0, 'False', 0, 0)
END
GO

-- ElectronicCertificate.Company

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '13e1bef2-5533-4a7b-ae9a-33537df3198e')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Company"}]}', '13e1bef2-5533-4a7b-ae9a-33537df3198e', 'Company', 'View', 'True', 'False' , 1, 'b9240a02-c628-4c24-b6a8-ea9b2f1ff290', 'True', 'True', 'False', 'False', 1, 0, 1, 'ELECTRONICCERTIFICATES.REPORTING.COMPANY', 'cfceb0dc-99f3-455d-9b6d-38bb7bffa159', 0, 'False', 0, 0)
END
GO

-- ElectronicCertificate.Company

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaEntitiesAssociations] WHERE [Id] = '5681cc84-3e5e-ab99-4639-05702668c045')
BEGIN
    INSERT INTO [CorePatterns].[SchemaEntitiesAssociations] ([Id], [SchemaEntityId], [TargetId], [AttributeId], [IsComposition], [IsManyToMany], [IsActive], [IsDeleted], [IsSystem])
    VALUES ('5681cc84-3e5e-ab99-4639-05702668c045', 'b9240a02-c628-4c24-b6a8-ea9b2f1ff290', 'cfceb0dc-99f3-455d-9b6d-38bb7bffa159', '13e1bef2-5533-4a7b-ae9a-33537df3198e', 0, 0, 1, 0, 1)
END
GO

-- ElectronicCertificate.UsedSignatures

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'fba8deab-5280-4240-a183-3b069b9fd2d0')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Used Signatures"}]}', 'fba8deab-5280-4240-a183-3b069b9fd2d0', 'UsedSignatures', 'ShortText', 'False', 'False' , 1, 'b9240a02-c628-4c24-b6a8-ea9b2f1ff290', 'False', 'False', 'False', 'False', 1, 0, 1, 'ELECTRONICCERTIFICATES.REPORTING.USEDSIGNATURES', NULL, 0, 'False', 0, 0)
END
GO

-- ElectronicCertificate.AvailableSignatures

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '30e29bd2-504b-4445-8fd9-bf8787d24a55')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Available Signatures"}]}', '30e29bd2-504b-4445-8fd9-bf8787d24a55', 'AvailableSignatures', 'ShortText', 'False', 'False' , 1, 'b9240a02-c628-4c24-b6a8-ea9b2f1ff290', 'False', 'False', 'False', 'False', 1, 0, 1, 'ELECTRONICCERTIFICATES.REPORTING.AVAILABLESIGNATURES', NULL, 0, 'False', 0, 0)
END
GO

-- ElectronicCertificate.AuthorizerID

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '481b3504-b6d0-4e00-b0a2-5c734a9523dc')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Authorizer ID"}]}', '481b3504-b6d0-4e00-b0a2-5c734a9523dc', 'AuthorizerID', 'Text', 'False', 'False' , 1, 'b9240a02-c628-4c24-b6a8-ea9b2f1ff290', 'False', 'True', 'False', 'False', 1, 0, 1, 'ELECTRONICCERTIFICATES.REPORTING.AUTHORIZERID', NULL, 0, 'False', 0, 0)
END
GO

-- ElectronicCertificate.Titular

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '7540febc-7cfa-45af-88ea-e533f8952634')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Titular"}]}', '7540febc-7cfa-45af-88ea-e533f8952634', 'Titular', 'Text', 'False', 'False' , 1, 'b9240a02-c628-4c24-b6a8-ea9b2f1ff290', 'False', 'False', 'False', 'False', 1, 0, 1, 'ELECTRONICCERTIFICATES.REPORTING.TITULAR', NULL, 0, 'False', 0, 0)
END
GO

-- ElectronicCertificate.IncludedSignatures

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'ca68ec27-c230-4742-86b5-e058b10c5299')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Included Signatures"}]}', 'ca68ec27-c230-4742-86b5-e058b10c5299', 'IncludedSignatures', 'ShortText', 'False', 'False' , 1, 'b9240a02-c628-4c24-b6a8-ea9b2f1ff290', 'False', 'False', 'False', 'False', 1, 0, 1, 'ELECTRONICCERTIFICATES.REPORTING.INCLUDEDSIGNATURES', NULL, 0, 'False', 0, 0)
END
GO

-- ElectronicCertificate.ValidFrom

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '0f6f41ea-0465-4801-b85d-9fd00b705d1e')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Valid From"}]}', '0f6f41ea-0465-4801-b85d-9fd00b705d1e', 'ValidFrom', 'ShortText', 'False', 'False' , 1, 'b9240a02-c628-4c24-b6a8-ea9b2f1ff290', 'False', 'False', 'False', 'False', 1, 0, 1, 'ELECTRONICCERTIFICATES.REPORTING.VALIDFROM', NULL, 0, 'False', 0, 0)
END
GO

-- ElectronicCertificate.ValidUntil

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'a3b59893-412a-405e-a023-2c045c53979c')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Valid Until"}]}', 'a3b59893-412a-405e-a023-2c045c53979c', 'ValidUntil', 'ShortText', 'False', 'False' , 1, 'b9240a02-c628-4c24-b6a8-ea9b2f1ff290', 'False', 'False', 'False', 'False', 1, 0, 1, 'ELECTRONICCERTIFICATES.REPORTING.VALIDUNTIL', NULL, 0, 'False', 0, 0)
END
GO

-- ElectronicCertificate.AuthorizerName

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '6cf1f5ab-9fdf-40d2-a1c8-6bcf538743b1')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Authorizer Name"}]}', '6cf1f5ab-9fdf-40d2-a1c8-6bcf538743b1', 'AuthorizerName', 'Text', 'False', 'False' , 1, 'b9240a02-c628-4c24-b6a8-ea9b2f1ff290', 'False', 'False', 'False', 'False', 1, 0, 1, 'ELECTRONICCERTIFICATES.REPORTING.AUTHORIZERNAME', NULL, 0, 'False', 0, 0)
END
GO

-- ElectronicCertificate.ExpiresOn

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '0ad375b0-a433-4ecb-8357-a63e18f29ed4')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Expires On"}]}', '0ad375b0-a433-4ecb-8357-a63e18f29ed4', 'ExpiresOn', 'ShortText', 'False', 'False' , 1, 'b9240a02-c628-4c24-b6a8-ea9b2f1ff290', 'False', 'False', 'False', 'False', 1, 0, 1, 'ELECTRONICCERTIFICATES.REPORTING.EXPIRESON', NULL, 0, 'False', 0, 0)
END
GO

-- ElectronicCertificate.Secret

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '9e792543-4cd9-47d5-8477-8d4bd87e95a9')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Secret"}]}', '9e792543-4cd9-47d5-8477-8d4bd87e95a9', 'Secret', 'Text', 'False', 'False' , 1, 'b9240a02-c628-4c24-b6a8-ea9b2f1ff290', 'False', 'True', 'False', 'False', 1, 0, 1, 'ELECTRONICCERTIFICATES.REPORTING.SECRET', NULL, 0, 'False', 0, 0)
END
GO

-- ElectronicCertificate.ElectronicCertificateStatus

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '13e23f66-f92d-4582-a5fc-73397e1ccd41')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Electronic Certificate Status"}]}', '13e23f66-f92d-4582-a5fc-73397e1ccd41', 'ElectronicCertificateStatus', 'ValueListItem', 'False', 'False' , 1, 'b9240a02-c628-4c24-b6a8-ea9b2f1ff290', 'True', 'True', 'False', 'False', 1, 0, 1, 'ELECTRONICCERTIFICATES.REPORTING.ELECTRONICCERTIFICATESTATUS', '06d85592-2f5a-42d0-a3c2-cf515beb37f2', 0, 'False', 1, 0)
END
GO

-- ElectronicCertificate.ElectronicCertificateStatus

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaEntitiesAssociations] WHERE [Id] = 'aea71472-6c5e-2dca-b285-d51c8e903096')
BEGIN
    INSERT INTO [CorePatterns].[SchemaEntitiesAssociations] ([Id], [SchemaEntityId], [TargetId], [AttributeId], [IsComposition], [IsManyToMany], [IsActive], [IsDeleted], [IsSystem])
    VALUES ('aea71472-6c5e-2dca-b285-d51c8e903096', 'b9240a02-c628-4c24-b6a8-ea9b2f1ff290', '06d85592-2f5a-42d0-a3c2-cf515beb37f2', '13e23f66-f92d-4582-a5fc-73397e1ccd41', 0, 0, 1, 0, 1)
END
GO

-- Operation: 'editelectroniccertificate'
-- Insert operation

merge [CorePatterns].[Operations] as target 
using(
    select '4ca12f27-8dbd-4a43-b009-031a45070190' [Id], 'editelectroniccertificate' [Name], 'reporting' [Module], null [ProcessId], N'{"Values":[{ "Culture":"en","Data":"Electronic Certificate"}]}' [LocalizableCaption], 'b49d1d13-6573-43d6-bd10-885377848a76' [TypeId], '50F4E368-C0A0-4EA3-83DC-BDC0904D465B' [OperationTypeSpecificationId], 'b9240a02-c628-4c24-b6a8-ea9b2f1ff290' [SchemaEntityId], 'ElectronicCertificates' [ServiceName], 'True' [UseDraft],'False' [ListDraft], 'Reporting_EditElectronicCertificate' [NaturalKey], '<sys>' [CreatedBy] ,SYSDATETIMEOFFSET() [CreatedOn], '<sys>' [ModifiedBy], SYSDATETIMEOFFSET() [ModifiedOn], 1 [IsActive], 0 [IsDeleted], 1 [IsSystem], 0 [IsDraft]
    ) as source on (source.id = target.id)
when not matched then
    insert ([Id],[Name],[Module],[ProcessId],[LocalizableCaption],[TypeId], [OperationTypeSpecificationId], [SchemaEntityId],[ServiceName], [UseDraft], [ListDraft], [NaturalKey],[CreatedBy],[CreatedOn],[ModifiedBy],[ModifiedOn],[IsActive],[IsDeleted],[IsSystem],[IsDraft])
    values (source.[Id],source.[Name],source.[Module],source.[ProcessId],source.[LocalizableCaption],source.[TypeId], source.[OperationTypeSpecificationId], source.[SchemaEntityId],source.[ServiceName],source.[UseDraft],source.[ListDraft],source.[NaturalKey],source.[CreatedBy],source.[CreatedOn],source.[ModifiedBy],source.[ModifiedOn],source.[IsActive],source.[IsDeleted],source.[IsSystem],source.[IsDraft]);


-- Operation: 'electroniccertificates'
-- Insert operation

merge [CorePatterns].[Operations] as target 
using(
    select 'bf02a9fc-1457-4820-8827-c0f764638c11' [Id], 'electroniccertificates' [Name], 'reporting' [Module], null [ProcessId], N'{"Values":[{ "Culture":"en","Data":"Electronic Certificates"}]}' [LocalizableCaption], '8f9d1046-be79-4071-abb9-688f3cf59b6d' [TypeId], 'C037ABE4-DD29-4C36-A8B3-14D8988D92DB' [OperationTypeSpecificationId], 'b9240a02-c628-4c24-b6a8-ea9b2f1ff290' [SchemaEntityId], 'ElectronicCertificates' [ServiceName], 'False' [UseDraft],'False' [ListDraft], 'reporting_electroniccertificates' [NaturalKey], '<sys>' [CreatedBy] ,SYSDATETIMEOFFSET() [CreatedOn], '<sys>' [ModifiedBy], SYSDATETIMEOFFSET() [ModifiedOn], 1 [IsActive], 0 [IsDeleted], 1 [IsSystem], 0 [IsDraft]
    ) as source on (source.id = target.id)
when not matched then
    insert ([Id],[Name],[Module],[ProcessId],[LocalizableCaption],[TypeId], [OperationTypeSpecificationId], [SchemaEntityId],[ServiceName], [UseDraft], [ListDraft], [NaturalKey],[CreatedBy],[CreatedOn],[ModifiedBy],[ModifiedOn],[IsActive],[IsDeleted],[IsSystem],[IsDraft])
    values (source.[Id],source.[Name],source.[Module],source.[ProcessId],source.[LocalizableCaption],source.[TypeId], source.[OperationTypeSpecificationId], source.[SchemaEntityId],source.[ServiceName],source.[UseDraft],source.[ListDraft],source.[NaturalKey],source.[CreatedBy],source.[CreatedOn],source.[ModifiedBy],source.[ModifiedOn],source.[IsActive],source.[IsDeleted],source.[IsSystem],source.[IsDraft]);


	-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [Reporting].[Reporting.ElectronicCertificatesLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [Reporting].[Reporting.ElectronicCertificatesLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= 'b9240a02-c628-4c24-b6a8-ea9b2f1ff290')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= 'b9240a02-c628-4c24-b6a8-ea9b2f1ff290'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    'b9240a02-c628-4c24-b6a8-ea9b2f1ff290'
    ,'Reporting'
    ,'ElectronicCertificates'
    ,'ElectronicCertificatesLookup'
	,'{"Values":[{ "Culture":"en","Data":"Electronic Certificate"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"en","Data":"(Electronic Certificate)"}]}'
    ,1
    ,'b9240a02-c628-4c24-b6a8-ea9b2f1ff290'
    ,'b9240a02-c628-4c24-b6a8-ea9b2f1ff290'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO

IF NOT EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModelColumns]
            WHERE [Id]= '8e777e6f-f31d-38cc-6b00-1aa5191fbba2')
BEGIN
-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        '8e777e6f-f31d-38cc-6b00-1aa5191fbba2'
        ,'{"Values":[{ "Culture":"en","Data":"Electronic Certificate"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'b9240a02-c628-4c24-b6a8-ea9b2f1ff290'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
END
GO

-- List Query TVF: ElectronicCertificatesQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Reporting' AND 
                    specific_name = 'ElectronicCertificatesQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Reporting].[ElectronicCertificatesQuery]
GO

CREATE FUNCTION  [Reporting].[ElectronicCertificatesQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL', @companyId UNIQUEIDENTIFIER  = NULL)
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[IsActive], [T1].[NaturalKey] AS [NaturalKey]
FROM [Reporting].[ElectronicCertificatesView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI))
AND (@companyId IS NULL
OR [T1].[CompanyId] = @companyId))
GO

-- Association Lookup: ElectronicCertificate_CompaniesForCompanyQuery (ElectronicCertificates | ElectronicCertificate | ElectronicCertificate.Company)

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Reporting' AND 
                    specific_name = 'ElectronicCertificate_CompaniesForCompanyQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Reporting].[ElectronicCertificate_CompaniesForCompanyQuery]
GO

	CREATE FUNCTION  [Reporting].[ElectronicCertificate_CompaniesForCompanyQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM [CorePatterns].CompaniesQuery(@searchTerm, @user, @culture) [T1]
WHERE [T1].[IsActive] = 1)
GO

	
-- Reporting.Verify_ElectronicCertificate_CompaniesForCompanyQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'Reporting' AND 
                    [SPECIFIC_NAME] = 'Verify_ElectronicCertificate_CompaniesForCompanyQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [Reporting].[Verify_ElectronicCertificate_CompaniesForCompanyQuery]
GO

-- [Reporting].Verify_ElectronicCertificate_CompaniesForCompanyQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'Reporting' AND 
                    [DOMAIN_NAME] = 'Verify_ElectronicCertificate_CompaniesForCompanyQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [Reporting].Verify_ElectronicCertificate_CompaniesForCompanyQuery_Parameters
GO

CREATE TYPE [Reporting].Verify_ElectronicCertificate_CompaniesForCompanyQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- Reporting.Verify_ElectronicCertificate_CompaniesForCompanyQuery

CREATE FUNCTION [Reporting].[Verify_ElectronicCertificate_CompaniesForCompanyQuery] (
     @List AS [Reporting].Verify_ElectronicCertificate_CompaniesForCompanyQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Reporting].[ElectronicCertificate_CompaniesForCompanyQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- Delete query filters

DELETE FROM [QueryBuilder].[ListModelQueryFilters]
WHERE [ListModelId] IN
(
    SELECT [Id]
    FROM [QueryBuilder].[ListModels]
    WHERE [Id]='4bcb5a0e-6252-4daa-a89d-a19300664925'
)
GO

-- Delete query actions

DELETE FROM [QueryBuilder].[ListModelQueryActionDetails]
WHERE [ListModelQueryActionId] IN
(
    SELECT [Id] FROM [QueryBuilder].[ListModelQueryActions]
    WHERE [ListModelId] IN
    (
        SELECT [Id]
        FROM [QueryBuilder].[ListModels]
        WHERE [Id]='4bcb5a0e-6252-4daa-a89d-a19300664925'
    )
)
GO

DELETE FROM [QueryBuilder].[ListModelQueryActions]
WHERE [ListModelId] IN
(
    SELECT [Id]
    FROM [QueryBuilder].[ListModels]
    WHERE [Id]='4bcb5a0e-6252-4daa-a89d-a19300664925'
)
GO

-- Delete query columns

DELETE FROM [QueryBuilder].[ListModelColumns]
WHERE [ListModelId] IN
(
    SELECT [Id]
    FROM [QueryBuilder].[ListModels]
    WHERE [Id]='4bcb5a0e-6252-4daa-a89d-a19300664925'
)
GO

-- Delete list models

DELETE FROM [QueryBuilder].[ListModels] WHERE ([Id] = '4bcb5a0e-6252-4daa-a89d-a19300664925')
GO


INSERT INTO [QueryBuilder].[ListModels] ([Id], [ModuleName], [ServiceName], [Name], [Description],[User], [SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery],[Filter],[FilteredByService],[IsCustomSource],[AggregationHeaderTemplate], [AllowUserCustomization], [HasAggregations], [AllowUserGrouping],[AllowUserSorting], [IncludeDeleted])
VALUES (
    '4bcb5a0e-6252-4daa-a89d-a19300664925'
    ,'Reporting'
    ,'ElectronicCertificates'
    ,'ElectronicCertificates'
	,'{"Values":[{ "Culture":"en","Data":"Electronic Certificates"}]}'
    ,'<sys>'
    ,'{"Values":[{ "Culture":"en","Data":"(Electronic Certificate)"}]}'
    ,'True'
    , 'b9240a02-c628-4c24-b6a8-ea9b2f1ff290'
    ,'4bcb5a0e-6252-4daa-a89d-a19300664925'
    ,'<sys>'
    ,1
    ,'{
  "ModuleName": "Reporting",
  "ServiceName": "ElectronicCertificates",
  "Name": "ElectronicCertificates",
  "HideSearchComponent": false,
  "Columns": [
    {
      "Name": "NaturalKey",
      "DataType": "LongText"
    },
    {
      "Name": "Name",
      "DataType": "LongText"
    },
    {
      "Name": "ElectronicCertificateStatus",
      "DataType": "ValueListItem"
    }
  ]
}'
    ,1
    ,''
    ,''
    ,'False'
	,''
    ,'True'
    ,'False'
    ,'True'
    ,'True'
	,'False'
    )
GO

    
    -- Get the style id
    
    DECLARE @columnStyleId uniqueidentifier;
    SET @columnStyleId = (SELECT [Id] FROM [QueryBuilder].[ListModelColumnStyles] WHERE [Value] = 0);

	-- Get the standard formatting id
    
    DECLARE @standardFormattingId uniqueidentifier;
    SET @standardFormattingId = (SELECT [Id] FROM [QueryBuilder].[ListModelColumnStandardFormattings] WHERE [Value] = 0);

    -- Get the aggregation expression id
    
    DECLARE @aggregationExpressionId uniqueidentifier;
    SET @aggregationExpressionId = (SELECT [Id] FROM [QueryBuilder].[ListModelAggregationOperations] WHERE [Value] = 0);

	 DECLARE @totalExpressionId uniqueidentifier;
    SET @totalExpressionId = (SELECT [Id] FROM [QueryBuilder].[ListModelAggregationOperations] WHERE [Value] = 0);


    INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [SchemaAttributeId], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible], [Uri], [Searchable], [IsCustom], [CustomExpression], [IsLocalizable], [StyleId], [AggregationOperationId], [TotalOperationId], [DisplayAggregationInFooter], [StandardFormattingId], [StandardFormattingColumn], [GroupHeaderTemplate], [ThumbnailColumnId])
    VALUES (
        'b39eaff4-e1d6-6d3f-5cc9-b4d490e98460'
		,'{"Values":[{ "Culture":"en","Data":"Id"}]}'
        ,'False'
        ,'False'
        , 0
        ,'UniqueIdentifier'
        , NULL
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'4bcb5a0e-6252-4daa-a89d-a19300664925'
        ,'False'
        ,0
        ,1
        ,''
        ,'Id'
        ,'True'
        ,''
        ,'True'
        ,'False'
        ,''
        ,'False'
        ,@columnStyleId
        ,@aggregationExpressionId
		,@totalExpressionId
        ,'False'
		,@standardFormattingId
		,''
		,NULL
		,NULL)
    GO
    
    -- Get the style id
    
    DECLARE @columnStyleId uniqueidentifier;
    SET @columnStyleId = (SELECT [Id] FROM [QueryBuilder].[ListModelColumnStyles] WHERE [Value] = 0);

	-- Get the standard formatting id
    
    DECLARE @standardFormattingId uniqueidentifier;
    SET @standardFormattingId = (SELECT [Id] FROM [QueryBuilder].[ListModelColumnStandardFormattings] WHERE [Value] = 0);

    -- Get the aggregation expression id
    
    DECLARE @aggregationExpressionId uniqueidentifier;
    SET @aggregationExpressionId = (SELECT [Id] FROM [QueryBuilder].[ListModelAggregationOperations] WHERE [Value] = 0);

	 DECLARE @totalExpressionId uniqueidentifier;
    SET @totalExpressionId = (SELECT [Id] FROM [QueryBuilder].[ListModelAggregationOperations] WHERE [Value] = 0);


    INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [SchemaAttributeId], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible], [Uri], [Searchable], [IsCustom], [CustomExpression], [IsLocalizable], [StyleId], [AggregationOperationId], [TotalOperationId], [DisplayAggregationInFooter], [StandardFormattingId], [StandardFormattingColumn], [GroupHeaderTemplate], [ThumbnailColumnId])
    VALUES (
        '743df70f-236d-4fb1-87b6-5db28443d1f5'
		,'{"Values":[{ "Culture":"en","Data":"Electronic Certificate"}]}'
        ,'True'
        ,'True'
        , 0
        ,'LongText'
        , 'fbf533c8-7d49-4f44-9945-b6b3b1063ed0'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'4bcb5a0e-6252-4daa-a89d-a19300664925'
        ,'True'
        ,0
        ,1
        ,'Reporting.ElectronicCertificates.NaturalKey.fbf533c8-7d49-4f44-9945-b6b3b1063ed0'
        ,'NaturalKey'
        ,'True'
        ,''
        ,'True'
        ,'False'
        ,''
        ,'False'
        ,@columnStyleId
        ,@aggregationExpressionId
		,@totalExpressionId
        ,'False'
		,@standardFormattingId
		,''
		,NULL
		,NULL)
    GO
    
    -- Get the style id
    
    DECLARE @columnStyleId uniqueidentifier;
    SET @columnStyleId = (SELECT [Id] FROM [QueryBuilder].[ListModelColumnStyles] WHERE [Value] = 0);

	-- Get the standard formatting id
    
    DECLARE @standardFormattingId uniqueidentifier;
    SET @standardFormattingId = (SELECT [Id] FROM [QueryBuilder].[ListModelColumnStandardFormattings] WHERE [Value] = 0);

    -- Get the aggregation expression id
    
    DECLARE @aggregationExpressionId uniqueidentifier;
    SET @aggregationExpressionId = (SELECT [Id] FROM [QueryBuilder].[ListModelAggregationOperations] WHERE [Value] = 0);

	 DECLARE @totalExpressionId uniqueidentifier;
    SET @totalExpressionId = (SELECT [Id] FROM [QueryBuilder].[ListModelAggregationOperations] WHERE [Value] = 0);


    INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [SchemaAttributeId], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible], [Uri], [Searchable], [IsCustom], [CustomExpression], [IsLocalizable], [StyleId], [AggregationOperationId], [TotalOperationId], [DisplayAggregationInFooter], [StandardFormattingId], [StandardFormattingColumn], [GroupHeaderTemplate], [ThumbnailColumnId])
    VALUES (
        '8f116ec9-bcdf-490b-a862-e0fcd58d5fad'
		,'{"Values":[{ "Culture":"en","Data":"Company Name"}]}'
        ,'True'
        ,'True'
        , 1
        ,'LongText'
        , '6e78b953-50ec-4e5e-805a-32dd501995d2'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'4bcb5a0e-6252-4daa-a89d-a19300664925'
        ,'False'
        ,0
        ,1
        ,'Reporting.ElectronicCertificates.Company.13e1bef2-5533-4a7b-ae9a-33537df3198e|CorePatterns.Companies.Name.6e78b953-50ec-4e5e-805a-32dd501995d2'
        ,'Name'
        ,'True'
        ,'#/corepatterns/companies/editcompany?id={CompanyId}'
        ,'False'
        ,'False'
        ,''
        ,'False'
        ,@columnStyleId
        ,@aggregationExpressionId
		,@totalExpressionId
        ,'False'
		,@standardFormattingId
		,''
		,NULL
		,NULL)
    GO
    
    -- Get the style id
    
    DECLARE @columnStyleId uniqueidentifier;
    SET @columnStyleId = (SELECT [Id] FROM [QueryBuilder].[ListModelColumnStyles] WHERE [Value] = 0);

	-- Get the standard formatting id
    
    DECLARE @standardFormattingId uniqueidentifier;
    SET @standardFormattingId = (SELECT [Id] FROM [QueryBuilder].[ListModelColumnStandardFormattings] WHERE [Value] = 0);

    -- Get the aggregation expression id
    
    DECLARE @aggregationExpressionId uniqueidentifier;
    SET @aggregationExpressionId = (SELECT [Id] FROM [QueryBuilder].[ListModelAggregationOperations] WHERE [Value] = 0);

	 DECLARE @totalExpressionId uniqueidentifier;
    SET @totalExpressionId = (SELECT [Id] FROM [QueryBuilder].[ListModelAggregationOperations] WHERE [Value] = 0);


    INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [SchemaAttributeId], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible], [Uri], [Searchable], [IsCustom], [CustomExpression], [IsLocalizable], [StyleId], [AggregationOperationId], [TotalOperationId], [DisplayAggregationInFooter], [StandardFormattingId], [StandardFormattingColumn], [GroupHeaderTemplate], [ThumbnailColumnId])
    VALUES (
        '4f65168c-1385-4662-b09f-cf2cfde473c8'
		,'{"Values":[{ "Culture":"en","Data":"Electronic Certificate Status"}]}'
        ,'True'
        ,'True'
        , 2
        ,'ValueListItem'
        , '13e23f66-f92d-4582-a5fc-73397e1ccd41'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'4bcb5a0e-6252-4daa-a89d-a19300664925'
        ,'False'
        ,0
        ,1
        ,'Reporting.ElectronicCertificates.ElectronicCertificateStatus.13e23f66-f92d-4582-a5fc-73397e1ccd41|Reporting.ElectronicCertificateStatuses.Description.06d85592-2f5a-42d0-a3c2-cf515beb37f2'
        ,'ElectronicCertificateStatus'
        ,'True'
        ,''
        ,'False'
        ,'False'
        ,''
        ,'False'
        ,@columnStyleId
        ,@aggregationExpressionId
		,@totalExpressionId
        ,'False'
		,@standardFormattingId
		,''
		,NULL
		,NULL)
    GO
        INSERT INTO [QueryBuilder].[ListModelQueryActions]
                ([Id], [Operation], [ListModelId], [IsSystem])
            VALUES
                ('1a011e00-e204-3e7e-c49e-a4ea881486b3'
                ,'Update'
                ,'4bcb5a0e-6252-4daa-a89d-a19300664925'
                ,'True')
        GO

        INSERT INTO [QueryBuilder].[ListModelQueryActionDetails]
                   ([Id], [Name], [Uri], [ActionType], [ListModelQueryActionId], [ListModelId], [IsSystem])
            VALUES
                   ('086f55ec-1bf7-f7d3-e3a0-899768d0d9a2'
                   ,'ViewAction'
                   ,'#/reporting/electronicCertificates/editelectroniccertificate?id={id}'
                   ,'Default'
                   ,'1a011e00-e204-3e7e-c49e-a4ea881486b3'
                   ,'4bcb5a0e-6252-4daa-a89d-a19300664925'
                   ,'True')
 GO


--- [Reporting].[ElectronicCertificates_ElectronicCertificatesQuery] (Default Entity TVF)

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Reporting' AND 
                    specific_name = 'ElectronicCertificates_ElectronicCertificatesQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Reporting].[ElectronicCertificates_ElectronicCertificatesQuery]
GO

CREATE FUNCTION  [Reporting].[ElectronicCertificates_ElectronicCertificatesQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [SRC].[Id], [SRC].[Source_NaturalKey], [SRC].[NaturalKey], [SRC].[Name], [SRC].[CompanyId], [SRC].[ElectronicCertificateStatusId], [SRC].[ElectronicCertificateStatusValue], [SRC].[ElectronicCertificateStatus]
FROM (SELECT [T0].[Id] AS [Id], [T0].[NaturalKey] AS [Source_NaturalKey], [T0].[NaturalKey] AS [NaturalKey], [T1].[Name] AS [Name], [T1].[Id] AS [CompanyId], [T2].[Id] AS [ElectronicCertificateStatusId], [T2].[Value] AS [ElectronicCertificateStatusValue], [CorePatterns].[GetLocalizedValue]([T2].[Description], @culture) AS [ElectronicCertificateStatus]
FROM [Reporting].[ElectronicCertificatesView] [T0]
LEFT JOIN [CorePatterns].[CompaniesView] [T1] ON [T0].[CompanyId] = [T1].[Id]
LEFT JOIN [Reporting].[ElectronicCertificateStatusesView] [T2] ON [T0].[ElectronicCertificateStatusId] = [T2].[Id]
WHERE ((@searchTerm IN ('%', '%%')
OR (ISNULL([T0].[NaturalKey] COLLATE Latin1_general_CI_AI, '') LIKE @searchTerm COLLATE Latin1_general_CI_AI)))) [SRC])
GO




--------------------------------------------------------- ADD Electronic Certificates on existing Companies------------------------------------------------------

Insert into [Reporting].[ElectronicCertificates] 
([CompanyId], [NaturalKey], [ElectronicCertificateStatusId], [AuthorizerID], [Secret], [CreatedBy],[CreatedOn],[ModifiedBy],[ModifiedOn],[IsActive],[IsDeleted],[IsSystem])
	( select Id, NaturalKey, 'E4855EE8-7766-4B20-855D-3EB304DA9B79' as [ElectronicCertificateStatusId], '' as [AuthorizerID], '' as [Secret], '<Sys>' as [CreatedBy], GETDATE() as [CreatedOn], '<Sys>' as [ModifiedBy], 
		   GETDATE() as [ModifiedOn], [IsActive], [IsDeleted], [IsSystem] from [CorePatterns].[Companies] comp
			where  comp.Id  NOT IN 
						( select CompanyId from [Reporting].[ElectronicCertificates] ec)
				)
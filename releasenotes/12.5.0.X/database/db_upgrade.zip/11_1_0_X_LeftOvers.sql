
IF exists (SELECT TOP 1 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[Identity].[RoleResourcesView]') AND type = 'V')
	DROP View [Identity].[RoleResourcesView];
GO
CREATE VIEW [Identity].[RoleResourcesView] 
WITH SCHEMABINDING AS
SELECT
    E.[Id]
    , E.[RoleKey]
    , E.[Description]
    , E.[IsAdministration]
    , E.[LocalizableDescription]
    , E.[RoleDefinition]
    , E.[IsDefault]
    , E.[IsInternal]
    , E.[NaturalKey]
    , E.[IsDraft]
    , E.[CreatedBy]
    , E.[CreatedOn]
    , E.[ModifiedBy]
    , E.[ModifiedOn]
    , E.[IsActive] 
    , E.[IsDeleted]
    , E.[IsSystem]
    , E.[Version]
FROM [Identity].[Roles] E
WHERE E.[IsDeleted] = 0
GO

IF exists (SELECT TOP 1 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[Identity].[UserResourcesView]') AND type = 'V')
	DROP View [Identity].[UserResourcesView];
GO
CREATE VIEW [Identity].[UserResourcesView] 
WITH SCHEMABINDING AS
SELECT
    E.[Id]
    , E.[UserKey]
    , E.[Name]
    , E.[LastLogin]
	, T0.NaturalKey as [DefaultRole]
    , E.[DefaultRoleId]
	, T0.[Description] as [DefaultRoleDescription]
    , E.[Email]
	, T1.NaturalKey as [Culture]
    , E.[CultureId]
	, T1.[Name] as [CultureDescription]
    , E.[Picture]
    , E.[PictureThumbnail]
    , E.[NaturalKey]
    , E.[IsDraft]
    , E.[CreatedBy]
    , E.[CreatedOn]
    , E.[ModifiedBy]
    , E.[ModifiedOn]
    , E.[IsActive] 
    , E.[IsDeleted]
    , E.[IsSystem]
    , E.[Version]
FROM [Identity].[Users] E
		left join [Identity].[Roles] T0 on E.DefaultRoleId = T0.Id
		left join [CorePatterns].[Cultures] T1 on E.CultureId = T1.Id
WHERE E.[IsDeleted] = 0
GO
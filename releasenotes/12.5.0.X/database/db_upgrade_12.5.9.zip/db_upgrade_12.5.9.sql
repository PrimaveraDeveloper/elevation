/*

View ExtensibilitySchemaEntityResourceView

*/

IF OBJECT_ID( 'CorePatterns.ExtensibilitySchemaEntityResourceView', 'V' ) IS NOT NULL 
	DROP VIEW [CorePatterns].[ExtensibilitySchemaEntityResourceView]
GO

CREATE VIEW [CorePatterns].[ExtensibilitySchemaEntityResourceView]
WITH SCHEMABINDING AS
SELECT DISTINCT SE.[Id] 
      ,SE.[Key] 
      ,SE.[ModuleName] 
      ,SE.[Title] 
      ,SE.[EntityName] 
      ,ISNULL(SEA.[IsComposition], 0) AS IsComposition
	  ,CASE 
		WHEN SEP.[InterfaceType] IS NULL THEN ISNULL(SEA.[IsComposition], CAST(0 AS BIT))
		ELSE CAST(1 AS BIT) 
	   END
	   AS IsCompanyDependent
FROM [CorePatterns].[SchemaEntities] SE
LEFT JOIN  [CorePatterns].[SchemaEntitiesAssociations] SEA ON SE.Id = SEA.TargetId
LEFT JOIN [CorePatterns].[SchemaEntityPatterns] SEP ON SE.Id = SEP.SchemaEntityId AND SEP.InterfaceType = 'ICompanyDependent'
WHERE SE.AllowExtensibility = 1 

GO

/*

View ExtensibilitySchemaAttributeResourceView

*/

IF OBJECT_ID( 'CorePatterns.ExtensibilitySchemaAttributeResourceView', 'V' ) IS NOT NULL 
	DROP VIEW [CorePatterns].[ExtensibilitySchemaAttributeResourceView]
GO

CREATE VIEW [CorePatterns].[ExtensibilitySchemaAttributeResourceView]
WITH SCHEMABINDING AS
SELECT SA.[Id]
	  ,SA.[SchemaEntityId]
	  ,JSON_VALUE(SA.[CustomAttributeDefinition], '$.name') AS [Name]
	  ,JSON_VALUE(SA.[CustomAttributeDefinition], '$.label') AS [Label]
	  ,CONVERT(Bit, JSON_VALUE(SA.[CustomAttributeDefinition], '$.isRequired'))  AS [IsRequired]
	  ,CONVERT(Bit,JSON_VALUE(SA.[CustomAttributeDefinition], '$.isVisible'))  AS [IsVisible]
	  ,JSON_VALUE(SA.[CustomAttributeDefinition], '$.attributeType') AS [AttributeType]
	  ,SA.ModifiedOn
	  ,CONVERT(Bit,JSON_VALUE(SA.[CustomAttributeDefinition], '$.isActive'))  AS [IsActive]
	  ,JSON_VALUE(SA.[CustomAttributeDefinition], '$.DefaultValue') AS DefaultValue
	  ,JSON_VALUE(SA.[CustomAttributeDefinition], '$.AttributeTypeOptions') AS AttributeTypeOptions
	  ,JSON_VALUE(SA.[CustomAttributeDefinition], '$.ValidationRules') AS ValidationRules
	  ,CASE
		WHEN JSON_VALUE(SA.[CustomAttributeDefinition], '$.isReadOnly') = 'false' THEN CAST(0 AS BIT) 
	    ELSE  CAST(1 AS BIT) 
	   END
	   AS IsReadOnly

FROM [CorePatterns].[SchemaAttributes] SA 
WHERE SA.IsCustomAttribute = 1


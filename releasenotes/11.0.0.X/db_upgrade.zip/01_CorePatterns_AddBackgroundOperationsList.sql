DROP VIEW IF EXISTS [CorePatterns].[BackgroundOperationDetailStatusesView]
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperationDetailStatuses]') AND type in (N'U'))
BEGIN
CREATE TABLE [CorePatterns].[BackgroundOperationDetailStatuses]
(
    [Id] uniqueidentifier NOT NULL
    , [Name] nvarchar(100) NOT NULL
	, [Value] int NOT NULL
	, [Description] nvarchar(MAX) NOT NULL
    , CONSTRAINT [BackgroundOperationDetailStatuses_PK] PRIMARY KEY NONCLUSTERED ([Id])
    , CONSTRAINT [BackgroundOperationDetailStatuses_Name_UK] UNIQUE NONCLUSTERED ([Name])
    , CONSTRAINT [BackgroundOperationDetailStatuses_Value_UK] UNIQUE NONCLUSTERED ([Value])
) ON [PRIMARY]

-- Value List: BackgroundOperationDetailStatuses
INSERT INTO [CorePatterns].[BackgroundOperationDetailStatuses] ([Id], [Name], [Value], [Description]) VALUES ('00000000-0000-0000-0000-000000000000', 'None', 0, '{"Values":[{ "Culture":"en","Data":"None"}]}')
INSERT INTO [CorePatterns].[BackgroundOperationDetailStatuses] ([Id], [Name], [Value], [Description]) VALUES ('252c9e10-d7ef-4745-bb9b-9238fcfca6a8', 'InProgress', 2, '{"Values":[{ "Culture":"en","Data":"In Progress"}]}')
INSERT INTO [CorePatterns].[BackgroundOperationDetailStatuses] ([Id], [Name], [Value], [Description]) VALUES ('a2372ed4-48fc-4b43-b55f-7d2134258d52', 'Succeded', 3, '{"Values":[{ "Culture":"en","Data":"Succeded"}]}')
INSERT INTO [CorePatterns].[BackgroundOperationDetailStatuses] ([Id], [Name], [Value], [Description]) VALUES ('275e6586-1057-464d-ab37-3582de2211e6', 'Failed', 4, '{"Values":[{ "Culture":"en","Data":"Failed"}]}')

END
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperationDetailStatuses]') AND name = N'BackgroundOperationDetailStatuses_IDX1')
BEGIN
CREATE CLUSTERED INDEX [BackgroundOperationDetailStatuses_IDX1] ON [CorePatterns].[BackgroundOperationDetailStatuses] ([Value])
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperationDetailStatuses_Id_DF]') AND type = 'D')
BEGIN
ALTER TABLE [CorePatterns].[BackgroundOperationDetailStatuses] ADD CONSTRAINT [BackgroundOperationDetailStatuses_Id_DF] DEFAULT (newsequentialid()) FOR [Id]
END
GO

CREATE VIEW [CorePatterns].[BackgroundOperationDetailStatusesView]
WITH SCHEMABINDING AS
SELECT
    E.[Id]
    , E.[Name]
	, E.[Value]
	, E.[Description]
FROM [CorePatterns].[BackgroundOperationDetailStatuses] E
GO

DROP VIEW IF EXISTS [CorePatterns].[BackgroundOperationStatusesView]
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperationStatuses]') AND type in (N'U'))
BEGIN
CREATE TABLE [CorePatterns].[BackgroundOperationStatuses]
(
    [Id] uniqueidentifier NOT NULL
    , [Name] nvarchar(100) NOT NULL
	, [Value] int NOT NULL
	, [Description] nvarchar(MAX) NOT NULL
    , CONSTRAINT [BackgroundOperationStatuses_PK] PRIMARY KEY NONCLUSTERED ([Id])
    , CONSTRAINT [BackgroundOperationStatuses_Name_UK] UNIQUE NONCLUSTERED ([Name])
    , CONSTRAINT [BackgroundOperationStatuses_Value_UK] UNIQUE NONCLUSTERED ([Value])
) ON [PRIMARY]

-- Value List: BackgroundOperationStatuses
INSERT INTO [CorePatterns].[BackgroundOperationStatuses] ([Id], [Name], [Value], [Description]) VALUES ('00000000-0000-0000-0000-000000000000', 'None', 0, '{"Values":[{ "Culture":"en","Data":"None"}]}')
INSERT INTO [CorePatterns].[BackgroundOperationStatuses] ([Id], [Name], [Value], [Description]) VALUES ('009f0b0f-6958-469f-abf8-d5d2a6b6cf0d', 'InProgress', 2, '{"Values":[{ "Culture":"en","Data":"In Progress"}]}')
INSERT INTO [CorePatterns].[BackgroundOperationStatuses] ([Id], [Name], [Value], [Description]) VALUES ('b1a11ff1-d528-4fe5-bb39-f1f32a5fbf6f', 'Completed', 3, '{"Values":[{ "Culture":"en","Data":"Completed"}]}')
INSERT INTO [CorePatterns].[BackgroundOperationStatuses] ([Id], [Name], [Value], [Description]) VALUES ('56920043-0c8a-49d9-9325-6babe8e0c46c', 'CompletedWithErrors', 4, '{"Values":[{ "Culture":"en","Data":"Completed With Errors"}]}')

END
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperationStatuses]') AND name = N'BackgroundOperationStatuses_IDX1')
BEGIN
CREATE CLUSTERED INDEX [BackgroundOperationStatuses_IDX1] ON [CorePatterns].[BackgroundOperationStatuses] ([Value])
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperationStatuses_Id_DF]') AND type = 'D')
BEGIN
ALTER TABLE [CorePatterns].[BackgroundOperationStatuses] ADD CONSTRAINT [BackgroundOperationStatuses_Id_DF] DEFAULT (newsequentialid()) FOR [Id]
END
GO

CREATE VIEW [CorePatterns].[BackgroundOperationStatusesView]
WITH SCHEMABINDING AS
SELECT
    E.[Id]
    , E.[Name]
	, E.[Value]
	, E.[Description]
FROM [CorePatterns].[BackgroundOperationStatuses] E
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperations]') AND type in (N'U'))
BEGIN
CREATE TABLE [CorePatterns].[BackgroundOperations]
(
    [Id] uniqueidentifier NOT NULL
    , [BackgroundOperationKey] nvarchar(100) NOT NULL
	, [EventType] nvarchar(100) NULL
	, [OperationId] uniqueidentifier NOT NULL
	, [SchemaEntityId] uniqueidentifier NOT NULL
	, [EntityUri] nvarchar(255) NULL
	, [EntityKey] nvarchar(100) NULL
	, [UserName] nvarchar(100) NULL
	, [BackgroundOperationStatusId] uniqueidentifier NULL
	, [NaturalKey] nvarchar(255) NOT NULL
	, [IsDraft] bit NOT NULL
	, [CreatedBy] nvarchar(255) NOT NULL
	, [CreatedOn] datetimeoffset(7) NOT NULL
	, [ModifiedBy] nvarchar(255) NOT NULL
	, [ModifiedOn] datetimeoffset(7) NOT NULL
	, [IsActive] bit NOT NULL
	, [IsDeleted] bit NOT NULL
	, [IsSystem] bit NOT NULL
	, [Version] timestamp NOT NULL
    , CONSTRAINT [BackgroundOperations_PK] PRIMARY KEY NONCLUSTERED ([Id])
    , CONSTRAINT [BackgroundOperations_UK] UNIQUE NONCLUSTERED ([BackgroundOperationKey])
    , CONSTRAINT [BackgroundOperations_UK2] UNIQUE NONCLUSTERED ([NaturalKey])
) ON [PRIMARY]
END
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperations]') AND name = N'BackgroundOperations_IDX0')
BEGIN
CREATE CLUSTERED INDEX [BackgroundOperations_IDX0] ON [CorePatterns].[BackgroundOperations] ([CreatedOn])
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperations_Id_DF]') AND type = 'D')
BEGIN
ALTER TABLE [CorePatterns].[BackgroundOperations] ADD CONSTRAINT [BackgroundOperations_Id_DF] DEFAULT (NEWSEQUENTIALID()) FOR [Id]
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperations_IsDraft_DF]') AND type = 'D')
BEGIN
ALTER TABLE [CorePatterns].[BackgroundOperations] ADD CONSTRAINT [BackgroundOperations_IsDraft_DF] DEFAULT (0) FOR [IsDraft]
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperations_CreatedBy_DF]') AND type = 'D')
BEGIN
ALTER TABLE [CorePatterns].[BackgroundOperations] ADD CONSTRAINT [BackgroundOperations_CreatedBy_DF] DEFAULT ('<Sys>') FOR [CreatedBy]
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperations_CreatedOn_DF]') AND type = 'D')
BEGIN
ALTER TABLE [CorePatterns].[BackgroundOperations] ADD CONSTRAINT [BackgroundOperations_CreatedOn_DF] DEFAULT (SYSDATETIMEOFFSET()) FOR [CreatedOn]
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperations_ModifiedBy_DF]') AND type = 'D')
BEGIN
ALTER TABLE [CorePatterns].[BackgroundOperations] ADD CONSTRAINT [BackgroundOperations_ModifiedBy_DF] DEFAULT ('<Sys>') FOR [ModifiedBy]
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperations_ModifiedOn_DF]') AND type = 'D')
BEGIN
ALTER TABLE [CorePatterns].[BackgroundOperations] ADD CONSTRAINT [BackgroundOperations_ModifiedOn_DF] DEFAULT (SYSDATETIMEOFFSET()) FOR [ModifiedOn]
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperations_IsActive_DF]') AND type = 'D')
BEGIN
ALTER TABLE [CorePatterns].[BackgroundOperations] ADD CONSTRAINT [BackgroundOperations_IsActive_DF] DEFAULT (1) FOR [IsActive]
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperations_IsDeleted_DF]') AND type = 'D')
BEGIN
ALTER TABLE [CorePatterns].[BackgroundOperations] ADD CONSTRAINT [BackgroundOperations_IsDeleted_DF] DEFAULT (0) FOR [IsDeleted]
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperations_IsSystem_DF]') AND type = 'D')
BEGIN
ALTER TABLE [CorePatterns].[BackgroundOperations] ADD CONSTRAINT [BackgroundOperations_IsSystem_DF] DEFAULT (0) FOR [IsSystem]
END
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperations_Operations_OperationId_FK]') AND parent_object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperations]'))
BEGIN
ALTER TABLE [CorePatterns].[BackgroundOperations] ADD CONSTRAINT [BackgroundOperations_Operations_OperationId_FK]
FOREIGN KEY ([OperationId]) REFERENCES [CorePatterns].[Operations] ([Id])
END
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperations_SchemaEntities_SchemaEntityId_FK]') AND parent_object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperations]'))
BEGIN
ALTER TABLE [CorePatterns].[BackgroundOperations] ADD CONSTRAINT [BackgroundOperations_SchemaEntities_SchemaEntityId_FK]
FOREIGN KEY ([SchemaEntityId]) REFERENCES [CorePatterns].[SchemaEntities] ([Id])
END
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperations_BackgroundOperationStatuses_BackgroundOperationStatusId_FK]') AND parent_object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperations]'))
BEGIN
ALTER TABLE [CorePatterns].[BackgroundOperations] ADD CONSTRAINT [BackgroundOperations_BackgroundOperationStatuses_BackgroundOperationStatusId_FK]
FOREIGN KEY ([BackgroundOperationStatusId]) REFERENCES [CorePatterns].[BackgroundOperationStatuses] ([Id])
END
GO

DROP VIEW IF EXISTS [CorePatterns].[BackgroundOperationsView]
GO

CREATE VIEW [CorePatterns].[BackgroundOperationsView]
WITH SCHEMABINDING AS
SELECT
    E.[Id]
    , E.[BackgroundOperationKey]
	, E.[EventType]
	, E.[OperationId]
	, E.[SchemaEntityId]
	, E.[EntityUri]
	, E.[EntityKey]
	, E.[UserName]
	, E.[BackgroundOperationStatusId]
	, E.[NaturalKey]
	, E.[IsDraft]
	, E.[CreatedBy]
	, E.[CreatedOn]
	, E.[ModifiedBy]
	, E.[ModifiedOn]
	, E.[IsActive]
	, E.[IsDeleted]
	, E.[IsSystem]
	, E.[Version]
FROM [CorePatterns].[BackgroundOperations] E
WHERE E.[IsDeleted] = 0
GO

DROP VIEW IF EXISTS [CorePatterns].[BackgroundOperationResourcesView]
GO

CREATE VIEW [CorePatterns].[BackgroundOperationResourcesView] 
WITH SCHEMABINDING AS
SELECT
    E.[Id]
    , E.[BackgroundOperationKey]
    , E.[EventType]
	, T0.NaturalKey as [Operation]
    , E.[OperationId]
	, T1.NaturalKey as [SchemaEntity]
    , E.[SchemaEntityId]
    , E.[EntityUri]
    , E.[EntityKey]
    , E.[UserName]
	, T2.Value as [BackgroundOperationStatus]
    , E.[BackgroundOperationStatusId]
	, T2.Description as [BackgroundOperationStatusDescription]
    , E.[NaturalKey]
    , E.[IsDraft]
    , E.[CreatedBy]
    , E.[CreatedOn]
    , E.[ModifiedBy]
    , E.[ModifiedOn]
    , E.[IsActive] 
    , E.[IsDeleted]
    , E.[IsSystem]
    , E.[Version]
FROM [CorePatterns].[BackgroundOperations] E
		left join [CorePatterns].[Operations] T0 on E.OperationId = T0.Id
		left join [CorePatterns].[SchemaEntities] T1 on E.SchemaEntityId = T1.Id
		left join [CorePatterns].[BackgroundOperationStatuses] T2 on E.BackgroundOperationStatusId = T2.Id
WHERE E.[IsDeleted] = 0

GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperationDetails]') AND type in (N'U'))
BEGIN
CREATE TABLE [CorePatterns].[BackgroundOperationDetails]
(
    [Id] uniqueidentifier NOT NULL
    , [Description] nvarchar(255) NULL
	, [BackgroundOperationDetailStatusId] uniqueidentifier NULL
	, [BackgroundOperationId] uniqueidentifier NOT NULL
	, [Index] int NOT NULL
	, [CreatedBy] nvarchar(255) NOT NULL
	, [CreatedOn] datetimeoffset(7) NOT NULL
	, [ModifiedBy] nvarchar(255) NOT NULL
	, [ModifiedOn] datetimeoffset(7) NOT NULL
	, [IsActive] bit NOT NULL
	, [IsDeleted] bit NOT NULL
	, [IsSystem] bit NOT NULL
	, [Version] timestamp NOT NULL
    , CONSTRAINT [BackgroundOperationDetails_PK] PRIMARY KEY NONCLUSTERED ([Id])
) ON [PRIMARY]
END
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperationDetails]') AND name = N'BackgroundOperationDetails_IDX1')
BEGIN
CREATE CLUSTERED INDEX [BackgroundOperationDetails_IDX1] ON [CorePatterns].[BackgroundOperationDetails] ([BackgroundOperationId], [Index])
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperationDetails_Id_DF]') AND type = 'D')
BEGIN
ALTER TABLE [CorePatterns].[BackgroundOperationDetails] ADD CONSTRAINT [BackgroundOperationDetails_Id_DF] DEFAULT (NEWSEQUENTIALID()) FOR [Id]
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperationDetails_Index_DF]') AND type = 'D')
BEGIN
ALTER TABLE [CorePatterns].[BackgroundOperationDetails] ADD CONSTRAINT [BackgroundOperationDetails_Index_DF] DEFAULT (0) FOR [Index]
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperationDetails_CreatedBy_DF]') AND type = 'D')
BEGIN
ALTER TABLE [CorePatterns].[BackgroundOperationDetails] ADD CONSTRAINT [BackgroundOperationDetails_CreatedBy_DF] DEFAULT ('<Sys>') FOR [CreatedBy]
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperationDetails_CreatedOn_DF]') AND type = 'D')
BEGIN
ALTER TABLE [CorePatterns].[BackgroundOperationDetails] ADD CONSTRAINT [BackgroundOperationDetails_CreatedOn_DF] DEFAULT (SYSDATETIMEOFFSET()) FOR [CreatedOn]
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperationDetails_ModifiedBy_DF]') AND type = 'D')
BEGIN
ALTER TABLE [CorePatterns].[BackgroundOperationDetails] ADD CONSTRAINT [BackgroundOperationDetails_ModifiedBy_DF] DEFAULT ('<Sys>') FOR [ModifiedBy]
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperationDetails_ModifiedOn_DF]') AND type = 'D')
BEGIN
ALTER TABLE [CorePatterns].[BackgroundOperationDetails] ADD CONSTRAINT [BackgroundOperationDetails_ModifiedOn_DF] DEFAULT (SYSDATETIMEOFFSET()) FOR [ModifiedOn]
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperationDetails_IsActive_DF]') AND type = 'D')
BEGIN
ALTER TABLE [CorePatterns].[BackgroundOperationDetails] ADD CONSTRAINT [BackgroundOperationDetails_IsActive_DF] DEFAULT (1) FOR [IsActive]
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperationDetails_IsDeleted_DF]') AND type = 'D')
BEGIN
ALTER TABLE [CorePatterns].[BackgroundOperationDetails] ADD CONSTRAINT [BackgroundOperationDetails_IsDeleted_DF] DEFAULT (0) FOR [IsDeleted]
END
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperationDetails_IsSystem_DF]') AND type = 'D')
BEGIN
ALTER TABLE [CorePatterns].[BackgroundOperationDetails] ADD CONSTRAINT [BackgroundOperationDetails_IsSystem_DF] DEFAULT (0) FOR [IsSystem]
END
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperationDetails_BackgroundOperations_BackgroundOperationId_FK]') AND parent_object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperationDetails]'))
BEGIN
ALTER TABLE [CorePatterns].[BackgroundOperationDetails] ADD CONSTRAINT [BackgroundOperationDetails_BackgroundOperations_BackgroundOperationId_FK]
FOREIGN KEY ([BackgroundOperationId]) REFERENCES [CorePatterns].[BackgroundOperations] ([Id])
ON DELETE CASCADE
END
GO

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperationDetails_BackgroundOperationDetailStatuses_BackgroundOperationDetailStatusId_FK]') AND parent_object_id = OBJECT_ID(N'[CorePatterns].[BackgroundOperationDetails]'))
BEGIN
ALTER TABLE [CorePatterns].[BackgroundOperationDetails] ADD CONSTRAINT [BackgroundOperationDetails_BackgroundOperationDetailStatuses_BackgroundOperationDetailStatusId_FK]
FOREIGN KEY ([BackgroundOperationDetailStatusId]) REFERENCES [CorePatterns].[BackgroundOperationDetailStatuses] ([Id])
END
GO

DROP VIEW IF EXISTS [CorePatterns].[BackgroundOperationDetailsView]
GO

CREATE VIEW [CorePatterns].[BackgroundOperationDetailsView]
WITH SCHEMABINDING AS
SELECT
    E.[Id]
    , E.[Description]
	, E.[BackgroundOperationDetailStatusId]
	, E.[BackgroundOperationId]
	, E.[Index]
	, E.[CreatedBy]
	, E.[CreatedOn]
	, E.[ModifiedBy]
	, E.[ModifiedOn]
	, E.[IsActive]
	, E.[IsDeleted]
	, E.[IsSystem]
	, E.[Version]
FROM [CorePatterns].[BackgroundOperationDetails] E
WHERE E.[IsDeleted] = 0
GO

DROP VIEW IF EXISTS [CorePatterns].[BackgroundOperationDetailResourcesView]
GO

CREATE VIEW [CorePatterns].[BackgroundOperationDetailResourcesView] 
WITH SCHEMABINDING AS
SELECT
    E.[Id]
    , E.[Description]
	, T0.Value as [BackgroundOperationDetailStatus]
    , E.[BackgroundOperationDetailStatusId]
	, T0.Description as [BackgroundOperationDetailStatusDescription]
    , E.[BackgroundOperationId]
	, E.[Index]
    , E.[CreatedBy]
    , E.[CreatedOn]
    , E.[ModifiedBy]
    , E.[ModifiedOn]
    , E.[IsActive] 
    , E.[IsDeleted]
    , E.[IsSystem]
    , E.[Version]
FROM [CorePatterns].[BackgroundOperationDetails] E
		left join [CorePatterns].[BackgroundOperationDetailStatuses] T0 on E.BackgroundOperationDetailStatusId = T0.Id
WHERE E.[IsDeleted] = 0

GO

-- BackgroundOperationDetailStatus

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaEntities] WHERE Id = '8b8ad3ea-7ab1-414f-acba-4345b2dea3ce')
BEGIN
    INSERT INTO [CorePatterns].[SchemaEntities] ([Id], [Key], [ModuleName], [Title], [EntityTypeId], [EntityName], [Database], [BaseEntityId], [IsGenericExtension], [LockingEnabled], [HasSequenceAttribute], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [IsRestrictable]) 
    VALUES ('8b8ad3ea-7ab1-414f-acba-4345b2dea3ce', 'BackgroundOperationDetailStatuses', 'CorePatterns', N'{"Values":[{ "Culture":"en","Data":"Background Operation Detail Status"}]}', (SELECT Id from [CorePatterns].[SchemaEntityTypes] WHERE Name = 'ValueList'), 'Primavera.Core.Patterns.Domain.BackgroundOperationDetailStatus', 'Enterprise', NULL, 0, 0, 0, 1, 0, 1, 'BACKGROUNDOPERATIONDETAILSTATUSES.COREPATTERNS', 0)
END
GO

-- BackgroundOperationStatus

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaEntities] WHERE Id = 'aafbe4a9-58c9-4ec3-afef-d764d23ec7e3')
BEGIN
    INSERT INTO [CorePatterns].[SchemaEntities] ([Id], [Key], [ModuleName], [Title], [EntityTypeId], [EntityName], [Database], [BaseEntityId], [IsGenericExtension], [LockingEnabled], [HasSequenceAttribute], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [IsRestrictable]) 
    VALUES ('aafbe4a9-58c9-4ec3-afef-d764d23ec7e3', 'BackgroundOperationStatuses', 'CorePatterns', N'{"Values":[{ "Culture":"en","Data":"Background Operation Status"}]}', (SELECT Id from [CorePatterns].[SchemaEntityTypes] WHERE Name = 'ValueList'), 'Primavera.Core.Patterns.Domain.BackgroundOperationStatus', 'Enterprise', NULL, 0, 0, 0, 1, 0, 1, 'BACKGROUNDOPERATIONSTATUSES.COREPATTERNS', 0)
END
GO

-- BackgroundOperation

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaEntities] WHERE Id = 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b')
BEGIN
    INSERT INTO [CorePatterns].[SchemaEntities] ([Id], [Key], [ModuleName], [Title], [EntityTypeId], [EntityName], [Database], [BaseEntityId], [IsGenericExtension], [LockingEnabled], [HasSequenceAttribute], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [IsRestrictable]) 
    VALUES ('b520dce1-406e-4cfc-a0a2-ef65c3b48d9b', 'BackgroundOperations', 'CorePatterns', '{"Values":[{ "Culture":"en","Data":"BackgroundOperation"}]}', (SELECT Id from [CorePatterns].[SchemaEntityTypes] WHERE Id = 'd4ed5adc-1618-4e79-9263-e02e3dd6fc79'), 'Primavera.Core.Patterns.Domain.BackgroundOperation', 'Enterprise', NULL, 0, 0, 0, 1, 0, 1, 'BACKGROUNDOPERATIONS.COREPATTERNS', 0 )
END
GO

-- SchemaEntityPatterns for : BackgroundOperation

-- BackgroundOperationDetail

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaEntities] WHERE Id = 'f0716c84-83ec-4db8-a737-9966b088dd0f')
BEGIN
    INSERT INTO [CorePatterns].[SchemaEntities] ([Id], [Key], [ModuleName], [Title], [EntityTypeId], [EntityName], [Database], [BaseEntityId], [IsGenericExtension], [LockingEnabled], [HasSequenceAttribute], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [IsRestrictable]) 
    VALUES ('f0716c84-83ec-4db8-a737-9966b088dd0f', 'BackgroundOperationDetails', 'CorePatterns', '{"Values":[{ "Culture":"en","Data":"Background Operation Detail"}]}', (SELECT Id from [CorePatterns].[SchemaEntityTypes] WHERE Id = 'd4ed5adc-1618-4e79-9263-e02e3dd6fc79'), 'Primavera.Core.Patterns.Domain.BackgroundOperationDetail', 'Enterprise', NULL, 0, 0, 0, 1, 0, 1, 'BACKGROUNDOPERATIONDETAILS.COREPATTERNS', 0 )
END
GO

-- SchemaEntityPatterns for : BackgroundOperationDetail

-- BackgroundOperation.Id

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '0300ae6b-446c-4670-a669-202391242d27')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Id"}]}', '0300ae6b-446c-4670-a669-202391242d27', 'Id', 'UniqueIdentifier', 'False', 'False' , 1, 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b', 'True', 'True', 'False', 'True', 1, 0, 1, 'BACKGROUNDOPERATIONS.COREPATTERNS.ID', NULL, 0, 'False', 0, 0)
END
GO

-- BackgroundOperation.NaturalKey

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '02c55bfb-190c-4679-a6e6-0f8460de6d56')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"BackgroundOperation"}]}', '02c55bfb-190c-4679-a6e6-0f8460de6d56', 'NaturalKey', 'LongText', 'False', 'False' , 1, 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b', 'True', 'True', 'False', 'True', 1, 0, 1, 'BACKGROUNDOPERATIONS.COREPATTERNS.NATURALKEY', NULL, 0, 'False', 0, 0)
END
GO

-- BackgroundOperation.IsDraft

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'c98ca5fc-e1a9-4f31-b6d6-2fae3c672718')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Draft"}]}', 'c98ca5fc-e1a9-4f31-b6d6-2fae3c672718', 'IsDraft', 'Boolean', 'False', 'False' , 1, 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b', 'True', 'True', 'False', 'True', 1, 0, 1, 'BACKGROUNDOPERATIONS.COREPATTERNS.ISDRAFT', NULL, 0, 'False', 0, 0)
END
GO

-- BackgroundOperation.CreatedBy

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '2b373c4f-62ad-49ef-b045-d947fcfeb317')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Created By"}]}', '2b373c4f-62ad-49ef-b045-d947fcfeb317', 'CreatedBy', 'LongText', 'False', 'False' , 1, 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b', 'True', 'True', 'False', 'True', 1, 0, 1, 'BACKGROUNDOPERATIONS.COREPATTERNS.CREATEDBY', NULL, 0, 'False', 0, 0)
END
GO

-- BackgroundOperation.CreatedOn

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '53586d3b-dbed-4c8a-9cfb-03fdf406c902')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Created On"}]}', '53586d3b-dbed-4c8a-9cfb-03fdf406c902', 'CreatedOn', 'Datetime', 'False', 'False' , 1, 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b', 'True', 'True', 'False', 'True', 1, 0, 1, 'BACKGROUNDOPERATIONS.COREPATTERNS.CREATEDON', NULL, 0, 'False', 0, 0)
END
GO

-- BackgroundOperation.ModifiedBy

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '94b3b3c1-b337-42f0-974f-eb42fe429122')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Modified By"}]}', '94b3b3c1-b337-42f0-974f-eb42fe429122', 'ModifiedBy', 'LongText', 'False', 'False' , 1, 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b', 'True', 'True', 'False', 'True', 1, 0, 1, 'BACKGROUNDOPERATIONS.COREPATTERNS.MODIFIEDBY', NULL, 0, 'False', 0, 0)
END
GO

-- BackgroundOperation.ModifiedOn

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'b9133c3e-1b09-4fe7-acbd-f9eadf4e1fad')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Modified On"}]}', 'b9133c3e-1b09-4fe7-acbd-f9eadf4e1fad', 'ModifiedOn', 'Datetime', 'False', 'False' , 1, 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b', 'True', 'True', 'False', 'True', 1, 0, 1, 'BACKGROUNDOPERATIONS.COREPATTERNS.MODIFIEDON', NULL, 0, 'False', 0, 0)
END
GO

-- BackgroundOperation.IsActive

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'a6fa27f1-3a97-4264-8f23-3e030e2c8e25')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Active"}]}', 'a6fa27f1-3a97-4264-8f23-3e030e2c8e25', 'IsActive', 'Boolean', 'False', 'False' , 1, 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b', 'True', 'True', 'False', 'True', 1, 0, 1, 'BACKGROUNDOPERATIONS.COREPATTERNS.ISACTIVE', NULL, 0, 'False', 0, 0)
END
GO

-- BackgroundOperation.IsDeleted

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '1d6084df-fbd8-41b3-8b58-c840c00981d5')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Deleted"}]}', '1d6084df-fbd8-41b3-8b58-c840c00981d5', 'IsDeleted', 'Boolean', 'False', 'False' , 1, 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b', 'True', 'True', 'True', 'True', 1, 0, 1, 'BACKGROUNDOPERATIONS.COREPATTERNS.ISDELETED', NULL, 0, 'False', 0, 0)
END
GO

-- BackgroundOperation.IsSystem

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'e105700f-7274-40c2-bb34-40269cebe8da')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"System"}]}', 'e105700f-7274-40c2-bb34-40269cebe8da', 'IsSystem', 'Boolean', 'False', 'False' , 1, 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b', 'True', 'True', 'False', 'True', 1, 0, 1, 'BACKGROUNDOPERATIONS.COREPATTERNS.ISSYSTEM', NULL, 0, 'False', 0, 0)
END
GO

-- BackgroundOperation.BackgroundOperationKey

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '98097f1c-adcc-42f2-91a6-1164dd2ca11a')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Background Operation"}]}', '98097f1c-adcc-42f2-91a6-1164dd2ca11a', 'BackgroundOperationKey', 'Text', 'True', 'False' , 1, 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b', 'True', 'True', 'False', 'False', 1, 0, 1, 'BACKGROUNDOPERATIONS.COREPATTERNS.BACKGROUNDOPERATIONKEY', NULL, 0, 'False', 1, 0)
END
GO

-- BackgroundOperation.EventType

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '77000443-6717-4556-b478-30443639db96')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Event Type"}]}', '77000443-6717-4556-b478-30443639db96', 'EventType', 'Text', 'False', 'False' , 1, 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b', 'False', 'True', 'False', 'False', 1, 0, 1, 'BACKGROUNDOPERATIONS.COREPATTERNS.EVENTTYPE', NULL, 0, 'False', 1, 0)
END
GO

-- BackgroundOperation.Operation

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '08fdbd45-8e5d-4f86-85b7-ce4e126de3dc')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Operation"}]}', '08fdbd45-8e5d-4f86-85b7-ce4e126de3dc', 'Operation', 'View', 'False', 'False' , 1, 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b', 'True', 'True', 'False', 'False', 1, 0, 1, 'BACKGROUNDOPERATIONS.COREPATTERNS.OPERATION', 'c65e050a-0746-4154-927a-9d28e1620537', 0, 'False', 1, 0)
END
GO

-- BackgroundOperation.Operation

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaEntitiesAssociations] WHERE [Id] = '44207685-4299-fa61-aa2b-2df0f1acd090')
BEGIN
    INSERT INTO [CorePatterns].[SchemaEntitiesAssociations] ([Id], [SchemaEntityId], [TargetId], [AttributeId], [IsComposition], [IsManyToMany], [IsActive], [IsDeleted], [IsSystem])
    VALUES ('44207685-4299-fa61-aa2b-2df0f1acd090', 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b', 'c65e050a-0746-4154-927a-9d28e1620537', '08fdbd45-8e5d-4f86-85b7-ce4e126de3dc', 0, 0, 1, 0, 1)
END
GO

-- BackgroundOperation.SchemaEntity

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '135e5ab0-c5fc-483c-95ea-e2306748d2a6')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Schema Entity"}]}', '135e5ab0-c5fc-483c-95ea-e2306748d2a6', 'SchemaEntity', 'View', 'False', 'False' , 1, 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b', 'True', 'True', 'False', 'False', 1, 0, 1, 'BACKGROUNDOPERATIONS.COREPATTERNS.SCHEMAENTITY', 'f5ce031f-fa96-4c2c-8d44-d71f621e9232', 0, 'False', 1, 0)
END
GO

-- BackgroundOperation.SchemaEntity

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaEntitiesAssociations] WHERE [Id] = '2062eb04-aeef-c5a2-bb36-d1d7ba532ee0')
BEGIN
    INSERT INTO [CorePatterns].[SchemaEntitiesAssociations] ([Id], [SchemaEntityId], [TargetId], [AttributeId], [IsComposition], [IsManyToMany], [IsActive], [IsDeleted], [IsSystem])
    VALUES ('2062eb04-aeef-c5a2-bb36-d1d7ba532ee0', 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b', 'f5ce031f-fa96-4c2c-8d44-d71f621e9232', '135e5ab0-c5fc-483c-95ea-e2306748d2a6', 0, 0, 1, 0, 1)
END
GO

-- BackgroundOperation.EntityUri

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'd444b9ef-11e1-4d2a-8ffa-36ab8eed5084')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Entity Uri"}]}', 'd444b9ef-11e1-4d2a-8ffa-36ab8eed5084', 'EntityUri', 'LongText', 'False', 'False' , 1, 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b', 'False', 'True', 'False', 'False', 1, 0, 1, 'BACKGROUNDOPERATIONS.COREPATTERNS.ENTITYURI', NULL, 0, 'False', 1, 0)
END
GO

-- BackgroundOperation.BackgroundOperationDetails

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '0a9bce80-f691-4857-84b7-919cd46d09e4')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Background Operation Details"}]}', '0a9bce80-f691-4857-84b7-919cd46d09e4', 'BackgroundOperationDetails', 'List', 'False', 'False' , 1, 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b', 'False', 'True', 'False', 'False', 1, 0, 1, 'BACKGROUNDOPERATIONS.COREPATTERNS.BACKGROUNDOPERATIONDETAILS', 'f0716c84-83ec-4db8-a737-9966b088dd0f', 0, 'False', 1, 0)
END
GO

-- BackgroundOperation.BackgroundOperationDetails

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaEntitiesAssociations] WHERE [Id] = '35c28fba-d740-2653-55c3-1d7659afe74a')
BEGIN
    INSERT INTO [CorePatterns].[SchemaEntitiesAssociations] ([Id], [SchemaEntityId], [TargetId], [AttributeId], [IsComposition], [IsManyToMany], [IsActive], [IsDeleted], [IsSystem])
    VALUES ('35c28fba-d740-2653-55c3-1d7659afe74a', 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b', 'f0716c84-83ec-4db8-a737-9966b088dd0f', '0a9bce80-f691-4857-84b7-919cd46d09e4', 1, 0, 1, 0, 1)
END
GO

-- BackgroundOperation.EntityKey

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '7b6aac74-166d-4e68-8bc4-f08273f80ecf')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Entity"}]}', '7b6aac74-166d-4e68-8bc4-f08273f80ecf', 'EntityKey', 'Text', 'False', 'False' , 1, 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b', 'False', 'True', 'False', 'False', 1, 0, 1, 'BACKGROUNDOPERATIONS.COREPATTERNS.ENTITYKEY', NULL, 0, 'False', 1, 0)
END
GO

-- BackgroundOperation.UserName

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '08272572-0554-4682-a641-4d8750972ec2')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"User Name"}]}', '08272572-0554-4682-a641-4d8750972ec2', 'UserName', 'Text', 'False', 'False' , 1, 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b', 'False', 'True', 'False', 'False', 1, 0, 1, 'BACKGROUNDOPERATIONS.COREPATTERNS.USERNAME', NULL, 0, 'False', 1, 0)
END
GO

-- BackgroundOperation.BackgroundOperationStatus

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '8e0756ba-5dce-4733-9484-eacffa774d78')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Background Operation Status"}]}', '8e0756ba-5dce-4733-9484-eacffa774d78', 'BackgroundOperationStatus', 'ValueListItem', 'False', 'False' , 1, 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b', 'False', 'True', 'False', 'False', 1, 0, 1, 'BACKGROUNDOPERATIONS.COREPATTERNS.BACKGROUNDOPERATIONSTATUS', 'aafbe4a9-58c9-4ec3-afef-d764d23ec7e3', 0, 'False', 1, 0)
END
GO

-- BackgroundOperation.BackgroundOperationStatus

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaEntitiesAssociations] WHERE [Id] = '29c366a2-bccb-c926-5293-3aac989ad046')
BEGIN
    INSERT INTO [CorePatterns].[SchemaEntitiesAssociations] ([Id], [SchemaEntityId], [TargetId], [AttributeId], [IsComposition], [IsManyToMany], [IsActive], [IsDeleted], [IsSystem])
    VALUES ('29c366a2-bccb-c926-5293-3aac989ad046', 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b', 'aafbe4a9-58c9-4ec3-afef-d764d23ec7e3', '8e0756ba-5dce-4733-9484-eacffa774d78', 0, 0, 1, 0, 1)
END
GO


IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"BackgroundOperation"}]}', 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b', 'BackgroundOperation', 'View', 0, 0 , 1, 'f0716c84-83ec-4db8-a737-9966b088dd0f', 1, 1, 0, 0, 1, 0, 1, 'BackgroundOperationDetails.CorePatterns.BackgroundOperation', 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b', 0, 0, 0, 0)

END
GO

-- BackgroundOperationDetail.Id

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '1f1af862-ae31-4a36-9463-60a7af405588')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Id"}]}', '1f1af862-ae31-4a36-9463-60a7af405588', 'Id', 'UniqueIdentifier', 'False', 'False' , 1, 'f0716c84-83ec-4db8-a737-9966b088dd0f', 'True', 'True', 'False', 'True', 1, 0, 1, 'BACKGROUNDOPERATIONDETAILS.COREPATTERNS.ID', NULL, 0, 'False', 0, 0)
END
GO

-- BackgroundOperationDetail.Index

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '8d12c307-afad-4bd5-9fa8-c0d18a773351')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Index"}]}', '8d12c307-afad-4bd5-9fa8-c0d18a773351', 'Index', 'Number', 'False', 'False' , 1, 'f0716c84-83ec-4db8-a737-9966b088dd0f', 'True', 'True', 'False', 'True', 1, 0, 1, 'BACKGROUNDOPERATIONDETAILS.COREPATTERNS.INDEX', NULL, 0, 'False', 0, 0)
END
GO

-- BackgroundOperationDetail.CreatedBy

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '6e23acb0-985f-429c-a672-099680cb5772')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Created By"}]}', '6e23acb0-985f-429c-a672-099680cb5772', 'CreatedBy', 'LongText', 'False', 'False' , 1, 'f0716c84-83ec-4db8-a737-9966b088dd0f', 'True', 'True', 'False', 'True', 1, 0, 1, 'BACKGROUNDOPERATIONDETAILS.COREPATTERNS.CREATEDBY', NULL, 0, 'False', 0, 0)
END
GO

-- BackgroundOperationDetail.CreatedOn

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '79d6507c-94a5-453a-bdb0-2527303b0340')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Created On"}]}', '79d6507c-94a5-453a-bdb0-2527303b0340', 'CreatedOn', 'Datetime', 'False', 'False' , 1, 'f0716c84-83ec-4db8-a737-9966b088dd0f', 'True', 'True', 'False', 'True', 1, 0, 1, 'BACKGROUNDOPERATIONDETAILS.COREPATTERNS.CREATEDON', NULL, 0, 'False', 0, 0)
END
GO

-- BackgroundOperationDetail.ModifiedBy

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '45126236-9683-49cc-b963-33bcc8909583')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Modified By"}]}', '45126236-9683-49cc-b963-33bcc8909583', 'ModifiedBy', 'LongText', 'False', 'False' , 1, 'f0716c84-83ec-4db8-a737-9966b088dd0f', 'True', 'True', 'False', 'True', 1, 0, 1, 'BACKGROUNDOPERATIONDETAILS.COREPATTERNS.MODIFIEDBY', NULL, 0, 'False', 0, 0)
END
GO

-- BackgroundOperationDetail.ModifiedOn

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'b5beb7c0-fece-43e4-91a5-d13f6c6abd9f')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Modified On"}]}', 'b5beb7c0-fece-43e4-91a5-d13f6c6abd9f', 'ModifiedOn', 'Datetime', 'False', 'False' , 1, 'f0716c84-83ec-4db8-a737-9966b088dd0f', 'True', 'True', 'False', 'True', 1, 0, 1, 'BACKGROUNDOPERATIONDETAILS.COREPATTERNS.MODIFIEDON', NULL, 0, 'False', 0, 0)
END
GO

-- BackgroundOperationDetail.IsActive

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '6de1e0bd-2668-4007-b0a7-8719bcce8358')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Active"}]}', '6de1e0bd-2668-4007-b0a7-8719bcce8358', 'IsActive', 'Boolean', 'False', 'False' , 1, 'f0716c84-83ec-4db8-a737-9966b088dd0f', 'True', 'True', 'False', 'True', 1, 0, 1, 'BACKGROUNDOPERATIONDETAILS.COREPATTERNS.ISACTIVE', NULL, 0, 'False', 0, 0)
END
GO

-- BackgroundOperationDetail.IsDeleted

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'e74c1ab3-aad8-4c3c-a76d-270fb84e761d')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Deleted"}]}', 'e74c1ab3-aad8-4c3c-a76d-270fb84e761d', 'IsDeleted', 'Boolean', 'False', 'False' , 1, 'f0716c84-83ec-4db8-a737-9966b088dd0f', 'True', 'True', 'True', 'True', 1, 0, 1, 'BACKGROUNDOPERATIONDETAILS.COREPATTERNS.ISDELETED', NULL, 0, 'False', 0, 0)
END
GO

-- BackgroundOperationDetail.IsSystem

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '561ce516-a26a-432c-9d49-4a670c18b20a')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"System"}]}', '561ce516-a26a-432c-9d49-4a670c18b20a', 'IsSystem', 'Boolean', 'False', 'False' , 1, 'f0716c84-83ec-4db8-a737-9966b088dd0f', 'True', 'True', 'False', 'True', 1, 0, 1, 'BACKGROUNDOPERATIONDETAILS.COREPATTERNS.ISSYSTEM', NULL, 0, 'False', 0, 0)
END
GO

-- BackgroundOperationDetail.Description

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '8e57d2e1-634a-4429-b34e-f5fd1dd1d024')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Description"}]}', '8e57d2e1-634a-4429-b34e-f5fd1dd1d024', 'Description', 'LongText', 'False', 'True' , 1, 'f0716c84-83ec-4db8-a737-9966b088dd0f', 'False', 'True', 'False', 'False', 1, 0, 1, 'BACKGROUNDOPERATIONDETAILS.COREPATTERNS.DESCRIPTION', NULL, 0, 'False', 1, 0)
END
GO

-- BackgroundOperationDetail.BackgroundOperationDetailStatus

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'e8aa1f49-a5ff-4533-982b-0803a7ccbf74')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Background Operation Detail Status"}]}', 'e8aa1f49-a5ff-4533-982b-0803a7ccbf74', 'BackgroundOperationDetailStatus', 'ValueListItem', 'False', 'False' , 1, 'f0716c84-83ec-4db8-a737-9966b088dd0f', 'False', 'True', 'False', 'False', 1, 0, 1, 'BACKGROUNDOPERATIONDETAILS.COREPATTERNS.BACKGROUNDOPERATIONDETAILSTATUS', '8b8ad3ea-7ab1-414f-acba-4345b2dea3ce', 0, 'False', 1, 0)
END
GO

-- BackgroundOperationDetail.BackgroundOperationDetailStatus

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaEntitiesAssociations] WHERE [Id] = 'fb56fa89-ea63-d6e7-55da-ee0d3b87a9d7')
BEGIN
    INSERT INTO [CorePatterns].[SchemaEntitiesAssociations] ([Id], [SchemaEntityId], [TargetId], [AttributeId], [IsComposition], [IsManyToMany], [IsActive], [IsDeleted], [IsSystem])
    VALUES ('fb56fa89-ea63-d6e7-55da-ee0d3b87a9d7', 'f0716c84-83ec-4db8-a737-9966b088dd0f', '8b8ad3ea-7ab1-414f-acba-4345b2dea3ce', 'e8aa1f49-a5ff-4533-982b-0803a7ccbf74', 0, 0, 1, 0, 1)
END
GO

-- Operation: 'backgroundoperations'
-- Insert operation

merge [CorePatterns].[Operations] as target 
using(
    select '9e860667-c806-449a-a5b5-10a2caeb94a6' [Id], 'backgroundoperations' [Name], 'corepatterns' [Module], null [ProcessId], N'{"Values":[{ "Culture":"en","Data":"Background Operations"}]}' [LocalizableCaption], '8f9d1046-be79-4071-abb9-688f3cf59b6d' [TypeId], 'C037ABE4-DD29-4C36-A8B3-14D8988D92DB' [OperationTypeSpecificationId], 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b' [SchemaEntityId], 'BackgroundOperations' [ServiceName], 'False' [UseDraft],'False' [ListDraft], 'corepatterns_backgroundoperations' [NaturalKey], '<sys>' [CreatedBy] ,SYSDATETIMEOFFSET() [CreatedOn], '<sys>' [ModifiedBy], SYSDATETIMEOFFSET() [ModifiedOn], 1 [IsActive], 0 [IsDeleted], 1 [IsSystem], 0 [IsDraft]
    ) as source on (source.id = target.id)
when not matched then
    insert ([Id],[Name],[Module],[ProcessId],[LocalizableCaption],[TypeId], [OperationTypeSpecificationId], [SchemaEntityId],[ServiceName], [UseDraft], [ListDraft], [NaturalKey],[CreatedBy],[CreatedOn],[ModifiedBy],[ModifiedOn],[IsActive],[IsDeleted],[IsSystem],[IsDraft])
    values (source.[Id],source.[Name],source.[Module],source.[ProcessId],source.[LocalizableCaption],source.[TypeId], source.[OperationTypeSpecificationId], source.[SchemaEntityId],source.[ServiceName],source.[UseDraft],source.[ListDraft],source.[NaturalKey],source.[CreatedBy],source.[CreatedOn],source.[ModifiedBy],source.[ModifiedOn],source.[IsActive],source.[IsDeleted],source.[IsSystem],source.[IsDraft]);

-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query: [CorePatterns].[CorePatterns.BackgroundOperationsLookup]
-- -- -- -- -- -- -- -- -- -- -- -- 
-- Lookup Query Definition: [CorePatterns].[CorePatterns.BackgroundOperationsLookup]

IF EXISTS ( SELECT  1
            FROM [QueryBuilder].[ListModels]
            WHERE [Id]= 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b')
	DELETE FROM [QueryBuilder].[ListModels] WHERE [Id]= 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b'
GO

INSERT INTO [QueryBuilder].[ListModels] ([Id],[ModuleName],[ServiceName],[Name],[Description],[User],[SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery])
VALUES (
    'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b'
    ,'CorePatterns'
    ,'BackgroundOperations'
    ,'BackgroundOperationsLookup'
	,'{"Values":[{ "Culture":"en","Data":"BackgroundOperation"}]}'
    ,'<sys>'
	,'{"Values":[{ "Culture":"en","Data":"(BackgroundOperation)"}]}'
    ,1
    ,'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b'
    ,'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b'
    ,'<sys>'
    ,1
    ,null
    ,1
    )
GO


-- Column: NaturalKey (NaturalKey) 

INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible])
VALUES (
        'd66cb03c-aafa-44bb-95a9-aeafda2359e6'
        ,'{"Values":[{ "Culture":"en","Data":"BackgroundOperation"}]}'
        ,'True'
        ,'False'
        ,0
        ,'LongText'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b'
        ,0
        ,0
        ,1
        ,'NaturalKey'
        ,'NaturalKey'
        ,'True'
        )
GO

-- List Query TVF: BackgroundOperationsQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'BackgroundOperationsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[BackgroundOperationsQuery]
GO

CREATE FUNCTION  [CorePatterns].[BackgroundOperationsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[NaturalKey] AS [NaturalKey]
FROM [CorePatterns].[BackgroundOperationsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO

-- -- -- -- -- -- -- -- -- -- -- -- 

-- Association Lookup: BackgroundOperation_OperationsForOperationQuery (BackgroundOperations | BackgroundOperation | BackgroundOperation.Operation)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'BackgroundOperation_OperationsForOperationQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[BackgroundOperation_OperationsForOperationQuery]
GO

	CREATE FUNCTION  [CorePatterns].[BackgroundOperation_OperationsForOperationQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[NaturalKey]
FROM [CorePatterns].OperationsQuery(@searchTerm, @user, @culture) [T1]
JOIN [CorePatterns].[OperationsView] [T] ON [T1].[Id] = [T].[Id]
WHERE [T].[IsActive] = 1)
GO

	
	-- Association Lookup: BackgroundOperation_SchemaEntitiesForSchemaEntityQuery (BackgroundOperations | BackgroundOperation | BackgroundOperation.SchemaEntity)

	IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'BackgroundOperation_SchemaEntitiesForSchemaEntityQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[BackgroundOperation_SchemaEntitiesForSchemaEntityQuery]
GO

	CREATE FUNCTION  [CorePatterns].[BackgroundOperation_SchemaEntitiesForSchemaEntityQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[NaturalKey]
FROM [CorePatterns].SchemaEntitiesQuery(@searchTerm, @user, @culture) [T1]
JOIN [CorePatterns].[SchemaEntitiesView] [T] ON [T1].[Id] = [T].[Id]
WHERE [T].[IsActive] = 1)
GO

	
-- CorePatterns.Verify_BackgroundOperation_OperationsForOperationQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_BackgroundOperation_OperationsForOperationQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_BackgroundOperation_OperationsForOperationQuery]
GO

-- [CorePatterns].Verify_BackgroundOperation_OperationsForOperationQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_BackgroundOperation_OperationsForOperationQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_BackgroundOperation_OperationsForOperationQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_BackgroundOperation_OperationsForOperationQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_BackgroundOperation_OperationsForOperationQuery

CREATE FUNCTION [CorePatterns].[Verify_BackgroundOperation_OperationsForOperationQuery] (
     @List AS [CorePatterns].Verify_BackgroundOperation_OperationsForOperationQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[BackgroundOperation_OperationsForOperationQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO


-- CorePatterns.Verify_BackgroundOperation_SchemaEntitiesForSchemaEntityQuery

IF EXISTS ( SELECT  1
            FROM    INFORMATION_SCHEMA.ROUTINES
            WHERE   [SPECIFIC_SCHEMA] = 'CorePatterns' AND 
                    [SPECIFIC_NAME] = 'Verify_BackgroundOperation_SchemaEntitiesForSchemaEntityQuery' AND
                    [ROUTINE_TYPE] = 'FUNCTION' )
    DROP FUNCTION [CorePatterns].[Verify_BackgroundOperation_SchemaEntitiesForSchemaEntityQuery]
GO

-- [CorePatterns].Verify_BackgroundOperation_SchemaEntitiesForSchemaEntityQuery_Parameters

IF EXISTS ( SELECT  1
            FROM    Information_schema.DOMAINS
            WHERE   [DOMAIN_SCHEMA] = 'CorePatterns' AND 
                    [DOMAIN_NAME] = 'Verify_BackgroundOperation_SchemaEntitiesForSchemaEntityQuery_Parameters' AND 
                    [DATA_TYPE] = 'table type' )
    DROP TYPE [CorePatterns].Verify_BackgroundOperation_SchemaEntitiesForSchemaEntityQuery_Parameters
GO

CREATE TYPE [CorePatterns].Verify_BackgroundOperation_SchemaEntitiesForSchemaEntityQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO

-- CorePatterns.Verify_BackgroundOperation_SchemaEntitiesForSchemaEntityQuery

CREATE FUNCTION [CorePatterns].[Verify_BackgroundOperation_SchemaEntitiesForSchemaEntityQuery] (
     @List AS [CorePatterns].Verify_BackgroundOperation_SchemaEntitiesForSchemaEntityQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [CorePatterns].[BackgroundOperation_SchemaEntitiesForSchemaEntityQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO

-- QUERIES SCHEMA

-- Delete query filters

DELETE FROM [QueryBuilder].[ListModelQueryFilters]
WHERE [ListModelId] IN
(
    SELECT [Id]
    FROM [QueryBuilder].[ListModels]
    WHERE [Id]='017ff142-239a-4cfe-a5c4-3c94e7c691d2'
)
GO

-- Delete query actions

DELETE FROM [QueryBuilder].[ListModelQueryActionDetails]
WHERE [ListModelQueryActionId] IN
(
    SELECT [Id] FROM [QueryBuilder].[ListModelQueryActions]
    WHERE [ListModelId] IN
    (
        SELECT [Id]
        FROM [QueryBuilder].[ListModels]
        WHERE [Id]='017ff142-239a-4cfe-a5c4-3c94e7c691d2'
    )
)
GO

DELETE FROM [QueryBuilder].[ListModelQueryActions]
WHERE [ListModelId] IN
(
    SELECT [Id]
    FROM [QueryBuilder].[ListModels]
    WHERE [Id]='017ff142-239a-4cfe-a5c4-3c94e7c691d2'
)
GO

-- Delete query columns

DELETE FROM [QueryBuilder].[ListModelColumns]
WHERE [ListModelId] IN
(
    SELECT [Id]
    FROM [QueryBuilder].[ListModels]
    WHERE [Id]='017ff142-239a-4cfe-a5c4-3c94e7c691d2'
)
GO

-- Delete list models

DELETE FROM [QueryBuilder].[ListModels] WHERE ([Id] = '017ff142-239a-4cfe-a5c4-3c94e7c691d2')
GO


INSERT INTO [QueryBuilder].[ListModels] ([Id], [ModuleName], [ServiceName], [Name], [Description],[User], [SearchPlaceHolder],[Searcheable],[MainEntityId],[NaturalKey],[CreatedBy],[IsSystem],[RuntimeDefinition],[DefaultQuery],[Filter],[FilteredByService],[IsCustomSource],[AggregationHeaderTemplate], [AllowUserCustomization], [HasAggregations], [AllowUserGrouping],[AllowUserSorting], [IncludeDeleted])
VALUES (
    '017ff142-239a-4cfe-a5c4-3c94e7c691d2'
    ,'CorePatterns'
    ,'BackgroundOperations'
    ,'BackgroundOperations'
	,'{"Values":[{ "Culture":"en","Data":"Background Operations"}]}'
    ,'<sys>'
    ,'{"Values":[{ "Culture":"en","Data":"(Description)"}]}'
    ,'True'
    , 'b520dce1-406e-4cfc-a0a2-ef65c3b48d9b'
    ,'017ff142-239a-4cfe-a5c4-3c94e7c691d2'
    ,'<sys>'
    ,1
    ,'{
  "ModuleName": "CorePatterns",
  "ServiceName": "BackgroundOperations",
  "Name": "BackgroundOperations",
  "HasParameters": true,
  "HideSearchComponent": false,
  "Parameters": [
    {
      "Name": "CorrelationId",
      "Type": "RegularFilter",
      "DataType": "UniqueIdentifier"
    },
    {
      "Name": "BackgroundOperationDetailStatus",
      "Type": "RegularFilter",
      "DataType": "ValueListItem"
    }
  ],
  "Columns": [
    {
      "Name": "BackgroundOperationDetailStatus",
      "DataType": "ValueListItem"
    },
    {
      "Name": "Description",
      "DataType": "LongText"
    },
    {
      "Name": "CreatedOnDetail",
      "DataType": "Datetime"
    },
    {
      "Name": "BackgroundOperationStatus",
      "DataType": "ValueListItem"
    },
    {
      "Name": "EntityKey",
      "DataType": "Text"
    },
    {
      "Name": "EntityUri",
      "DataType": "LongText"
    },
    {
      "Name": "LocalizableCaption",
      "DataType": "Text"
    },
    {
      "Name": "CreatedOn",
      "DataType": "Datetime"
    },
    {
      "Name": "UserName",
      "DataType": "Text"
    },
    {
      "Name": "IsOnError",
      "DataType": "Boolean"
    },
    {
      "Name": "GroupHeader",
      "DataType": "LongText"
    }
  ]
}'
    ,1
    ,'((@CorrelationId = "00000000-0000-0000-0000-000000000000" OR [Id] = @CorrelationId) AND (@BackgroundOperationDetailStatus = 0 OR @BackgroundOperationDetailStatus = "" OR[BackgroundOperationDetailStatusValue] = @BackgroundOperationDetailStatus))'
    ,''
    ,'False'
	,''
    ,'False'
    ,'False'
    ,'False'
    ,'True'
	,'False'
    )
GO

    
    -- Get the style id
    
    DECLARE @columnStyleId uniqueidentifier;
    SET @columnStyleId = (SELECT [Id] FROM [QueryBuilder].[ListModelColumnStyles] WHERE [Value] = 0);

	-- Get the standard formatting id
    
    DECLARE @standardFormattingId uniqueidentifier;
    SET @standardFormattingId = (SELECT [Id] FROM [QueryBuilder].[ListModelColumnStandardFormattings] WHERE [Value] = 0);

    -- Get the aggregation expression id
    
    DECLARE @aggregationExpressionId uniqueidentifier;
    SET @aggregationExpressionId = (SELECT [Id] FROM [QueryBuilder].[ListModelAggregationOperations] WHERE [Value] = 0);

	 DECLARE @totalExpressionId uniqueidentifier;
    SET @totalExpressionId = (SELECT [Id] FROM [QueryBuilder].[ListModelAggregationOperations] WHERE [Value] = 0);


    INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [SchemaAttributeId], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible], [Uri], [Searchable], [IsCustom], [CustomExpression], [IsLocalizable], [StyleId], [AggregationOperationId], [TotalOperationId], [DisplayAggregationInFooter], [StandardFormattingId], [StandardFormattingColumn], [GroupHeaderTemplate])
    VALUES (
        '3c189ef7-9f96-4ef9-a1ae-83271fe9ee39'
		,'{"Values":[{ "Culture":"en","Data":"Id"}]}'
        ,'False'
        ,'False'
        , 0
        ,'UniqueIdentifier'
        , NULL
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'017ff142-239a-4cfe-a5c4-3c94e7c691d2'
        ,'False'
        ,0
        ,1
        ,''
        ,'Id'
        ,'True'
        ,''
        ,'True'
        ,'False'
        ,''
        ,'False'
        ,@columnStyleId
        ,@aggregationExpressionId
		,@totalExpressionId
        ,'False'
		,@standardFormattingId
		,''
		,NULL
        )
    GO
    
    -- Get the style id
    
    DECLARE @columnStyleId uniqueidentifier;
    SET @columnStyleId = (SELECT [Id] FROM [QueryBuilder].[ListModelColumnStyles] WHERE [Value] = 0);

	-- Get the standard formatting id
    
    DECLARE @standardFormattingId uniqueidentifier;
    SET @standardFormattingId = (SELECT [Id] FROM [QueryBuilder].[ListModelColumnStandardFormattings] WHERE [Value] = 6);

    -- Get the aggregation expression id
    
    DECLARE @aggregationExpressionId uniqueidentifier;
    SET @aggregationExpressionId = (SELECT [Id] FROM [QueryBuilder].[ListModelAggregationOperations] WHERE [Value] = 0);

	 DECLARE @totalExpressionId uniqueidentifier;
    SET @totalExpressionId = (SELECT [Id] FROM [QueryBuilder].[ListModelAggregationOperations] WHERE [Value] = 0);


    INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [SchemaAttributeId], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible], [Uri], [Searchable], [IsCustom], [CustomExpression], [IsLocalizable], [StyleId], [AggregationOperationId], [TotalOperationId], [DisplayAggregationInFooter], [StandardFormattingId], [StandardFormattingColumn], [GroupHeaderTemplate])
    VALUES (
        '1e3f9507-b3dd-4f73-9915-ff86662bb549'
		,'{"Values":[{ "Culture":"en","Data":"Status"}]}'
        ,'True'
        ,'True'
        , 0
        ,'ValueListItem'
        , 'e8aa1f49-a5ff-4533-982b-0803a7ccbf74'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'017ff142-239a-4cfe-a5c4-3c94e7c691d2'
        ,'False'
        ,0
        ,1
        ,'CorePatterns.BackgroundOperations.BackgroundOperationDetails.0a9bce80-f691-4857-84b7-919cd46d09e4|CorePatterns.BackgroundOperationDetails.BackgroundOperationDetailStatus.e8aa1f49-a5ff-4533-982b-0803a7ccbf74|CorePatterns.BackgroundOperationDetailStatuses.Description.8b8ad3ea-7ab1-414f-acba-4345b2dea3ce'
        ,'BackgroundOperationDetailStatus'
        ,'True'
        ,''
        ,'False'
        ,'False'
        ,''
        ,'False'
        ,@columnStyleId
        ,@aggregationExpressionId
		,@totalExpressionId
        ,'False'
		,@standardFormattingId
		,'IsOnError'
		,NULL
        )
    GO
    
    -- Get the style id
    
    DECLARE @columnStyleId uniqueidentifier;
    SET @columnStyleId = (SELECT [Id] FROM [QueryBuilder].[ListModelColumnStyles] WHERE [Value] = 0);

	-- Get the standard formatting id
    
    DECLARE @standardFormattingId uniqueidentifier;
    SET @standardFormattingId = (SELECT [Id] FROM [QueryBuilder].[ListModelColumnStandardFormattings] WHERE [Value] = 0);

    -- Get the aggregation expression id
    
    DECLARE @aggregationExpressionId uniqueidentifier;
    SET @aggregationExpressionId = (SELECT [Id] FROM [QueryBuilder].[ListModelAggregationOperations] WHERE [Value] = 0);

	 DECLARE @totalExpressionId uniqueidentifier;
    SET @totalExpressionId = (SELECT [Id] FROM [QueryBuilder].[ListModelAggregationOperations] WHERE [Value] = 0);


    INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [SchemaAttributeId], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible], [Uri], [Searchable], [IsCustom], [CustomExpression], [IsLocalizable], [StyleId], [AggregationOperationId], [TotalOperationId], [DisplayAggregationInFooter], [StandardFormattingId], [StandardFormattingColumn], [GroupHeaderTemplate])
    VALUES (
        '41b2ab2f-db89-444f-84e0-543bdd76a90c'
		,'{"Values":[{ "Culture":"en","Data":"Description"}]}'
        ,'True'
        ,'True'
        , 1
        ,'LongText'
        , '8e57d2e1-634a-4429-b34e-f5fd1dd1d024'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'017ff142-239a-4cfe-a5c4-3c94e7c691d2'
        ,'False'
        ,0
        ,1
        ,'CorePatterns.BackgroundOperations.BackgroundOperationDetails.0a9bce80-f691-4857-84b7-919cd46d09e4|CorePatterns.BackgroundOperationDetails.Description.8e57d2e1-634a-4429-b34e-f5fd1dd1d024'
        ,'Description'
        ,'True'
        ,''
        ,'True'
        ,'False'
        ,''
        ,'False'
        ,@columnStyleId
        ,@aggregationExpressionId
		,@totalExpressionId
        ,'False'
		,@standardFormattingId
		,''
		,NULL
        )
    GO
    
    -- Get the style id
    
    DECLARE @columnStyleId uniqueidentifier;
    SET @columnStyleId = (SELECT [Id] FROM [QueryBuilder].[ListModelColumnStyles] WHERE [Value] = 0);

	-- Get the standard formatting id
    
    DECLARE @standardFormattingId uniqueidentifier;
    SET @standardFormattingId = (SELECT [Id] FROM [QueryBuilder].[ListModelColumnStandardFormattings] WHERE [Value] = 0);

    -- Get the aggregation expression id
    
    DECLARE @aggregationExpressionId uniqueidentifier;
    SET @aggregationExpressionId = (SELECT [Id] FROM [QueryBuilder].[ListModelAggregationOperations] WHERE [Value] = 0);

	 DECLARE @totalExpressionId uniqueidentifier;
    SET @totalExpressionId = (SELECT [Id] FROM [QueryBuilder].[ListModelAggregationOperations] WHERE [Value] = 0);


    INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [SchemaAttributeId], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible], [Uri], [Searchable], [IsCustom], [CustomExpression], [IsLocalizable], [StyleId], [AggregationOperationId], [TotalOperationId], [DisplayAggregationInFooter], [StandardFormattingId], [StandardFormattingColumn], [GroupHeaderTemplate])
    VALUES (
        '501c91e3-9362-4336-90f8-041740e26085'
		,'{"Values":[{ "Culture":"en","Data":"Date/Time"}]}'
        ,'True'
        ,'True'
        , 2
        ,'Datetime'
        , '79d6507c-94a5-453a-bdb0-2527303b0340'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'017ff142-239a-4cfe-a5c4-3c94e7c691d2'
        ,'False'
        ,0
        ,1
        ,'CorePatterns.BackgroundOperations.BackgroundOperationDetails.0a9bce80-f691-4857-84b7-919cd46d09e4|CorePatterns.BackgroundOperationDetails.CreatedOn.79d6507c-94a5-453a-bdb0-2527303b0340'
        ,'CreatedOnDetail'
        ,'True'
        ,''
        ,'False'
        ,'False'
        ,''
        ,'False'
        ,@columnStyleId
        ,@aggregationExpressionId
		,@totalExpressionId
        ,'False'
		,@standardFormattingId
		,''
		,NULL
        )
    GO
    
    -- Get the style id
    
    DECLARE @columnStyleId uniqueidentifier;
    SET @columnStyleId = (SELECT [Id] FROM [QueryBuilder].[ListModelColumnStyles] WHERE [Value] = 0);

	-- Get the standard formatting id
    
    DECLARE @standardFormattingId uniqueidentifier;
    SET @standardFormattingId = (SELECT [Id] FROM [QueryBuilder].[ListModelColumnStandardFormattings] WHERE [Value] = 0);

    -- Get the aggregation expression id
    
    DECLARE @aggregationExpressionId uniqueidentifier;
    SET @aggregationExpressionId = (SELECT [Id] FROM [QueryBuilder].[ListModelAggregationOperations] WHERE [Value] = 0);

	 DECLARE @totalExpressionId uniqueidentifier;
    SET @totalExpressionId = (SELECT [Id] FROM [QueryBuilder].[ListModelAggregationOperations] WHERE [Value] = 0);


    INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [SchemaAttributeId], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible], [Uri], [Searchable], [IsCustom], [CustomExpression], [IsLocalizable], [StyleId], [AggregationOperationId], [TotalOperationId], [DisplayAggregationInFooter], [StandardFormattingId], [StandardFormattingColumn], [GroupHeaderTemplate])
    VALUES (
        '866eddfb-9935-4861-9e9c-2dc83fa529c6'
		,'{"Values":[{ "Culture":"en","Data":"Background Operation Status"}]}'
        ,'True'
        ,'True'
        , 3
        ,'ValueListItem'
        , '8e0756ba-5dce-4733-9484-eacffa774d78'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'017ff142-239a-4cfe-a5c4-3c94e7c691d2'
        ,'False'
        ,0
        ,1
        ,'CorePatterns.BackgroundOperations.BackgroundOperationStatus.8e0756ba-5dce-4733-9484-eacffa774d78|CorePatterns.BackgroundOperationStatuses.Description.aafbe4a9-58c9-4ec3-afef-d764d23ec7e3'
        ,'BackgroundOperationStatus'
        ,'False'
        ,''
        ,'False'
        ,'False'
        ,''
        ,'False'
        ,@columnStyleId
        ,@aggregationExpressionId
		,@totalExpressionId
        ,'False'
		,@standardFormattingId
		,''
		,NULL
        )
    GO
    
    -- Get the style id
    
    DECLARE @columnStyleId uniqueidentifier;
    SET @columnStyleId = (SELECT [Id] FROM [QueryBuilder].[ListModelColumnStyles] WHERE [Value] = 0);

	-- Get the standard formatting id
    
    DECLARE @standardFormattingId uniqueidentifier;
    SET @standardFormattingId = (SELECT [Id] FROM [QueryBuilder].[ListModelColumnStandardFormattings] WHERE [Value] = 0);

    -- Get the aggregation expression id
    
    DECLARE @aggregationExpressionId uniqueidentifier;
    SET @aggregationExpressionId = (SELECT [Id] FROM [QueryBuilder].[ListModelAggregationOperations] WHERE [Value] = 0);

	 DECLARE @totalExpressionId uniqueidentifier;
    SET @totalExpressionId = (SELECT [Id] FROM [QueryBuilder].[ListModelAggregationOperations] WHERE [Value] = 0);


    INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [SchemaAttributeId], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible], [Uri], [Searchable], [IsCustom], [CustomExpression], [IsLocalizable], [StyleId], [AggregationOperationId], [TotalOperationId], [DisplayAggregationInFooter], [StandardFormattingId], [StandardFormattingColumn], [GroupHeaderTemplate])
    VALUES (
        '08e61ce0-ade2-4c57-bd9f-c01c9b4ad2ad'
		,'{"Values":[{ "Culture":"en","Data":"Entity"}]}'
        ,'True'
        ,'True'
        , 4
        ,'Text'
        , '7b6aac74-166d-4e68-8bc4-f08273f80ecf'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'017ff142-239a-4cfe-a5c4-3c94e7c691d2'
        ,'False'
        ,0
        ,1
        ,'CorePatterns.BackgroundOperations.EntityKey.7b6aac74-166d-4e68-8bc4-f08273f80ecf'
        ,'EntityKey'
        ,'False'
        ,''
        ,'False'
        ,'False'
        ,''
        ,'False'
        ,@columnStyleId
        ,@aggregationExpressionId
		,@totalExpressionId
        ,'False'
		,@standardFormattingId
		,''
		,NULL
        )
    GO
    
    -- Get the style id
    
    DECLARE @columnStyleId uniqueidentifier;
    SET @columnStyleId = (SELECT [Id] FROM [QueryBuilder].[ListModelColumnStyles] WHERE [Value] = 0);

	-- Get the standard formatting id
    
    DECLARE @standardFormattingId uniqueidentifier;
    SET @standardFormattingId = (SELECT [Id] FROM [QueryBuilder].[ListModelColumnStandardFormattings] WHERE [Value] = 0);

    -- Get the aggregation expression id
    
    DECLARE @aggregationExpressionId uniqueidentifier;
    SET @aggregationExpressionId = (SELECT [Id] FROM [QueryBuilder].[ListModelAggregationOperations] WHERE [Value] = 0);

	 DECLARE @totalExpressionId uniqueidentifier;
    SET @totalExpressionId = (SELECT [Id] FROM [QueryBuilder].[ListModelAggregationOperations] WHERE [Value] = 0);


    INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [SchemaAttributeId], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible], [Uri], [Searchable], [IsCustom], [CustomExpression], [IsLocalizable], [StyleId], [AggregationOperationId], [TotalOperationId], [DisplayAggregationInFooter], [StandardFormattingId], [StandardFormattingColumn], [GroupHeaderTemplate])
    VALUES (
        'e19b056a-f5fb-45a1-9244-753c8ce88020'
		,'{"Values":[{ "Culture":"en","Data":"Entity Uri"}]}'
        ,'True'
        ,'True'
        , 5
        ,'LongText'
        , 'd444b9ef-11e1-4d2a-8ffa-36ab8eed5084'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'017ff142-239a-4cfe-a5c4-3c94e7c691d2'
        ,'False'
        ,0
        ,1
        ,'CorePatterns.BackgroundOperations.EntityUri.d444b9ef-11e1-4d2a-8ffa-36ab8eed5084'
        ,'EntityUri'
        ,'False'
        ,''
        ,'False'
        ,'False'
        ,''
        ,'False'
        ,@columnStyleId
        ,@aggregationExpressionId
		,@totalExpressionId
        ,'False'
		,@standardFormattingId
		,''
		,NULL
        )
    GO
    
    -- Get the style id
    
    DECLARE @columnStyleId uniqueidentifier;
    SET @columnStyleId = (SELECT [Id] FROM [QueryBuilder].[ListModelColumnStyles] WHERE [Value] = 0);

	-- Get the standard formatting id
    
    DECLARE @standardFormattingId uniqueidentifier;
    SET @standardFormattingId = (SELECT [Id] FROM [QueryBuilder].[ListModelColumnStandardFormattings] WHERE [Value] = 0);

    -- Get the aggregation expression id
    
    DECLARE @aggregationExpressionId uniqueidentifier;
    SET @aggregationExpressionId = (SELECT [Id] FROM [QueryBuilder].[ListModelAggregationOperations] WHERE [Value] = 0);

	 DECLARE @totalExpressionId uniqueidentifier;
    SET @totalExpressionId = (SELECT [Id] FROM [QueryBuilder].[ListModelAggregationOperations] WHERE [Value] = 0);


    INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [SchemaAttributeId], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible], [Uri], [Searchable], [IsCustom], [CustomExpression], [IsLocalizable], [StyleId], [AggregationOperationId], [TotalOperationId], [DisplayAggregationInFooter], [StandardFormattingId], [StandardFormattingColumn], [GroupHeaderTemplate])
    VALUES (
        '00907d58-fb19-4c3b-ab36-e05edbe4175c'
		,'{"Values":[{ "Culture":"en","Data":"Localizable Caption"}]}'
        ,'True'
        ,'True'
        , 6
        ,'Text'
        , 'd26203fb-1f16-421e-aa82-abedb940f5c5'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'017ff142-239a-4cfe-a5c4-3c94e7c691d2'
        ,'False'
        ,0
        ,1
        ,'CorePatterns.BackgroundOperations.Operation.08fdbd45-8e5d-4f86-85b7-ce4e126de3dc|CorePatterns.Operations.LocalizableCaption.d26203fb-1f16-421e-aa82-abedb940f5c5'
        ,'LocalizableCaption'
        ,'False'
        ,''
        ,'False'
        ,'False'
        ,''
        ,'True'
        ,@columnStyleId
        ,@aggregationExpressionId
		,@totalExpressionId
        ,'False'
		,@standardFormattingId
		,''
		,NULL
        )
    GO
    
    -- Get the style id
    
    DECLARE @columnStyleId uniqueidentifier;
    SET @columnStyleId = (SELECT [Id] FROM [QueryBuilder].[ListModelColumnStyles] WHERE [Value] = 0);

	-- Get the standard formatting id
    
    DECLARE @standardFormattingId uniqueidentifier;
    SET @standardFormattingId = (SELECT [Id] FROM [QueryBuilder].[ListModelColumnStandardFormattings] WHERE [Value] = 0);

    -- Get the aggregation expression id
    
    DECLARE @aggregationExpressionId uniqueidentifier;
    SET @aggregationExpressionId = (SELECT [Id] FROM [QueryBuilder].[ListModelAggregationOperations] WHERE [Value] = 0);

	 DECLARE @totalExpressionId uniqueidentifier;
    SET @totalExpressionId = (SELECT [Id] FROM [QueryBuilder].[ListModelAggregationOperations] WHERE [Value] = 0);


    INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [SchemaAttributeId], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible], [Uri], [Searchable], [IsCustom], [CustomExpression], [IsLocalizable], [StyleId], [AggregationOperationId], [TotalOperationId], [DisplayAggregationInFooter], [StandardFormattingId], [StandardFormattingColumn], [GroupHeaderTemplate])
    VALUES (
        '82a0cfee-b78c-4e47-95b5-2063fa7f2dc1'
		,'{"Values":[{ "Culture":"en","Data":"Created On 2"}]}'
        ,'True'
        ,'True'
        , 7
        ,'Datetime'
        , '53586d3b-dbed-4c8a-9cfb-03fdf406c902'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'017ff142-239a-4cfe-a5c4-3c94e7c691d2'
        ,'False'
        ,0
        ,1
        ,'CorePatterns.BackgroundOperations.CreatedOn.53586d3b-dbed-4c8a-9cfb-03fdf406c902'
        ,'CreatedOn'
        ,'False'
        ,''
        ,'False'
        ,'False'
        ,''
        ,'False'
        ,@columnStyleId
        ,@aggregationExpressionId
		,@totalExpressionId
        ,'False'
		,@standardFormattingId
		,''
		,NULL
        )
    GO
    
    -- Get the style id
    
    DECLARE @columnStyleId uniqueidentifier;
    SET @columnStyleId = (SELECT [Id] FROM [QueryBuilder].[ListModelColumnStyles] WHERE [Value] = 0);

	-- Get the standard formatting id
    
    DECLARE @standardFormattingId uniqueidentifier;
    SET @standardFormattingId = (SELECT [Id] FROM [QueryBuilder].[ListModelColumnStandardFormattings] WHERE [Value] = 0);

    -- Get the aggregation expression id
    
    DECLARE @aggregationExpressionId uniqueidentifier;
    SET @aggregationExpressionId = (SELECT [Id] FROM [QueryBuilder].[ListModelAggregationOperations] WHERE [Value] = 0);

	 DECLARE @totalExpressionId uniqueidentifier;
    SET @totalExpressionId = (SELECT [Id] FROM [QueryBuilder].[ListModelAggregationOperations] WHERE [Value] = 0);


    INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [SchemaAttributeId], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible], [Uri], [Searchable], [IsCustom], [CustomExpression], [IsLocalizable], [StyleId], [AggregationOperationId], [TotalOperationId], [DisplayAggregationInFooter], [StandardFormattingId], [StandardFormattingColumn], [GroupHeaderTemplate])
    VALUES (
        '298d8cd5-bf1c-4c89-93d2-4dc6d8da0302'
		,'{"Values":[{ "Culture":"en","Data":"User Name"}]}'
        ,'True'
        ,'True'
        , 8
        ,'Text'
        , '08272572-0554-4682-a641-4d8750972ec2'
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'017ff142-239a-4cfe-a5c4-3c94e7c691d2'
        ,'False'
        ,0
        ,1
        ,'CorePatterns.BackgroundOperations.UserName.08272572-0554-4682-a641-4d8750972ec2'
        ,'UserName'
        ,'False'
        ,''
        ,'False'
        ,'False'
        ,''
        ,'False'
        ,@columnStyleId
        ,@aggregationExpressionId
		,@totalExpressionId
        ,'False'
		,@standardFormattingId
		,''
		,NULL
        )
    GO
    
    -- Get the style id
    
    DECLARE @columnStyleId uniqueidentifier;
    SET @columnStyleId = (SELECT [Id] FROM [QueryBuilder].[ListModelColumnStyles] WHERE [Value] = 0);

	-- Get the standard formatting id
    
    DECLARE @standardFormattingId uniqueidentifier;
    SET @standardFormattingId = (SELECT [Id] FROM [QueryBuilder].[ListModelColumnStandardFormattings] WHERE [Value] = 0);

    -- Get the aggregation expression id
    
    DECLARE @aggregationExpressionId uniqueidentifier;
    SET @aggregationExpressionId = (SELECT [Id] FROM [QueryBuilder].[ListModelAggregationOperations] WHERE [Value] = 0);

	 DECLARE @totalExpressionId uniqueidentifier;
    SET @totalExpressionId = (SELECT [Id] FROM [QueryBuilder].[ListModelAggregationOperations] WHERE [Value] = 0);


    INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [SchemaAttributeId], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible], [Uri], [Searchable], [IsCustom], [CustomExpression], [IsLocalizable], [StyleId], [AggregationOperationId], [TotalOperationId], [DisplayAggregationInFooter], [StandardFormattingId], [StandardFormattingColumn], [GroupHeaderTemplate])
    VALUES (
        '045763e2-ee12-4d14-9280-684024499410'
		,'{"Values":[{ "Culture":"en","Data":"Is On Error"}]}'
        ,'True'
        ,'True'
        , 9
        ,'Boolean'
        , NULL
        ,'None'
        ,-1
        ,'None'
        ,-1
        ,'017ff142-239a-4cfe-a5c4-3c94e7c691d2'
        ,'False'
        ,0
        ,1
        ,'CustomColumn.CorePatterns.BackgroundOperations.IsOnError'
        ,'IsOnError'
        ,'False'
        ,''
        ,'False'
        ,'True'
        ,'(CASE WHEN [SRC].[BackgroundOperationDetailStatus] = ''Failed'' THEN 1 ELSE 0 END)'
        ,'False'
        ,@columnStyleId
        ,@aggregationExpressionId
		,@totalExpressionId
        ,'False'
		,@standardFormattingId
		,''
		,NULL
        )
    GO
    
    -- Get the style id
    
    DECLARE @columnStyleId uniqueidentifier;
    SET @columnStyleId = (SELECT [Id] FROM [QueryBuilder].[ListModelColumnStyles] WHERE [Value] = 0);

	-- Get the standard formatting id
    
    DECLARE @standardFormattingId uniqueidentifier;
    SET @standardFormattingId = (SELECT [Id] FROM [QueryBuilder].[ListModelColumnStandardFormattings] WHERE [Value] = 0);

    -- Get the aggregation expression id
    
    DECLARE @aggregationExpressionId uniqueidentifier;
    SET @aggregationExpressionId = (SELECT [Id] FROM [QueryBuilder].[ListModelAggregationOperations] WHERE [Value] = 0);

	 DECLARE @totalExpressionId uniqueidentifier;
    SET @totalExpressionId = (SELECT [Id] FROM [QueryBuilder].[ListModelAggregationOperations] WHERE [Value] = 0);


    INSERT INTO [QueryBuilder].[ListModelColumns]
    ([Id], [Description], [Sortable], [Groupable], [DisplayOrder], [PresentationDataType], [SchemaAttributeId], [GroupByDirection], [GroupByIndex], [OrderByDirection], [OrderByIndex], [ListModelId], [IsMainDrillDown], [Index], [IsSystem], [Path], [Name], [IsVisible], [Uri], [Searchable], [IsCustom], [CustomExpression], [IsLocalizable], [StyleId], [AggregationOperationId], [TotalOperationId], [DisplayAggregationInFooter], [StandardFormattingId], [StandardFormattingColumn], [GroupHeaderTemplate])
    VALUES (
        'c399fe2d-b02c-48a2-a199-1563d2001c4f'
		,'{"Values":[{ "Culture":"en","Data":"Operation"}]}'
        ,'True'
        ,'True'
        , 10
        ,'LongText'
        , NULL
        ,'Desc'
        ,'1'
        ,'Desc'
        ,'1'
        ,'017ff142-239a-4cfe-a5c4-3c94e7c691d2'
        ,'False'
        ,0
        ,1
        ,'CustomColumn.CorePatterns.BackgroundOperations.GroupHeader'
        ,'GroupHeader'
        ,'True'
        ,''
        ,'False'
        ,'True'
        ,'CONCAT([SRC].[CreatedOn],''$'',[SRC].[LocalizableCaption],''$'', [SRC].[EntityKey],''$'',[SRC].[UserName],''$'',[SRC].[EntityUri], ''$'', [SRC].[BackgroundOperationStatusValue], ''$'', [SRC].[BackgroundOperationStatus])'
        ,'False'
        ,@columnStyleId
        ,@aggregationExpressionId
		,@totalExpressionId
        ,'False'
		,@standardFormattingId
		,''
		,'<span>{1}: </span><a href="{4}">{2}</a><span class="operation-createdby"> ({3}) </span><span class="operation-status status-{5}">{6}</span>'
        )
    GO
			

INSERT INTO [QueryBuilder].[ListModelQueryFilters]
           ([Id], [Index], [Name], [Required], [Type], [DataType], [Description], [ReportVisible], [Value], [Column], [Table], [ListModelId], [IsSystem])
     VALUES
           ('69fd1691-95be-13eb-4dbe-b4484f4dcbef',
            0,
           'CorrelationId',
           'True',
           'RegularFilter',
           'UniqueIdentifier',
		   '{"Values":[{ "Culture":"en","Data":"Correlation Id"}]}',
           'True',
           '',
           '',
           '',
           '017ff142-239a-4cfe-a5c4-3c94e7c691d2',
           'True')
GO
			

INSERT INTO [QueryBuilder].[ListModelQueryFilters]
           ([Id], [Index], [Name], [Required], [Type], [DataType], [Description], [ReportVisible], [Value], [Column], [Table], [ListModelId], [IsSystem])
     VALUES
           ('f0435e23-92bb-f856-1165-d4ec38a077f1',
            1,
           'BackgroundOperationDetailStatus',
           'True',
           'RegularFilter',
           'ValueListItem',
		   '{"Values":[{ "Culture":"en","Data":"Status"}]}',
           'True',
           '',
           '',
           '',
           '017ff142-239a-4cfe-a5c4-3c94e7c691d2',
           'True')
GO

--- [CorePatterns].[BackgroundOperations_BackgroundOperationsQuery] (Default Entity TVF)

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'BackgroundOperations_BackgroundOperationsQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[BackgroundOperations_BackgroundOperationsQuery]
GO

CREATE FUNCTION  [CorePatterns].[BackgroundOperations_BackgroundOperationsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL', @CorrelationId UNIQUEIDENTIFIER  = 'Guid.Empty', @BackgroundOperationDetailStatus NVARCHAR(20)  = '')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM (SELECT [SRC].[Id], [SRC].[Source_NaturalKey], [SRC].[BackgroundOperationDetailStatusId], [SRC].[BackgroundOperationDetailStatusValue], [SRC].[BackgroundOperationDetailStatus], [SRC].[Description], [SRC].[BackgroundOperationDetailId], [SRC].[CreatedOnDetail], [SRC].[BackgroundOperationStatusId], [SRC].[BackgroundOperationStatusValue], [SRC].[BackgroundOperationStatus], [SRC].[EntityKey], [SRC].[EntityUri], [SRC].[LocalizableCaption], [SRC].[OperationId], [SRC].[CreatedOn], [SRC].[UserName], ((CASE WHEN [SRC].[BackgroundOperationDetailStatus] = 'Failed' THEN 1 ELSE 0 END)) AS [IsOnError], (CONCAT([SRC].[CreatedOn],'$',[SRC].[LocalizableCaption],'$', [SRC].[EntityKey],'$',[SRC].[UserName],'$',[SRC].[EntityUri], '$', [SRC].[BackgroundOperationStatusValue], '$', [SRC].[BackgroundOperationStatus])) AS [GroupHeader]
FROM (SELECT [T0].[Id] AS [Id], [T0].[NaturalKey] AS [Source_NaturalKey], [T2].[Id] AS [BackgroundOperationDetailStatusId], [T2].[Value] AS [BackgroundOperationDetailStatusValue], [CorePatterns].[GetLocalizedValue]([T2].[Description], @culture) AS [BackgroundOperationDetailStatus], [T1].[Description] AS [Description], [T1].[Id] AS [BackgroundOperationDetailId], [T1].[CreatedOn] AS [CreatedOnDetail], [T3].[Id] AS [BackgroundOperationStatusId], [T3].[Value] AS [BackgroundOperationStatusValue], [CorePatterns].[GetLocalizedValue]([T3].[Description], @culture) AS [BackgroundOperationStatus], [T0].[EntityKey] AS [EntityKey], [T0].[EntityUri] AS [EntityUri], [CorePatterns].[GetLocalizedValue]([T4].[LocalizableCaption], @culture) AS [LocalizableCaption], [T4].[Id] AS [OperationId], [T0].[CreatedOn] AS [CreatedOn], [T0].[UserName] AS [UserName]
FROM [CorePatterns].[BackgroundOperationsView] [T0]
LEFT JOIN [CorePatterns].[BackgroundOperationDetailsView] [T1] ON [T0].[Id] = [T1].[BackgroundOperationId]
LEFT JOIN [CorePatterns].[BackgroundOperationDetailStatusesView] [T2] ON [T1].[BackgroundOperationDetailStatusId] = [T2].[Id]
LEFT JOIN [CorePatterns].[BackgroundOperationStatusesView] [T3] ON [T0].[BackgroundOperationStatusId] = [T3].[Id]
LEFT JOIN [CorePatterns].[OperationsView] [T4] ON [T0].[OperationId] = [T4].[Id]
WHERE (ISNULL([T1].[Description] COLLATE Latin1_general_CI_AI, '') LIKE @searchTerm COLLATE Latin1_general_CI_AI)) [SRC]) [FILTERSRC]
WHERE ((@CorrelationId = '00000000-0000-0000-0000-000000000000' OR [Id] = @CorrelationId) AND (@BackgroundOperationDetailStatus = 0 OR @BackgroundOperationDetailStatus = '' OR[BackgroundOperationDetailStatusValue] = @BackgroundOperationDetailStatus)))
GO
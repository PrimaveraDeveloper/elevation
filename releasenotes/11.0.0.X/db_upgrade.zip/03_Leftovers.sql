/*
The column [Reporting].[ReportModelDefinitions].[TemplateId] is being dropped, data loss could occur.
*/
IF COL_LENGTH(N'[Reporting].[ReportModelDefinitions]', 'TemplateId') IS NULL
BEGIN
    ALTER TABLE [Reporting].[ReportModelDefinitions] ADD [TemplateId] [uniqueidentifier] NULL
END
PRINT N'Dropping [CorePatterns].[BackgroundOperationDetails].[BackgroundOperationDetails_IDX1]...';
GO
IF EXISTS(SELECT * FROM sys.indexes WHERE name = 'BackgroundOperationDetails_IDX1' AND object_id = OBJECT_ID('[CorePatterns].[BackgroundOperationDetails]'))
	DROP INDEX [BackgroundOperationDetails_IDX1] ON [CorePatterns].[BackgroundOperationDetails];
GO
PRINT N'Dropping [Identity].[CompanyAccessRestrictions].[CompanyAccessRestrictions_IDX0]...';
GO
IF EXISTS(SELECT * FROM sys.indexes WHERE name = 'CompanyAccessRestrictions_IDX0' AND object_id = OBJECT_ID('[Identity].[CompanyAccessRestrictions]'))
	DROP INDEX [CompanyAccessRestrictions_IDX0] ON [Identity].[CompanyAccessRestrictions];
GO
PRINT N'Dropping [Identity].[GroupsUsers].[GroupsUsers_IDX0]...';
GO
IF EXISTS(SELECT * FROM sys.indexes WHERE name = 'GroupsUsers_IDX0' AND object_id = OBJECT_ID('[Identity].[GroupsUsers]'))
	DROP INDEX [GroupsUsers_IDX0] ON [Identity].[GroupsUsers];
GO
PRINT N'Dropping [Identity].[RestrictedGroups].[RestrictedGroups_IDX1]...';
GO
IF EXISTS(SELECT * FROM sys.indexes WHERE name = 'RestrictedGroups_IDX1' AND object_id = OBJECT_ID('[Identity].[RestrictedGroups]'))
	DROP INDEX [RestrictedGroups_IDX1] ON [Identity].[RestrictedGroups];
GO
PRINT N'Dropping [Identity].[RowLevelSecurityClaims].[RowLevelSecurityClaims_IDX_SchemaEntityIdRecordId]...';
GO
IF EXISTS(SELECT * FROM sys.indexes WHERE name = 'RowLevelSecurityClaims_IDX_SchemaEntityIdRecordId' AND object_id = OBJECT_ID('[Identity].[RowLevelSecurityClaims]'))
	DROP INDEX [RowLevelSecurityClaims_IDX_SchemaEntityIdRecordId] ON [Identity].[RowLevelSecurityClaims];
GO
PRINT N'Dropping [Identity].[RowLevelSecurityClaims].[RowLevelSecurityClaims_IDX0]...';
GO
IF EXISTS(SELECT * FROM sys.indexes WHERE name = 'RowLevelSecurityClaims_IDX0' AND object_id = OBJECT_ID('[Identity].[RowLevelSecurityClaims]'))
	DROP INDEX [RowLevelSecurityClaims_IDX0] ON [Identity].[RowLevelSecurityClaims];
GO
PRINT N'Dropping [Identity].[UserAccessClaims].[UserAccessClaims_IDX0]...';

GO
IF EXISTS(SELECT * FROM sys.indexes WHERE name = 'UserAccessClaims_IDX0' AND object_id = OBJECT_ID('[Identity].[UserAccessClaims]'))
	DROP INDEX [UserAccessClaims_IDX0] ON [Identity].[UserAccessClaims];
GO
PRINT N'Dropping [CorePatterns].[Companies_ModifiedOn_DF]...';

GO
IF OBJECT_ID('[CorePatterns].[Companies].[Companies_ModifiedOn_DF]', 'C') IS NOT NULL
	ALTER TABLE [CorePatterns].[Companies] DROP CONSTRAINT [Companies_ModifiedOn_DF];
GO
PRINT N'Dropping [CorePatterns].[Companies_IsActive_DF]...';
GO
IF OBJECT_ID('[CorePatterns].[Companies].[Companies_IsActive_DF]', 'C') IS NOT NULL
	ALTER TABLE [CorePatterns].[Companies] DROP CONSTRAINT [Companies_IsActive_DF];
GO
PRINT N'Dropping [CorePatterns].[Companies_Id_DF]...';
GO
IF OBJECT_ID('[CorePatterns].[Companies].[Companies_Id_DF]', 'C') IS NOT NULL
	ALTER TABLE [CorePatterns].[Companies] DROP CONSTRAINT [Companies_Id_DF];
GO
PRINT N'Dropping [CorePatterns].[Companies_ShowExchangeRateReversed_DF]...';


GO
IF OBJECT_ID('[CorePatterns].[Companies].[Companies_ShowExchangeRateReversed_DF]', 'C') IS NOT NULL
	ALTER TABLE [CorePatterns].[Companies] DROP CONSTRAINT [Companies_ShowExchangeRateReversed_DF];
GO
PRINT N'Dropping [CorePatterns].[Companies_IsDraft_DF]...';


GO
IF OBJECT_ID('[CorePatterns].[Companies].[Companies_IsDraft_DF]', 'C') IS NOT NULL
	ALTER TABLE [CorePatterns].[Companies] DROP CONSTRAINT [Companies_IsDraft_DF];
GO
PRINT N'Dropping [CorePatterns].[Companies_ModifiedBy_DF]...';
GO
IF OBJECT_ID('[CorePatterns].[Companies].[Companies_ModifiedBy_DF]', 'C') IS NOT NULL
	ALTER TABLE [CorePatterns].[Companies] DROP CONSTRAINT [Companies_ModifiedBy_DF];
GO
PRINT N'Dropping [CorePatterns].[Companies_IsDeleted_DF]...';
GO
IF OBJECT_ID('[CorePatterns].[Companies].[Companies_IsDeleted_DF]', 'C') IS NOT NULL
	ALTER TABLE [CorePatterns].[Companies] DROP CONSTRAINT [Companies_IsDeleted_DF];
GO
PRINT N'Dropping [CorePatterns].[Companies_IsSystem_DF]...';
GO
IF OBJECT_ID('[CorePatterns].[Companies].[Companies_IsSystem_DF]', 'C') IS NOT NULL
	ALTER TABLE [CorePatterns].[Companies] DROP CONSTRAINT [Companies_IsSystem_DF];
GO
PRINT N'Dropping [CorePatterns].[Companies_CreatedOn_DF]...';
GO
IF OBJECT_ID('[CorePatterns].[Companies].[Companies_CreatedOn_DF]', 'C') IS NOT NULL
	ALTER TABLE [CorePatterns].[Companies] DROP CONSTRAINT [Companies_CreatedOn_DF];
GO
PRINT N'Dropping [CorePatterns].[Companies_CreatedBy_DF]...';
GO
IF OBJECT_ID('[CorePatterns].[Companies].[Companies_CreatedBy_DF]', 'C') IS NOT NULL
	ALTER TABLE [CorePatterns].[Companies] DROP CONSTRAINT [Companies_CreatedBy_DF];
GO
PRINT N'Dropping [Identity].[Groups_ModifiedOn_DF]...';
GO
IF OBJECT_ID('[Identity].[Groups].[Groups_ModifiedOn_DF]', 'C') IS NOT NULL
	ALTER TABLE [Identity].[Groups] DROP CONSTRAINT [Groups_ModifiedOn_DF];
GO
PRINT N'Dropping [Identity].[Groups_IsSystem_DF]...';
GO
IF OBJECT_ID('[Identity].[Groups].[Groups_IsSystem_DF]', 'C') IS NOT NULL
	ALTER TABLE [Identity].[Groups] DROP CONSTRAINT [Groups_IsSystem_DF];
GO
PRINT N'Dropping [Identity].[Groups_IsDeleted_DF]...';
GO
IF OBJECT_ID('[Identity].[Groups].[Groups_ModifiedOn_DF]', 'C') IS NOT NULL
	ALTER TABLE [Identity].[Groups] DROP CONSTRAINT [Groups_ModifiedOn_DF];
GO
PRINT N'Dropping [Identity].[Groups_CreatedOn_DF]...';
GO
IF OBJECT_ID('[Identity].[Groups].[Groups_CreatedOn_DF]', 'C') IS NOT NULL
	ALTER TABLE [Identity].[Groups] DROP CONSTRAINT [Groups_CreatedOn_DF];
GO
PRINT N'Dropping [Identity].[Groups_IsActive_DF]...';
GO
IF OBJECT_ID('[Identity].[Groups].[Groups_IsActive_DF]', 'C') IS NOT NULL
	ALTER TABLE [Identity].[Groups] DROP CONSTRAINT [Groups_IsActive_DF];
GO
PRINT N'Dropping [Identity].[Groups_CreatedBy_DF]...';


GO
IF OBJECT_ID('[Identity].[Groups].[Groups_CreatedBy_DF]', 'C') IS NOT NULL
	ALTER TABLE [Identity].[Groups] DROP CONSTRAINT [Groups_CreatedBy_DF];
GO
PRINT N'Dropping [Identity].[Groups_ModifiedBy_DF]...';


GO
IF OBJECT_ID('[Identity].[Groups].[Groups_ModifiedBy_DF]', 'C') IS NOT NULL
	ALTER TABLE [Identity].[Groups] DROP CONSTRAINT [Groups_ModifiedBy_DF];
GO
PRINT N'Dropping [Identity].[Groups_IsDraft_DF]...';


GO
IF OBJECT_ID('[Identity].[Groups].[Groups_IsDraft_DF]', 'C') IS NOT NULL
	ALTER TABLE [Identity].[Groups] DROP CONSTRAINT [Groups_IsDraft_DF];
GO
PRINT N'Dropping [Identity].[Groups_Id_DF]...';


GO
IF OBJECT_ID('[Identity].[Groups].[Groups_Id_DF]', 'C') IS NOT NULL
	ALTER TABLE [Identity].[Groups] DROP CONSTRAINT [Groups_Id_DF];
GO
PRINT N'Dropping [QueryBuilder].[ListModelColumns_IsDeleted_DF]...';


GO
IF OBJECT_ID('[Identity].[Groups].[ListModelColumns_IsDeleted_DF]', 'C') IS NOT NULL
	ALTER TABLE [QueryBuilder].[ListModelColumns] DROP CONSTRAINT [ListModelColumns_IsDeleted_DF];
GO
PRINT N'Dropping [QueryBuilder].[ListModelColumns_ModifiedOn_DF]...';


GO
IF OBJECT_ID('[QueryBuilder].[ListModelColumns].[ListModelColumns_ModifiedOn_DF]', 'C') IS NOT NULL
	ALTER TABLE [QueryBuilder].[ListModelColumns] DROP CONSTRAINT [ListModelColumns_ModifiedOn_DF];
GO
PRINT N'Dropping [QueryBuilder].[ListModelColumns_Id_DF]...';


GO
IF OBJECT_ID('[QueryBuilder].[ListModelColumns].[ListModelColumns_Id_DF]', 'C') IS NOT NULL
	ALTER TABLE [QueryBuilder].[ListModelColumns] DROP CONSTRAINT [ListModelColumns_Id_DF];
GO
PRINT N'Dropping [QueryBuilder].[ListModelColumns_CreatedOn_DF]...';


GO
IF OBJECT_ID('[QueryBuilder].[ListModelColumns].[ListModelColumns_CreatedOn_DF]', 'C') IS NOT NULL
	ALTER TABLE [QueryBuilder].[ListModelColumns] DROP CONSTRAINT [ListModelColumns_CreatedOn_DF];
GO
PRINT N'Dropping [QueryBuilder].[ListModelColumns_IsCustomAttribute_DF]...';


GO
IF OBJECT_ID('[QueryBuilder].[ListModelColumns].[ListModelColumns_IsCustomAttribute_DF]', 'C') IS NOT NULL
	ALTER TABLE [QueryBuilder].[ListModelColumns] DROP CONSTRAINT [ListModelColumns_IsCustomAttribute_DF];
GO
PRINT N'Dropping [QueryBuilder].[ListModelColumns_ModifiedBy_DF]...';


GO
IF OBJECT_ID('[QueryBuilder].[ListModelColumns].[ListModelColumns_ModifiedBy_DF]', 'C') IS NOT NULL
	ALTER TABLE [QueryBuilder].[ListModelColumns] DROP CONSTRAINT [ListModelColumns_ModifiedBy_DF];
GO
PRINT N'Dropping [QueryBuilder].[ListModelColumns_CreatedBy_DF]...';


GO
IF OBJECT_ID('[QueryBuilder].[ListModelColumns].[ListModelColumns_CreatedBy_DF]', 'C') IS NOT NULL
	ALTER TABLE [QueryBuilder].[ListModelColumns] DROP CONSTRAINT [ListModelColumns_CreatedBy_DF];
GO
PRINT N'Dropping [QueryBuilder].[ListModelColumns_IsSystem_DF]...';


GO
IF OBJECT_ID('[QueryBuilder].[ListModelColumns].[ListModelColumns_IsSystem_DF]', 'C') IS NOT NULL
	ALTER TABLE [QueryBuilder].[ListModelColumns] DROP CONSTRAINT [ListModelColumns_IsSystem_DF];
GO
PRINT N'Dropping [QueryBuilder].[ListModelColumns_Index_DF]...';


GO
IF OBJECT_ID('[QueryBuilder].[ListModelColumns].[ListModelColumns_Index_DF]', 'C') IS NOT NULL
	ALTER TABLE [QueryBuilder].[ListModelColumns] DROP CONSTRAINT [ListModelColumns_Index_DF];
GO
PRINT N'Dropping [QueryBuilder].[ListModelColumns_IsActive_DF]...';


GO
IF OBJECT_ID('[QueryBuilder].[ListModelColumns].[ListModelColumns_IsActive_DF]', 'C') IS NOT NULL
	ALTER TABLE [QueryBuilder].[ListModelColumns] DROP CONSTRAINT [ListModelColumns_IsActive_DF];
GO
PRINT N'Dropping [CorePatterns].[BackgroundOperationDetails_CreatedOn_DF]...';


GO
IF OBJECT_ID('[QueryBuilder].[BackgroundOperationDetails].[BackgroundOperationDetails_CreatedOn_DF]', 'C') IS NOT NULL
	ALTER TABLE [CorePatterns].[BackgroundOperationDetails] DROP CONSTRAINT [BackgroundOperationDetails_CreatedOn_DF];
GO
PRINT N'Dropping [CorePatterns].[BackgroundOperationDetails_Id_DF]...';


GO
IF OBJECT_ID('[QueryBuilder].[BackgroundOperationDetails].[BackgroundOperationDetails_Id_DF]', 'C') IS NOT NULL
	ALTER TABLE [CorePatterns].[BackgroundOperationDetails] DROP CONSTRAINT [BackgroundOperationDetails_Id_DF];
GO
PRINT N'Dropping [CorePatterns].[BackgroundOperationDetails_ModifiedOn_DF]...';


GO
IF OBJECT_ID('[QueryBuilder].[BackgroundOperationDetails].[BackgroundOperationDetails_ModifiedOn_DF]', 'C') IS NOT NULL
	ALTER TABLE [CorePatterns].[BackgroundOperationDetails] DROP CONSTRAINT [BackgroundOperationDetails_ModifiedOn_DF];
GO
PRINT N'Dropping [CorePatterns].[BackgroundOperationDetails_IsDeleted_DF]...';


GO
IF OBJECT_ID('[QueryBuilder].[BackgroundOperationDetails].[BackgroundOperationDetails_IsDeleted_DF]', 'C') IS NOT NULL
	ALTER TABLE [CorePatterns].[BackgroundOperationDetails] DROP CONSTRAINT [BackgroundOperationDetails_IsDeleted_DF];
GO
PRINT N'Dropping [CorePatterns].[BackgroundOperationDetails_IsSystem_DF]...';


GO
IF OBJECT_ID('[QueryBuilder].[BackgroundOperationDetails].[BackgroundOperationDetails_IsSystem_DF]', 'C') IS NOT NULL
	ALTER TABLE [CorePatterns].[BackgroundOperationDetails] DROP CONSTRAINT [BackgroundOperationDetails_IsSystem_DF];
GO

PRINT N'Dropping [CorePatterns].[BackgroundOperationDetails_ModifiedBy_DF]...';


GO
IF OBJECT_ID('[QueryBuilder].[BackgroundOperationDetails].[BackgroundOperationDetails_ModifiedBy_DF]', 'C') IS NOT NULL
	ALTER TABLE [CorePatterns].[BackgroundOperationDetails] DROP CONSTRAINT [BackgroundOperationDetails_ModifiedBy_DF];
GO
PRINT N'Dropping [CorePatterns].[BackgroundOperationDetails_ModifiedOn_DF]...';


GO
IF OBJECT_ID('[QueryBuilder].[BackgroundOperationDetails].[BackgroundOperationDetails_ModifiedOn_DF]', 'C') IS NOT NULL
	ALTER TABLE [CorePatterns].[BackgroundOperationDetails] DROP CONSTRAINT [BackgroundOperationDetails_ModifiedOn_DF];
GO
PRINT N'Dropping [CorePatterns].[Companies_Addresses_AddressId_FK]...';


GO
IF OBJECT_ID('[CorePatterns].[Companies].[Companies_Addresses_AddressId_FK]', 'C') IS NOT NULL
	ALTER TABLE [CorePatterns].[Companies] DROP CONSTRAINT [Companies_Addresses_AddressId_FK];
GO
PRINT N'Dropping [CorePatterns].[Companies_Countries_CountryId_FK]...';


GO
IF OBJECT_ID('[CorePatterns].[Companies].[Companies_Countries_CountryId_FK]', 'C') IS NOT NULL
	ALTER TABLE [CorePatterns].[Companies] DROP CONSTRAINT [Companies_Countries_CountryId_FK];
GO
PRINT N'Dropping [CorePatterns].[Companies_Currencies_BaseCurrencyId_FK]...';


GO
IF OBJECT_ID('[CorePatterns].[Companies].[Companies_Currencies_BaseCurrencyId_FK]', 'C') IS NOT NULL
	ALTER TABLE [CorePatterns].[Companies] DROP CONSTRAINT [Companies_Currencies_BaseCurrencyId_FK];
GO
PRINT N'Dropping [Identity].[CompanyAccessRestrictions_Companies_BaseEntityId_FK]...';


GO
IF OBJECT_ID('[Identity].[CompanyAccessRestrictions].[CompanyAccessRestrictions_Companies_BaseEntityId_FK]', 'C') IS NOT NULL
	ALTER TABLE [Identity].[CompanyAccessRestrictions] DROP CONSTRAINT [CompanyAccessRestrictions_Companies_BaseEntityId_FK];
GO
PRINT N'Dropping [Reporting].[ReportModelDefinitionsCompanies_Company_CompanyId_FK]...';


GO
IF OBJECT_ID('[Reporting].[ReportModelDefinitionsCompanies].[ReportModelDefinitionsCompanies_Company_CompanyId_FK]', 'C') IS NOT NULL
	ALTER TABLE [Reporting].[ReportModelDefinitionsCompanies] DROP CONSTRAINT [ReportModelDefinitionsCompanies_Company_CompanyId_FK];
GO
PRINT N'Dropping [Identity].[GroupsUsers_Group_GroupId_FK]...';


GO
IF OBJECT_ID('[Identity].[GroupsUsers].[GroupsUsers_Group_GroupId_FK]', 'C') IS NOT NULL
	ALTER TABLE [Identity].[GroupsUsers] DROP CONSTRAINT [GroupsUsers_Group_GroupId_FK];
GO
PRINT N'Dropping [Identity].[RestrictedGroups_Groups_GroupId_FK]...';


GO
IF OBJECT_ID('[Identity].[RestrictedGroups].[RestrictedGroups_Groups_GroupId_FK]', 'C') IS NOT NULL
	ALTER TABLE [Identity].[RestrictedGroups] DROP CONSTRAINT [RestrictedGroups_Groups_GroupId_FK];
GO
PRINT N'Dropping [QueryBuilder].[ListModelColumns_ListModelAggregationOperations_AggregationOperationId_FK]...';


GO
IF OBJECT_ID('[QueryBuilder].[ListModelColumns].[ListModelColumns_ListModelAggregationOperations_AggregationOperationId_FK]', 'C') IS NOT NULL
	ALTER TABLE [QueryBuilder].[ListModelColumns] DROP CONSTRAINT [ListModelColumns_ListModelAggregationOperations_AggregationOperationId_FK];
GO
PRINT N'Dropping [QueryBuilder].[ListModelColumns_ListModelAggregationOperations_TotalOperationId_FK]...';


GO
IF OBJECT_ID('[QueryBuilder].[ListModelColumns].[ListModelColumns_ListModelAggregationOperations_TotalOperationId_FK]', 'C') IS NOT NULL
	ALTER TABLE [QueryBuilder].[ListModelColumns] DROP CONSTRAINT [ListModelColumns_ListModelAggregationOperations_TotalOperationId_FK];
GO
PRINT N'Dropping [QueryBuilder].[ListModelColumns_ListModelColumnStandardFormattings_StandardFormattingId_FK]...';


GO
IF OBJECT_ID('[QueryBuilder].[ListModelColumns].[ListModelColumns_ListModelColumnStandardFormattings_StandardFormattingId_FK]', 'C') IS NOT NULL
	ALTER TABLE [QueryBuilder].[ListModelColumns] DROP CONSTRAINT [ListModelColumns_ListModelColumnStandardFormattings_StandardFormattingId_FK];
GO
PRINT N'Dropping [QueryBuilder].[ListModelColumns_ListModelColumnStyles_StyleId_FK]...';


GO
IF OBJECT_ID('[QueryBuilder].[ListModelColumns].[ListModelColumns_ListModelColumnStyles_StyleId_FK]', 'C') IS NOT NULL
	ALTER TABLE [QueryBuilder].[ListModelColumns] DROP CONSTRAINT [ListModelColumns_ListModelColumnStyles_StyleId_FK];
GO
PRINT N'Dropping [QueryBuilder].[ListModelColumns_ListModels_ListModelId_FK]...';


GO
IF OBJECT_ID('[QueryBuilder].[ListModelColumns].[ListModelColumns_ListModels_ListModelId_FK]', 'C') IS NOT NULL
	ALTER TABLE [QueryBuilder].[ListModelColumns] DROP CONSTRAINT [ListModelColumns_ListModels_ListModelId_FK];
GO
PRINT N'Dropping [QueryBuilder].[ListModelColumns_SchemaAttributes_SchemaAttributeId_FK]...';


GO
IF OBJECT_ID('[QueryBuilder].[ListModelColumns].[ListModelColumns_SchemaAttributes_SchemaAttributeId_FK]', 'C') IS NOT NULL
	ALTER TABLE [QueryBuilder].[ListModelColumns] DROP CONSTRAINT [ListModelColumns_SchemaAttributes_SchemaAttributeId_FK];
GO
PRINT N'Dropping [CorePatterns].[BackgroundOperationDetails_BackgroundOperationDetailStatuses_BackgroundOperationDetailStatusId_FK]...';


GO
IF OBJECT_ID('[CorePatterns].[BackgroundOperationDetails].[BackgroundOperationDetails_BackgroundOperationDetailStatuses_BackgroundOperationDetailStatusId_FK]', 'C') IS NOT NULL
	ALTER TABLE [CorePatterns].[BackgroundOperationDetails] DROP CONSTRAINT [BackgroundOperationDetails_BackgroundOperationDetailStatuses_BackgroundOperationDetailStatusId_FK];
GO
PRINT N'Dropping [CorePatterns].[BackgroundOperationDetails_BackgroundOperations_BackgroundOperationId_FK]...';


GO
IF OBJECT_ID('[CorePatterns].[BackgroundOperationDetails].[BackgroundOperationDetails_BackgroundOperations_BackgroundOperationId_FK]', 'C') IS NOT NULL
	ALTER TABLE [CorePatterns].[BackgroundOperationDetails] DROP CONSTRAINT [BackgroundOperationDetails_BackgroundOperations_BackgroundOperationId_FK];
GO
PRINT N'Dropping [Reporting].[ReportModelDefinitions_Templates_TemplateId_FK]...';


GO
IF OBJECT_ID('[Reporting].[ReportModelDefinitions].[ReportModelDefinitions_Templates_TemplateId_FK]', 'C') IS NOT NULL
	ALTER TABLE [Reporting].[ReportModelDefinitions] DROP CONSTRAINT [ReportModelDefinitions_Templates_TemplateId_FK];
GO
PRINT N'Removing schema binding from [CorePatterns].[CompaniesIncludeDeletedView]...';
PRINT N'Dropping [Identity].[GroupUsers_CreatedBy_DF]...';


GO
IF OBJECT_ID('[Identity].[GroupUsers].[GroupUsers_CreatedBy_DF]', 'C') IS NOT NULL
	ALTER TABLE [Identity].[GroupUsers] DROP CONSTRAINT [GroupUsers_CreatedBy_DF];
GO
PRINT N'Dropping [Identity].[GroupUsers_Index_DF]...';


GO

IF OBJECT_ID('[Identity].[GroupUsers].[GroupUsers_Index_DF]', 'C') IS NOT NULL
	ALTER TABLE [Identity].[GroupUsers] DROP CONSTRAINT [GroupUsers_Index_DF];
GO
PRINT N'Dropping [Identity].[GroupUsers_IsSystem_DF]...';


GO

IF OBJECT_ID('[Identity].[GroupUsers].[GroupUsers_IsSystem_DF]', 'C') IS NOT NULL
	ALTER TABLE [Identity].[GroupUsers] DROP CONSTRAINT [GroupUsers_IsSystem_DF];
GO
PRINT N'Dropping [Identity].[GroupUsers_ModifiedOn_DF]...';


GO

IF OBJECT_ID('[Identity].[GroupUsers].[GroupUsers_ModifiedOn_DF]', 'C') IS NOT	NULL
	ALTER TABLE [Identity].[GroupUsers] DROP CONSTRAINT [GroupUsers_ModifiedOn_DF];
GO
PRINT N'Dropping [Identity].[GroupUsers_IsActive_DF]...';


GO
IF OBJECT_ID('[Identity].[GroupUsers].[GroupUsers_IsActive_DF]', 'C') IS NOT	NULL
	ALTER TABLE [Identity].[GroupUsers] DROP CONSTRAINT [GroupUsers_ModifiedOn_DF];
GO
PRINT N'Dropping [Identity].[GroupUsers_CreatedOn_DF]...';


GO

IF OBJECT_ID('[Identity].[GroupUsers].[GroupUsers_CreatedOn_DF]', 'C') IS NOT	NULL
	ALTER TABLE [Identity].[GroupUsers] DROP CONSTRAINT [GroupUsers_CreatedOn_DF];
GO
PRINT N'Dropping [Identity].[GroupUsers_ModifiedBy_DF]...';


GO

IF OBJECT_ID('[Identity].[GroupUsers].[GroupUsers_ModifiedBy_DF]', 'C') IS NOT	NULL
	ALTER TABLE [Identity].[GroupUsers] DROP CONSTRAINT [GroupUsers_ModifiedBy_DF];
GO
PRINT N'Dropping [Identity].[GroupUsers_Id_DF]...';


GO

IF OBJECT_ID('[Identity].[GroupUsers].[GroupUsers_Id_DF]', 'C') IS NOT	NULL
	ALTER TABLE [Identity].[GroupUsers] DROP CONSTRAINT [GroupUsers_Id_DF];
GO
PRINT N'Dropping [Identity].[GroupUsers_IsDeleted_DF]...';


GO

IF OBJECT_ID('[Identity].[GroupUsers].[GroupUsers_IsDeleted_DF]', 'C') IS NOT	NULL
	ALTER TABLE [Identity].[GroupUsers] DROP CONSTRAINT [GroupUsers_IsDeleted_DF];
GO
PRINT N'Dropping [Identity].[GroupUsers_Groups_GroupId_FK]...';


GO

IF OBJECT_ID('[Identity].[GroupUsers].[GroupUsers_Groups_GroupId_FK]', 'C') IS NOT	NULL
	ALTER TABLE [Identity].[GroupUsers] DROP CONSTRAINT [GroupUsers_Groups_GroupId_FK];
GO
PRINT N'Dropping [Identity].[GroupUsers_Users_UserId_FK]...';


GO
IF OBJECT_ID('[Identity].[GroupUsers].[GroupUsers_Users_UserId_FK]', 'C') IS NOT	NULL
	ALTER TABLE [Identity].[GroupUsers] DROP CONSTRAINT [GroupUsers_Users_UserId_FK];
GO
PRINT N'Dropping [Identity].[AccessGroupRecordsQuery]...';


GO
DROP FUNCTION IF EXISTS [Identity].[AccessGroupRecordsQuery];


GO
PRINT N'Dropping [Identity].[AccessGroups_AccessGroupsQuery]...';


GO
DROP FUNCTION IF EXISTS [Identity].[AccessGroups_AccessGroupsQuery];


GO
PRINT N'Dropping [Identity].[AccessGroupsQuery]...';


GO
DROP FUNCTION IF EXISTS [Identity].[AccessGroupsQuery];


GO
PRINT N'Dropping [Identity].[AccessGroupUsersQuery]...';


GO
DROP FUNCTION IF EXISTS [Identity].[AccessGroupUsersQuery];


GO
PRINT N'Dropping [Identity].[Verify_AuthorizableResource_AuthorizableResourcesForParentQuery]...';


GO
DROP FUNCTION IF EXISTS [Identity].[Verify_AuthorizableResource_AuthorizableResourcesForParentQuery];


GO
PRINT N'Dropping [Identity].[Verify_Authorization_AuthorizableResourcesForPermissionsAuthorizableResourceQuery]...';


GO
DROP FUNCTION IF EXISTS [Identity].[Verify_Authorization_AuthorizableResourcesForPermissionsAuthorizableResourceQuery];


GO
PRINT N'Dropping [Identity].[AuthorizationsQuery]...';


GO
DROP FUNCTION IF EXISTS [Identity].[AuthorizationsQuery];


GO
PRINT N'Dropping [Identity].[Verify_Group_GroupsForSubGroupsChildGroupQuery]...';


GO
DROP FUNCTION IF EXISTS [Identity].[Verify_Group_GroupsForSubGroupsChildGroupQuery];


GO
PRINT N'Dropping [Identity].[Verify_Group_RolesForRolesRoleQuery]...';


GO
DROP FUNCTION IF EXISTS [Identity].[Verify_Group_RolesForRolesRoleQuery];


GO
PRINT N'Dropping [Identity].[Verify_Group_UsersForUsersUserQuery]...';


GO
DROP FUNCTION IF EXISTS [Identity].[Verify_Group_UsersForUsersUserQuery];


GO
PRINT N'Dropping [Identity].[Verify_Role_GroupsForRoleGroupsGroupQuery]...';


GO
DROP FUNCTION IF EXISTS [Identity].[Verify_Role_GroupsForRoleGroupsGroupQuery];


GO
PRINT N'Dropping [Identity].[Verify_User_GroupsForGroupsGroupQuery]...';


GO
DROP FUNCTION IF EXISTS [Identity].[Verify_User_GroupsForGroupsGroupQuery];


GO
PRINT N'Dropping [SalesCore].[CUSTOMERPARTIES_CUSTOMERPARTIESQuery_RAFAEL.DUARTE@PRIMAVERABSS.COM]...';


GO
DROP FUNCTION IF EXISTS [SalesCore].[CUSTOMERPARTIES_CUSTOMERPARTIESQuery_RAFAEL.DUARTE@PRIMAVERABSS.COM];


GO
PRINT N'Dropping [Identity].[AuthorizableResource_AuthorizableResourcesForParentQuery]...';


GO
DROP FUNCTION IF EXISTS [Identity].[AuthorizableResource_AuthorizableResourcesForParentQuery];


GO
PRINT N'Dropping [Identity].[Authorization_AuthorizableResourcesForPermissionsAuthorizableResourceQuery]...';


GO
DROP FUNCTION IF EXISTS [Identity].[Authorization_AuthorizableResourcesForPermissionsAuthorizableResourceQuery];


GO
PRINT N'Dropping [Identity].[Group_GroupsForSubGroupsChildGroupQuery]...';


GO
DROP FUNCTION IF EXISTS [Identity].[Group_GroupsForSubGroupsChildGroupQuery];


GO
PRINT N'Dropping [Identity].[Group_RolesForRolesRoleQuery]...';


GO
DROP FUNCTION IF EXISTS [Identity].[Group_RolesForRolesRoleQuery];


GO
PRINT N'Dropping [Identity].[Group_UsersForUsersUserQuery]...';


GO
DROP FUNCTION IF EXISTS [Identity].[Group_UsersForUsersUserQuery];


GO
PRINT N'Dropping [Identity].[Role_GroupsForRoleGroupsGroupQuery]...';


GO
DROP FUNCTION IF EXISTS [Identity].[Role_GroupsForRoleGroupsGroupQuery];


GO
PRINT N'Dropping [Identity].[User_GroupsForGroupsGroupQuery]...';


GO
DROP FUNCTION IF EXISTS [Identity].[User_GroupsForGroupsGroupQuery];


GO
PRINT N'Dropping [Identity].[AuthorizableResourcesQuery]...';


GO
DROP FUNCTION IF EXISTS [Identity].[AuthorizableResourcesQuery];


GO
PRINT N'Dropping [Identity].[GroupUsersView]...';


GO
DROP VIEW IF EXISTS [Identity].[GroupUsersView];


GO
PRINT N'Dropping [Identity].[GroupUsers]...';


GO
DROP TABLE IF EXISTS [Identity].[GroupUsers];
GO

GO
DROP VIEW IF EXISTS [CorePatterns].[CompaniesIncludeDeletedView];
GO
IF NOT EXISTS(SELECT * FROM sys.views WHERE name = 'CompaniesIncludeDeletedView')
BEGIN  
	EXECUTE('CREATE VIEW [CorePatterns].[CompaniesIncludeDeletedView]
AS
SELECT E.[Id],
       E.[CompanyKey],
       E.[IsExternal],
       E.[ShowExchangeRateReversed],
       E.[Name],
       E.[SearchTerm],
       E.[CompanyTaxID],
       E.[Telephone],
       E.[TeleFax],
       E.[Mobile],
       E.[ElectronicMail],
       E.[EquityCapital],
       E.[RegistrationOffice],
       E.[RegistrationNumber],
       E.[CountryId],
       E.[BaseCurrencyId],
       E.[AddressId],
       E.[Logo],
       E.[LogoThumbnail],
       E.[CompanyRegistrationData],
       E.[AccessClaim],
       E.[NaturalKey],
       E.[IsDraft],
       E.[CreatedBy],
       E.[CreatedOn],
       E.[ModifiedBy],
       E.[ModifiedOn],
       E.[IsActive],
       E.[IsDeleted],
       E.[IsSystem],
       E.[Version]
FROM   [CorePatterns].[Companies] AS E;');
END

GO
PRINT N'Removing schema binding from [CorePatterns].[CompaniesView]...';
GO
DROP VIEW IF EXISTS [CorePatterns].[CompaniesView];
GO
IF NOT EXISTS(SELECT * FROM sys.views WHERE name = 'CompaniesView')
BEGIN  
	EXECUTE('CREATE VIEW [CorePatterns].[CompaniesView]
AS
SELECT E.[Id],
       E.[CompanyKey],
       E.[IsExternal],
       E.[ShowExchangeRateReversed],
       E.[Name],
       E.[SearchTerm],
       E.[CompanyTaxID],
       E.[Telephone],
       E.[TeleFax],
       E.[Mobile],
       E.[ElectronicMail],
       E.[EquityCapital],
       E.[RegistrationOffice],
       E.[RegistrationNumber],
       E.[CountryId],
       E.[BaseCurrencyId],
       E.[AddressId],
       E.[Logo],
       E.[LogoThumbnail],
       E.[CompanyRegistrationData],
       E.[AccessClaim],
       E.[NaturalKey],
       E.[IsDraft],
       E.[CreatedBy],
       E.[CreatedOn],
       E.[ModifiedBy],
       E.[ModifiedOn],
       E.[IsActive],
       E.[IsDeleted],
       E.[IsSystem],
       E.[Version]
FROM   [CorePatterns].[Companies] AS E
WHERE  E.[IsDeleted] = 0;');
END

GO
PRINT N'Removing schema binding from [CorePatterns].[CompanyResourcesView]...';
GO
DROP VIEW IF EXISTS [CorePatterns].[CompanyResourcesView];
GO
IF NOT EXISTS(SELECT * FROM sys.views WHERE name = 'CompanyResourcesView')
BEGIN  
	EXECUTE('CREATE VIEW [CorePatterns].[CompanyResourcesView]
AS
SELECT E.[Id],
       E.[CompanyKey],
       E.[IsExternal],
       E.[ShowExchangeRateReversed],
       E.[Name],
       E.[SearchTerm],
       E.[CompanyTaxID],
       E.[Telephone],
       E.[TeleFax],
       E.[Mobile],
       E.[ElectronicMail],
       E.[EquityCapital],
       E.[RegistrationOffice],
       E.[RegistrationNumber],
       T0.NaturalKey AS [Country],
       E.[CountryId],
       T0.[Name] AS [CountryDescription],
       T1.NaturalKey AS [BaseCurrency],
       E.[BaseCurrencyId],
       T1.[Description] AS [BaseCurrencyDescription],
       T2.NaturalKey AS [Address],
       E.[AddressId],
       E.[Logo],
       E.[LogoThumbnail],
       E.[CompanyRegistrationData],
       E.[AccessClaim],
       E.[NaturalKey],
       E.[IsDraft],
       E.[CreatedBy],
       E.[CreatedOn],
       E.[ModifiedBy],
       E.[ModifiedOn],
       E.[IsActive],
       E.[IsDeleted],
       E.[IsSystem],
       E.[Version]
FROM   [CorePatterns].[Companies] AS E
       LEFT OUTER JOIN
       [CorePatterns].[Countries] AS T0
       ON E.CountryId = T0.Id
       LEFT OUTER JOIN
       [CorePatterns].[Currencies] AS T1
       ON E.BaseCurrencyId = T1.Id
       LEFT OUTER JOIN
       [CorePatterns].[Addresses] AS T2
       ON E.AddressId = T2.Id
WHERE  E.[IsDeleted] = 0;');
END

GO
PRINT N'Removing schema binding from [Identity].[GroupsView]...';
GO
DROP VIEW IF EXISTS [Identity].[GroupsView];
GO
IF NOT EXISTS(SELECT * FROM sys.views WHERE name = 'GroupsView')
BEGIN  
	EXECUTE('CREATE VIEW [Identity].[GroupsView]
AS
SELECT E.[Id],
       E.[GroupKey],
       E.[Name],
       E.[Email],
       E.[Notes],
       E.[NaturalKey],
       E.[IsDraft],
       E.[CreatedBy],
       E.[CreatedOn],
       E.[ModifiedBy],
       E.[ModifiedOn],
       E.[IsActive],
       E.[IsDeleted],
       E.[IsSystem],
       E.[Version]
FROM   [Identity].[Groups] AS E
WHERE  E.[IsDeleted] = 0;');
END

GO
PRINT N'Dropping [Identity].[RestrictedGroupResourcesView]...';
GO
IF EXISTS(SELECT * FROM sys.views WHERE name = 'RestrictedGroupResourcesView')
BEGIN 
	DROP VIEW [Identity].[RestrictedGroupResourcesView];
END

GO

PRINT N'Removing schema binding from [QueryBuilder].[ListModelColumnsView]...';
GO
DROP VIEW IF EXISTS [QueryBuilder].[ListModelColumnsView];
GO
IF NOT EXISTS(SELECT * FROM sys.views WHERE name = 'ListModelColumnsView')
BEGIN  
	EXECUTE('CREATE VIEW [QueryBuilder].[ListModelColumnsView]
AS
SELECT E.[Id],
       E.[Name],
       E.[Description],
       E.[Sortable],
       E.[Groupable],
       E.[Searchable],
       E.[DisplayOrder],
       E.[PresentationDataType],
       E.[SchemaAttributeId],
       E.[GroupByDirection],
       E.[GroupByIndex],
       E.[OrderByDirection],
       E.[OrderByIndex],
       E.[Path],
       E.[IsMainDrillDown],
       E.[IsVisible],
       E.[Uri],
       E.[IsCustom],
       E.[CustomExpression],
       E.[IsLocalizable],
       E.[StyleId],
       E.[AggregationOperationId],
       E.[DisplayAggregationInFooter],
       E.[StandardFormattingId],
       E.[StandardFormattingColumn],
       E.[TotalOperationId],
       E.[IsCustomAttribute],
       E.[DecimalPlaces],
       E.[GroupHeaderTemplate],
       E.[ListModelId],
       E.[Index],
       E.[CreatedBy],
       E.[CreatedOn],
       E.[ModifiedBy],
       E.[ModifiedOn],
       E.[IsActive],
       E.[IsDeleted],
       E.[IsSystem],
       E.[Version]
FROM   [QueryBuilder].[ListModelColumns] AS E
WHERE  E.[IsDeleted] = 0;');
END

GO
PRINT N'Removing schema binding from [Reporting].[ReportModelDefinitionsView]...';
GO
DROP VIEW IF EXISTS [Reporting].[ReportModelDefinitionsView];
GO
IF NOT EXISTS(SELECT * FROM sys.views WHERE name = 'ReportModelDefinitionsView')
BEGIN  
	EXECUTE('CREATE VIEW [Reporting].[ReportModelDefinitionsView]
AS
SELECT E.[Id],
       E.[Name],
       E.[Description],
       E.[Model],
       E.[IsDefault],
       E.[AllowExtensions],
       E.[IsCustomReport],
       E.[DataSourceModel],
       E.[Configuration],
       E.[EntityId],
       E.[TemplateId],
       E.[NaturalKey],
       E.[IsDraft],
       E.[CreatedBy],
       E.[CreatedOn],
       E.[ModifiedBy],
       E.[ModifiedOn],
       E.[IsActive],
       E.[IsDeleted],
       E.[IsSystem],
       E.[Version]
FROM   [Reporting].[ReportModelDefinitions] AS E
WHERE  E.[IsDeleted] = 0;');
END

GO
PRINT N'Removing schema binding from [CorePatterns].[BackgroundOperationDetailResourcesView]...';
GO
DROP VIEW IF EXISTS [CorePatterns].[BackgroundOperationDetailResourcesView];
GO
IF NOT EXISTS(SELECT * FROM sys.views WHERE name = 'BackgroundOperationDetailResourcesView')
BEGIN  
	EXECUTE('CREATE VIEW [CorePatterns].[BackgroundOperationDetailResourcesView]
AS
SELECT E.[Id],
       E.[Description],
       T0.Value AS [BackgroundOperationDetailStatus],
       E.[BackgroundOperationDetailStatusId],
       T0.Description AS [BackgroundOperationDetailStatusDescription],
       E.[BackgroundOperationId],
       E.[Index],
       E.[CreatedBy],
       E.[CreatedOn],
       E.[ModifiedBy],
       E.[ModifiedOn],
       E.[IsActive],
       E.[IsDeleted],
       E.[IsSystem],
       E.[Version]
FROM   [CorePatterns].[BackgroundOperationDetails] AS E
       LEFT OUTER JOIN
       [CorePatterns].[BackgroundOperationDetailStatuses] AS T0
       ON E.BackgroundOperationDetailStatusId = T0.Id
WHERE  E.[IsDeleted] = 0;');
END

GO
PRINT N'Removing schema binding from [CorePatterns].[BackgroundOperationDetailsView]...';
GO
DROP VIEW IF EXISTS [CorePatterns].[BackgroundOperationDetailsView];
GO
IF NOT EXISTS(SELECT * FROM sys.views WHERE name = 'BackgroundOperationDetailsView')
BEGIN  
	EXECUTE('CREATE VIEW [CorePatterns].[BackgroundOperationDetailsView]
AS
SELECT E.[Id],
       E.[Description],
       E.[BackgroundOperationDetailStatusId],
       E.[BackgroundOperationId],
       E.[Index],
       E.[CreatedBy],
       E.[CreatedOn],
       E.[ModifiedBy],
       E.[ModifiedOn],
       E.[IsActive],
       E.[IsDeleted],
       E.[IsSystem],
       E.[Version]
FROM   [CorePatterns].[BackgroundOperationDetails] AS E
WHERE  E.[IsDeleted] = 0;');
END 

GO
PRINT N'Creating [Identity].[GroupUsers]...';


GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[Identity].[GroupUsers]') AND type in (N'U'))
BEGIN  
	EXECUTE('CREATE TABLE [Identity].[GroupUsers] (
    [Id]         UNIQUEIDENTIFIER   NOT NULL,
    [UserId]     UNIQUEIDENTIFIER   NOT NULL,
    [GroupId]    UNIQUEIDENTIFIER   NOT NULL,
    [Index]      INT                NOT NULL,
    [CreatedBy]  NVARCHAR (255)     NOT NULL,
    [CreatedOn]  DATETIMEOFFSET (7) NOT NULL,
    [ModifiedBy] NVARCHAR (255)     NOT NULL,
    [ModifiedOn] DATETIMEOFFSET (7) NOT NULL,
    [IsActive]   BIT                NOT NULL,
    [IsDeleted]  BIT                NOT NULL,
    [IsSystem]   BIT                NOT NULL,
    [Version]    ROWVERSION         NOT NULL,
    CONSTRAINT [GroupUsers_PK] PRIMARY KEY NONCLUSTERED ([Id] ASC)
);');
END

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[Identity].[Groups]') AND type in (N'U'))
	IF EXISTS(SELECT 1 FROM sys.columns 
          WHERE Name = N'[Address]'
          AND Object_ID = Object_ID(N'[Identity].[Groups]'))
	BEGIN
		ALTER TABLE [Identity].[Groups] DROP COLUMN [Address];
	END
	IF EXISTS(SELECT 1 FROM sys.columns 
          WHERE Name = N'[Phone]'
          AND Object_ID = Object_ID(N'[Identity].[Groups]'))
	BEGIN
		ALTER TABLE [Identity].[Groups] DROP COLUMN [Phone];
	END
	IF EXISTS(SELECT 1 FROM sys.columns 
          WHERE Name = N'[Fax]'
          AND Object_ID = Object_ID(N'[Identity].[Groups]'))
	BEGIN
		ALTER TABLE [Identity].[Groups] DROP COLUMN [Fax];
	END
GO
PRINT N'Creating [Identity].[GroupUsers].[GroupUsers_IDX1]...';

GO
IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = 'GroupUsers_IDX1' AND object_id = OBJECT_ID('[Identity].[GroupUsers]'))
	EXECUTE('CREATE CLUSTERED INDEX [GroupUsers_IDX1] ON [Identity].[GroupUsers]([GroupId] ASC, [Index] ASC);');
GO
PRINT N'Creating [Identity].[GroupUsers].[GroupUsers_IDXC1]...';


GO
IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = 'GroupUsers_IDXC1' AND object_id = OBJECT_ID('[Identity].[GroupUsers]'))
	EXECUTE('CREATE NONCLUSTERED INDEX [GroupUsers_IDXC1] ON [Identity].[GroupUsers]([UserId] ASC, [GroupId] ASC);');
GO
PRINT N'Creating [Identity].[GroupUsers_CreatedBy_DF]...';


GO
IF OBJECT_ID('[Identity].[GroupUsers].[GroupUsers_CreatedBy_DF]', 'C') IS NOT NULL
	ALTER TABLE [Identity].[GroupUsers] ADD CONSTRAINT [GroupUsers_CreatedBy_DF] DEFAULT ('<Sys>') FOR [CreatedBy];
GO
PRINT N'Creating [Identity].[GroupUsers_Index_DF]...';


GO
IF OBJECT_ID('[Identity].[GroupUsers].[GroupUsers_Index_DF]', 'C') IS NOT NULL
	ALTER TABLE [Identity].[GroupUsers] ADD CONSTRAINT [GroupUsers_Index_DF] DEFAULT ((0)) FOR [Index];
GO
PRINT N'Creating [Identity].[GroupUsers_IsSystem_DF]...';


GO
IF OBJECT_ID('[Identity].[GroupUsers].[GroupUsers_IsSystem_DF]', 'C') IS NOT NULL
	ALTER TABLE [Identity].[GroupUsers] ADD CONSTRAINT [GroupUsers_IsSystem_DF] DEFAULT ((0)) FOR [IsSystem];
GO
PRINT N'Creating [Identity].[GroupUsers_ModifiedOn_DF]...';


GO
IF OBJECT_ID('[Identity].[GroupUsers].[GroupUsers_ModifiedOn_DF]', 'C') IS NOT NULL
	ALTER TABLE [Identity].[GroupUsers] ADD CONSTRAINT [GroupUsers_ModifiedOn_DF] DEFAULT (sysdatetimeoffset()) FOR [ModifiedOn];
GO
PRINT N'Creating [Identity].[GroupUsers_IsActive_DF]...';


GO
IF OBJECT_ID('[Identity].[GroupUsers].[GroupUsers_IsActive_DF]', 'C') IS NOT NULL
	ALTER TABLE [Identity].[GroupUsers] ADD CONSTRAINT [GroupUsers_IsActive_DF] DEFAULT ((1)) FOR [IsActive];
GO
PRINT N'Creating [Identity].[GroupUsers_CreatedOn_DF]...';


GO
IF OBJECT_ID('[Identity].[GroupUsers].[GroupUsers_CreatedOn_DF]', 'C') IS NOT NULL
	ALTER TABLE [Identity].[GroupUsers] ADD CONSTRAINT [GroupUsers_CreatedOn_DF] DEFAULT (sysdatetimeoffset()) FOR [CreatedOn];
GO
PRINT N'Creating [Identity].[GroupUsers_ModifiedBy_DF]...';


GO
IF OBJECT_ID('[Identity].[GroupUsers].[GroupUsers_ModifiedBy_DF]', 'C') IS NOT NULL
	ALTER TABLE [Identity].[GroupUsers] ADD CONSTRAINT [GroupUsers_ModifiedBy_DF] DEFAULT ('<Sys>') FOR [ModifiedBy];
GO
PRINT N'Creating [Identity].[GroupUsers_Id_DF]...';


GO
IF OBJECT_ID('[Identity].[GroupUsers].[GroupUsers_Id_DF]', 'C') IS NOT NULL
	ALTER TABLE [Identity].[GroupUsers] ADD CONSTRAINT [GroupUsers_Id_DF] DEFAULT (newsequentialid()) FOR [Id];
GO
PRINT N'Creating [Identity].[GroupUsers_IsDeleted_DF]...';


GO
IF OBJECT_ID('[Identity].[GroupUsers].[GroupUsers_IsDeleted_DF]', 'C') IS NOT NULL
	ALTER TABLE [Identity].[GroupUsers] ADD CONSTRAINT [GroupUsers_IsDeleted_DF] DEFAULT ((0)) FOR [IsDeleted];
GO
PRINT N'Creating [CorePatterns].[Companies_Addresses_AddressId_FK]...';


GO
IF OBJECT_ID('[CorePatterns].[Companies].[Companies_Addresses_AddressId_FK]', 'C') IS NOT NULL
	ALTER TABLE [CorePatterns].[Companies] WITH NOCHECK ADD CONSTRAINT [Companies_Addresses_AddressId_FK] FOREIGN KEY ([AddressId]) REFERENCES [CorePatterns].[Addresses] ([Id]);
GO
PRINT N'Creating [CorePatterns].[Companies_Countries_CountryId_FK]...';


GO
IF OBJECT_ID('[CorePatterns].[Companies].[Companies_Countries_CountryId_FK]', 'C') IS NOT NULL
	ALTER TABLE [CorePatterns].[Companies] WITH NOCHECK ADD CONSTRAINT [Companies_Countries_CountryId_FK] FOREIGN KEY ([CountryId]) REFERENCES [CorePatterns].[Countries] ([Id]);
GO
PRINT N'Creating [CorePatterns].[Companies_Currencies_BaseCurrencyId_FK]...';


GO
IF OBJECT_ID('[CorePatterns].[Companies].[Companies_Currencies_BaseCurrencyId_FK]', 'C') IS NOT NULL
	ALTER TABLE [CorePatterns].[Companies] WITH NOCHECK ADD CONSTRAINT [Companies_Currencies_BaseCurrencyId_FK] FOREIGN KEY ([BaseCurrencyId]) REFERENCES [CorePatterns].[Currencies] ([Id]);
GO
PRINT N'Creating [Identity].[CompanyAccessRestrictions_Companies_BaseEntityId_FK]...';


GO
IF OBJECT_ID('[Identity].[CompanyAccessRestrictions].[CompanyAccessRestrictions_Companies_BaseEntityId_FK]', 'C') IS NOT NULL
	ALTER TABLE [Identity].[CompanyAccessRestrictions] WITH NOCHECK ADD CONSTRAINT [CompanyAccessRestrictions_Companies_BaseEntityId_FK] FOREIGN KEY ([BaseEntityId]) REFERENCES [CorePatterns].[Companies] ([Id]);
GO
PRINT N'Creating [Reporting].[ReportModelDefinitionsCompanies_Company_CompanyId_FK]...';


GO
IF OBJECT_ID('[Reporting].[ReportModelDefinitionsCompanies].[ReportModelDefinitionsCompanies_Company_CompanyId_FK]', 'C') IS NOT NULL
	ALTER TABLE [Reporting].[ReportModelDefinitionsCompanies] WITH NOCHECK ADD CONSTRAINT [ReportModelDefinitionsCompanies_Company_CompanyId_FK] FOREIGN KEY ([CompanyId]) REFERENCES [CorePatterns].[Companies] ([Id]) ON DELETE CASCADE;
GO
PRINT N'Creating [Identity].[GroupsUsers_Group_GroupId_FK]...';


GO
IF OBJECT_ID('[CorePatterns].[Companies].[GroupsUsers_Group_GroupId_FK]', 'C') IS NOT NULL
	ALTER TABLE [CorePatterns].[Companies] WITH NOCHECK ADD CONSTRAINT [GroupsUsers_Group_GroupId_FK] FOREIGN KEY ([GroupId]) REFERENCES [Identity].[Groups] ([Id]) ON DELETE CASCADE;
GO
PRINT N'Creating [Identity].[RestrictedGroups_Groups_GroupId_FK]...';


GO
IF OBJECT_ID('[Identity].[RestrictedGroups].[RestrictedGroups_Groups_GroupId_FK]', 'C') IS NOT NULL
	ALTER TABLE [Identity].[RestrictedGroups] WITH NOCHECK ADD CONSTRAINT [RestrictedGroups_Groups_GroupId_FK] FOREIGN KEY ([GroupId]) REFERENCES [Identity].[Groups] ([Id]);
GO
PRINT N'Creating [QueryBuilder].[ListModelColumns_ListModelAggregationOperations_AggregationOperationId_FK]...';


GO
IF OBJECT_ID('[QueryBuilder].[ListModelColumns].[ListModelColumns_ListModelAggregationOperations_AggregationOperationId_FK]', 'C') IS NOT NULL
	ALTER TABLE [QueryBuilder].[ListModelColumns] WITH NOCHECK ADD CONSTRAINT [ListModelColumns_ListModelAggregationOperations_AggregationOperationId_FK] FOREIGN KEY ([AggregationOperationId]) REFERENCES [QueryBuilder].[ListModelAggregationOperations] ([Id]);
GO
PRINT N'Creating [QueryBuilder].[ListModelColumns_ListModelAggregationOperations_TotalOperationId_FK]...';


GO
IF OBJECT_ID('[QueryBuilder].[ListModelColumns].[ListModelColumns_ListModelAggregationOperations_TotalOperationId_FK]', 'C') IS NOT NULL
	ALTER TABLE [QueryBuilder].[ListModelColumns] WITH NOCHECK ADD CONSTRAINT [ListModelColumns_ListModelAggregationOperations_TotalOperationId_FK] FOREIGN KEY ([TotalOperationId]) REFERENCES [QueryBuilder].[ListModelAggregationOperations] ([Id]);
GO
PRINT N'Creating [QueryBuilder].[ListModelColumns_ListModelColumnStandardFormattings_StandardFormattingId_FK]...';


GO
IF OBJECT_ID('[QueryBuilder].[ListModelColumns].[ListModelColumns_ListModelColumnStandardFormattings_StandardFormattingId_FK]', 'C') IS NOT NULL
	ALTER TABLE [QueryBuilder].[ListModelColumns] WITH NOCHECK ADD CONSTRAINT [ListModelColumns_ListModelColumnStandardFormattings_StandardFormattingId_FK] FOREIGN KEY ([StandardFormattingId]) REFERENCES [QueryBuilder].[ListModelColumnStandardFormattings] ([Id]);
GO
PRINT N'Creating [QueryBuilder].[ListModelColumns_ListModelColumnStyles_StyleId_FK]...';


GO
IF OBJECT_ID('[QueryBuilder].[ListModelColumns].[ListModelColumns_ListModelColumnStyles_StyleId_FK]', 'C') IS NOT NULL
	ALTER TABLE [QueryBuilder].[ListModelColumns] WITH NOCHECK ADD CONSTRAINT [ListModelColumns_ListModelColumnStyles_StyleId_FK] FOREIGN KEY ([StyleId]) REFERENCES [QueryBuilder].[ListModelColumnStyles] ([Id]);
GO
PRINT N'Creating [QueryBuilder].[ListModelColumns_ListModels_ListModelId_FK]...';


GO
IF OBJECT_ID('[QueryBuilder].[ListModelColumns].[ListModelColumns_ListModels_ListModelId_FK]', 'C') IS NOT NULL
	ALTER TABLE [QueryBuilder].[ListModelColumns] WITH NOCHECK ADD CONSTRAINT [ListModelColumns_ListModels_ListModelId_FK] FOREIGN KEY ([ListModelId]) REFERENCES [QueryBuilder].[ListModels] ([Id]) ON DELETE CASCADE;
GO
PRINT N'Creating [QueryBuilder].[ListModelColumns_SchemaAttributes_SchemaAttributeId_FK]...';


GO
IF OBJECT_ID('[QueryBuilder].[ListModelColumns].[ListModelColumns_SchemaAttributes_SchemaAttributeId_FK]', 'C') IS NOT NULL
	ALTER TABLE [QueryBuilder].[ListModelColumns] WITH NOCHECK ADD CONSTRAINT [ListModelColumns_SchemaAttributes_SchemaAttributeId_FK] FOREIGN KEY ([SchemaAttributeId]) REFERENCES [CorePatterns].[SchemaAttributes] ([Id]);
GO
PRINT N'Creating [CorePatterns].[BackgroundOperationDetails_BackgroundOperationDetailStatuses_BackgroundOperationDetailStatusId_FK]...';


GO
IF OBJECT_ID('[CorePatterns].[BackgroundOperationDetails].[BackgroundOperationDetails_BackgroundOperationDetailStatuses_BackgroundOperationDetailStatusId_FK]', 'C') IS NOT NULL
	ALTER TABLE [CorePatterns].[BackgroundOperationDetails] WITH NOCHECK ADD CONSTRAINT [BackgroundOperationDetails_BackgroundOperationDetailStatuses_BackgroundOperationDetailStatusId_FK] FOREIGN KEY ([BackgroundOperationDetailStatusId]) REFERENCES [CorePatterns].[BackgroundOperationDetailStatuses] ([Id]);
GO
PRINT N'Creating [CorePatterns].[BackgroundOperationDetails_BackgroundOperations_BackgroundOperationId_FK]...';


GO
IF OBJECT_ID('[CorePatterns].[BackgroundOperationDetails].[BackgroundOperationDetails_BackgroundOperations_BackgroundOperationId_FK]', 'C') IS NOT NULL
	ALTER TABLE [CorePatterns].[BackgroundOperationDetails] WITH NOCHECK ADD CONSTRAINT [BackgroundOperationDetails_BackgroundOperations_BackgroundOperationId_FK] FOREIGN KEY ([BackgroundOperationId]) REFERENCES [CorePatterns].[BackgroundOperations] ([Id]) ON DELETE CASCADE;
GO
PRINT N'Creating [Identity].[GroupUsers_Groups_GroupId_FK]...';


GO
IF OBJECT_ID('[Identity].[GroupUsers].[GroupUsers_Groups_GroupId_FK]', 'C') IS NOT NULL
	ALTER TABLE [Identity].[GroupUsers] WITH NOCHECK ADD CONSTRAINT [GroupUsers_Groups_GroupId_FK] FOREIGN KEY ([GroupId]) REFERENCES [Identity].[Groups] ([Id]) ON DELETE CASCADE;
GO
PRINT N'Creating [Identity].[GroupUsers_Users_UserId_FK]...';


GO
IF OBJECT_ID('[Identity].[GroupUsers].[GroupUsers_Users_UserId_FK]', 'C') IS NOT NULL
	ALTER TABLE [Identity].[GroupUsers] WITH NOCHECK ADD CONSTRAINT [GroupUsers_Users_UserId_FK] FOREIGN KEY ([UserId]) REFERENCES [Identity].[Users] ([Id]);
GO

PRINT N'Adding schema binding to [CorePatterns].[CompaniesIncludeDeletedView]...';

GO

DROP VIEW IF EXISTS [CorePatterns].[CompaniesIncludeDeletedView]
GO

CREATE VIEW [CorePatterns].[CompaniesIncludeDeletedView]
WITH SCHEMABINDING AS
SELECT
    E.[Id]
    , E.[CompanyKey]
	, E.[IsExternal]
	, E.[ShowExchangeRateReversed]
	, E.[Name]
	, E.[SearchTerm]
	, E.[CompanyTaxID]
	, E.[Telephone]
	, E.[TeleFax]
	, E.[Mobile]
	, E.[ElectronicMail]
	, E.[EquityCapital]
	, E.[RegistrationOffice]
	, E.[RegistrationNumber]
	, E.[CountryId]
	, E.[BaseCurrencyId]
	, E.[AddressId]
	, E.[Logo]
	, E.[LogoThumbnail]
	, E.[CompanyRegistrationData]
	, E.[AccessClaim]
	, E.[NaturalKey]
	, E.[IsDraft]
	, E.[CreatedBy]
	, E.[CreatedOn]
	, E.[ModifiedBy]
	, E.[ModifiedOn]
	, E.[IsActive]
	, E.[IsDeleted]
	, E.[IsSystem]
	, E.[Version]
FROM [CorePatterns].[Companies] E
GO
PRINT N'Adding schema binding to [CorePatterns].[CompaniesView]...';


GO
DROP VIEW IF EXISTS [CorePatterns].[CompaniesView]
GO
CREATE VIEW [CorePatterns].[CompaniesView]
WITH SCHEMABINDING AS
SELECT
    E.[Id]
    , E.[CompanyKey]
	, E.[IsExternal]
	, E.[ShowExchangeRateReversed]
	, E.[Name]
	, E.[SearchTerm]
	, E.[CompanyTaxID]
	, E.[Telephone]
	, E.[TeleFax]
	, E.[Mobile]
	, E.[ElectronicMail]
	, E.[EquityCapital]
	, E.[RegistrationOffice]
	, E.[RegistrationNumber]
	, E.[CountryId]
	, E.[BaseCurrencyId]
	, E.[AddressId]
	, E.[Logo]
	, E.[LogoThumbnail]
	, E.[CompanyRegistrationData]
	, E.[AccessClaim]
	, E.[NaturalKey]
	, E.[IsDraft]
	, E.[CreatedBy]
	, E.[CreatedOn]
	, E.[ModifiedBy]
	, E.[ModifiedOn]
	, E.[IsActive]
	, E.[IsDeleted]
	, E.[IsSystem]
	, E.[Version]
FROM [CorePatterns].[Companies] E
WHERE E.[IsDeleted] = 0
GO
PRINT N'Adding schema binding to [CorePatterns].[CompanyResourcesView]...';


GO
DROP VIEW IF EXISTS [CorePatterns].[CompanyResourcesView]
GO
CREATE VIEW [CorePatterns].[CompanyResourcesView] 
WITH SCHEMABINDING AS
SELECT
    E.[Id]
    , E.[CompanyKey]
    , E.[IsExternal]
    , E.[ShowExchangeRateReversed]
    , E.[Name]
    , E.[SearchTerm]
    , E.[CompanyTaxID]
    , E.[Telephone]
    , E.[TeleFax]
    , E.[Mobile]
    , E.[ElectronicMail]
    , E.[EquityCapital]
    , E.[RegistrationOffice]
    , E.[RegistrationNumber]
	, T0.NaturalKey as [Country]
    , E.[CountryId]
	, T0.[Name] as [CountryDescription]
	, T1.NaturalKey as [BaseCurrency]
    , E.[BaseCurrencyId]
	, T1.[Description] as [BaseCurrencyDescription]
	, T2.NaturalKey as [Address]
    , E.[AddressId]
    , E.[Logo]
    , E.[LogoThumbnail]
    , E.[CompanyRegistrationData]
	, E.[AccessClaim]
    , E.[NaturalKey]
    , E.[IsDraft]
    , E.[CreatedBy]
    , E.[CreatedOn]
    , E.[ModifiedBy]
    , E.[ModifiedOn]
    , E.[IsActive] 
    , E.[IsDeleted]
    , E.[IsSystem]
    , E.[Version]
FROM [CorePatterns].[Companies] E
		left join [CorePatterns].[Countries] T0 on E.CountryId = T0.Id
		left join [CorePatterns].[Currencies] T1 on E.BaseCurrencyId = T1.Id
		left join [CorePatterns].[Addresses] T2 on E.AddressId = T2.Id
WHERE E.[IsDeleted] = 0
GO
PRINT N'Adding schema binding to [Identity].[GroupsView]...';


DROP VIEW IF EXISTS [Identity].[GroupsView]
GO
CREATE VIEW [Identity].[GroupsView]
WITH SCHEMABINDING AS
SELECT
    E.[Id]
    , E.[GroupKey]
	, E.[Name]
	, E.[Email]
	, E.[Notes]
	, E.[NaturalKey]
	, E.[IsDraft]
	, E.[CreatedBy]
	, E.[CreatedOn]
	, E.[ModifiedBy]
	, E.[ModifiedOn]
	, E.[IsActive]
	, E.[IsDeleted]
	, E.[IsSystem]
	, E.[Version]
FROM [Identity].[Groups] E
WHERE E.[IsDeleted] = 0
GO
PRINT N'Adding schema binding to [QueryBuilder].[ListModelColumnsView]...';


GO

DROP VIEW IF EXISTS [QueryBuilder].[ListModelColumnsView]
GO
CREATE VIEW [QueryBuilder].[ListModelColumnsView]
WITH SCHEMABINDING AS
SELECT
    E.[Id]
    , E.[Name]
	, E.[Description]
	, E.[Sortable]
	, E.[Groupable]
	, E.[Searchable]
	, E.[DisplayOrder]
	, E.[PresentationDataType]
	, E.[SchemaAttributeId]
	, E.[GroupByDirection]
	, E.[GroupByIndex]
	, E.[OrderByDirection]
	, E.[OrderByIndex]
	, E.[Path]
	, E.[IsMainDrillDown]
	, E.[IsVisible]
	, E.[Uri]
	, E.[IsCustom]
	, E.[CustomExpression]
	, E.[IsLocalizable]
	, E.[StyleId]
	, E.[AggregationOperationId]
	, E.[DisplayAggregationInFooter]
	, E.[StandardFormattingId]
	, E.[StandardFormattingColumn]
	, E.[TotalOperationId]
	, E.[IsCustomAttribute]
	, E.[DecimalPlaces]
	, E.[GroupHeaderTemplate]
	, E.[ListModelId]
	, E.[Index]
	, E.[CreatedBy]
	, E.[CreatedOn]
	, E.[ModifiedBy]
	, E.[ModifiedOn]
	, E.[IsActive]
	, E.[IsDeleted]
	, E.[IsSystem]
	, E.[Version]
FROM [QueryBuilder].[ListModelColumns] E
WHERE E.[IsDeleted] = 0
GO
PRINT N'Adding schema binding to [Reporting].[ReportModelDefinitionsView]...';


GO
DROP VIEW IF EXISTS [Reporting].[ReportModelDefinitionsView]
GO
CREATE VIEW [Reporting].[ReportModelDefinitionsView]
WITH SCHEMABINDING AS
SELECT
    E.[Id]
    , E.[Name]
	, E.[Description]
	, E.[Model]
	, E.[IsDefault]
	, E.[AllowExtensions]
	, E.[IsCustomReport]
	, E.[DataSourceModel]
	, E.[Configuration]
	, E.[EntityId]
	, E.[TemplateId]
	, E.[NaturalKey]
	, E.[IsDraft]
	, E.[CreatedBy]
	, E.[CreatedOn]
	, E.[ModifiedBy]
	, E.[ModifiedOn]
	, E.[IsActive]
	, E.[IsDeleted]
	, E.[IsSystem]
	, E.[Version]
FROM [Reporting].[ReportModelDefinitions] E
WHERE E.[IsDeleted] = 0
GO
PRINT N'Altering [CorePatterns].[CustomEntityResourcesView]...';


GO
DROP VIEW IF EXISTS [CorePatterns].[CustomEntityResourcesView] 
GO
CREATE VIEW [CorePatterns].[CustomEntityResourcesView] 
WITH SCHEMABINDING AS
SELECT
    E.[Id]
    , E.[Key]
    , E.[Title]
    , E.[Remarks]
	, E.[AllowExtensibility]
    , E.[ModuleName]
    , E.[NaturalKey]
    , E.[IsDraft]
    , E.[CreatedBy]
    , E.[CreatedOn]
    , E.[ModifiedBy]
    , E.[ModifiedOn]
    , E.[IsActive] 
    , E.[IsDeleted]
    , E.[IsSystem]
    , E.[Version]
FROM [CorePatterns].[SchemaEntities] E
WHERE E.[IsDeleted] = 0
GO
PRINT N'Adding schema binding to [CorePatterns].[BackgroundOperationDetailResourcesView]...';


GO
IF EXISTS(SELECT * FROM sys.views WHERE name = 'BackgroundOperationDetailResourcesView')
BEGIN 
	DROP VIEW [CorePatterns].[BackgroundOperationDetailResourcesView];
END

GO
IF NOT EXISTS(SELECT * FROM sys.views WHERE name = 'BackgroundOperationDetailResourcesView')
BEGIN  
	EXECUTE('CREATE VIEW [CorePatterns].[BackgroundOperationDetailResourcesView] 
WITH SCHEMABINDING AS
SELECT
    E.[Id]
    , E.[Description]
	, T0.Value as [BackgroundOperationDetailStatus]
    , E.[BackgroundOperationDetailStatusId]
	, T0.Description as [BackgroundOperationDetailStatusDescription]
    , E.[BackgroundOperationId]
	, E.[Index]
    , E.[CreatedBy]
    , E.[CreatedOn]
    , E.[ModifiedBy]
    , E.[ModifiedOn]
    , E.[IsActive] 
    , E.[IsDeleted]
    , E.[IsSystem]
    , E.[Version]
FROM [CorePatterns].[BackgroundOperationDetails] E
		left join [CorePatterns].[BackgroundOperationDetailStatuses] T0 on E.BackgroundOperationDetailStatusId = T0.Id
WHERE E.[IsDeleted] = 0;');
END
GO
PRINT N'Adding schema binding to [CorePatterns].[BackgroundOperationDetailsView]...';

GO

DROP VIEW IF EXISTS [CorePatterns].[BackgroundOperationDetailsView]
GO
CREATE VIEW [CorePatterns].[BackgroundOperationDetailsView]
WITH SCHEMABINDING AS
SELECT
    E.[Id]
    , E.[Description]
	, E.[BackgroundOperationDetailStatusId]
	, E.[BackgroundOperationId]
	, E.[Index]
	, E.[CreatedBy]
	, E.[CreatedOn]
	, E.[ModifiedBy]
	, E.[ModifiedOn]
	, E.[IsActive]
	, E.[IsDeleted]
	, E.[IsSystem]
	, E.[Version]
FROM [CorePatterns].[BackgroundOperationDetails] E
WHERE E.[IsDeleted] = 0
GO
PRINT N'Creating [Identity].[GroupUsersView]...';
GO
DROP VIEW IF EXISTS [Identity].[GroupUsersView]
GO
CREATE VIEW [Identity].[GroupUsersView]
WITH SCHEMABINDING AS
SELECT
    E.[Id]
    , E.[UserId]
	, E.[GroupId]
	, E.[Index]
	, E.[CreatedBy]
	, E.[CreatedOn]
	, E.[ModifiedBy]
	, E.[ModifiedOn]
	, E.[IsActive]
	, E.[IsDeleted]
	, E.[IsSystem]
	, E.[Version]
FROM [Identity].[GroupUsers] E
WHERE E.[IsDeleted] = 0
GO
EXECUTE sp_refreshsqlmodule N'[Identity].[GroupsQuery]';
GO
DROP VIEW IF EXISTS [Identity].[BaseCompanyAccessRestrictionResourcesView]
GO
CREATE VIEW [Identity].[BaseCompanyAccessRestrictionResourcesView] 
WITH SCHEMABINDING AS
SELECT
    E.[Id]
    , EBase.[CompanyKey]
    , EBase.[IsExternal]
    , EBase.[ShowExchangeRateReversed]
    , EBase.[Name]
    , EBase.[SearchTerm]
    , EBase.[CompanyTaxID]
    , EBase.[Telephone]
    , EBase.[TeleFax]
    , EBase.[Mobile]
    , EBase.[ElectronicMail]
    , EBase.[EquityCapital]
    , EBase.[RegistrationOffice]
    , EBase.[RegistrationNumber]
	, T0.NaturalKey as [Country]
    , EBase.[CountryId]
	, T0.[Name] as [CountryDescription]
	, T1.NaturalKey as [BaseCurrency]
    , EBase.[BaseCurrencyId]
	, T1.[Description] as [BaseCurrencyDescription]
	, T2.NaturalKey as [Address]
    , EBase.[AddressId]
    , EBase.[Logo]
    , EBase.[LogoThumbnail]
    , EBase.[CompanyRegistrationData]
	, E.BaseEntityId
    , EBase.[NaturalKey]
    , E.[IsDraft]
    , E.[CreatedBy]
    , E.[CreatedOn]
    , E.[ModifiedBy]
    , E.[ModifiedOn]
    , E.[IsActive] 
    , E.[IsDeleted]
    , E.[IsSystem]
    , E.[Version]
FROM [Identity].[CompanyAccessRestrictions] E
		left join [CorePatterns].[Companies] EBase on E.BaseEntityId = EBase.Id
		left join [CorePatterns].[Countries] T0 on EBase.CountryId = T0.Id
		left join [CorePatterns].[Currencies] T1 on EBase.BaseCurrencyId = T1.Id
		left join [CorePatterns].[Addresses] T2 on EBase.AddressId = T2.Id
WHERE E.[IsDeleted] = 0
GO
DROP VIEW IF EXISTS [Identity].[BaseCompanyAccessRestrictionRestrictedGroupsResourcesView] 
GO
CREATE VIEW [Identity].[BaseCompanyAccessRestrictionRestrictedGroupsResourcesView] 
WITH SCHEMABINDING AS
SELECT
    E.[Id]
	, T0.NaturalKey as [Group]
    , E.[GroupId]
	, T0.[Name] as [GroupDescription]
    , E.[CompanyAccessRestrictionId]
	, E.[Index]
    , E.[CreatedBy]
    , E.[CreatedOn]
    , E.[ModifiedBy]
    , E.[ModifiedOn]
    , E.[IsActive] 
    , E.[IsDeleted]
    , E.[IsSystem]
    , E.[Version]
FROM [Identity].[RestrictedGroups] E
		left join [Identity].[Groups] T0 on E.GroupId = T0.Id
WHERE E.[IsDeleted] = 0
GO
DROP VIEW IF EXISTS [Identity].[CompanyAccessRestrictionResourcesView] 
GO
CREATE VIEW [Identity].[CompanyAccessRestrictionResourcesView] 
WITH SCHEMABINDING AS
SELECT
    E.[Id]
    , EBase.[CompanyKey]
	, E.BaseEntityId
    , EBase.[NaturalKey]
    , E.[IsDraft]
    , E.[CreatedBy]
    , E.[CreatedOn]
    , E.[ModifiedBy]
    , E.[ModifiedOn]
    , E.[IsActive] 
    , E.[IsDeleted]
    , E.[IsSystem]
    , E.[Version]
FROM [Identity].[CompanyAccessRestrictions] E
		left join [CorePatterns].[Companies] EBase on E.BaseEntityId = EBase.Id
WHERE E.[IsDeleted] = 0
GO
DROP VIEW IF EXISTS [Identity].[GroupResourcesView] 
GO
CREATE VIEW [Identity].[GroupResourcesView] 
WITH SCHEMABINDING AS
SELECT
    E.[Id]
    , E.[GroupKey]
    , E.[Name]
    , E.[Email]
    , E.[Notes]
    , E.[NaturalKey]
    , E.[IsDraft]
    , E.[CreatedBy]
    , E.[CreatedOn]
    , E.[ModifiedBy]
    , E.[ModifiedOn]
    , E.[IsActive] 
    , E.[IsDeleted]
    , E.[IsSystem]
    , E.[Version]
FROM [Identity].[Groups] E
WHERE E.[IsDeleted] = 0
GO
DROP VIEW IF EXISTS [Identity].[RestrictedGroupResourcesView]
GO
CREATE VIEW [Identity].[RestrictedGroupResourcesView] 
WITH SCHEMABINDING AS
SELECT
    E.[Id]
	, T0.NaturalKey as [Group]
    , E.[GroupId]
	, T0.[Name] as [GroupDescription]
    , E.[CompanyAccessRestrictionId]
	, E.[Index]
    , E.[CreatedBy]
    , E.[CreatedOn]
    , E.[ModifiedBy]
    , E.[ModifiedOn]
    , E.[IsActive] 
    , E.[IsDeleted]
    , E.[IsSystem]
    , E.[Version]
FROM [Identity].[RestrictedGroups] E
		left join [Identity].[Groups] T0 on E.GroupId = T0.Id
WHERE E.[IsDeleted] = 0
GO
DROP FUNCTION IF EXISTS [Reporting].[Templates_TemplatesQuery]
GO
CREATE FUNCTION  [Reporting].[Templates_TemplatesQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM (SELECT [SRC].[Id], [SRC].[Source_NaturalKey], [SRC].[TemplateKey], [SRC].[Description], [SRC].[ReportTypeId], [SRC].[ReportTypeValue], [SRC].[ReportType], [SRC].[CopiedFrom], (SELECT CASE WHEN EXISTS (
SELECT TOP 1 *
FROM [Reporting].[GroupTemplates] [GT] 
INNER JOIN [Reporting].[Templates] [T] ON [GT].TemplateId=[T].Id 
WHERE 
[T].TemplateKey=[SRC].TemplateKey AND 
[GT].IsDefaultForGroupEntities=1
)
THEN CAST(1 AS BIT)
ELSE CAST(0 AS BIT) END) AS [IsGroupDefault], (SELECT CASE WHEN EXISTS (SELECT TOP 1 * FROM [Reporting].[ReportModelDefinitions] [RMD] WHERE cast(Model as xml) .value('(/ReportModel/@Template)[1]', 'nvarchar(max)' )=[SRC].TemplateKey) AND NOT EXISTS (SELECT TOP 1 * FROM Reporting.Templates WHERE CopiedFrom=[SRC].TemplateKey) THEN CAST(1 AS BIT) ELSE CAST(0 AS BIT) END) AS [IsSpecificTemplate], (SELECT CASE WHEN EXISTS (SELECT TOP 1 * FROM [Reporting].[ReportModelDefinitions] [RMD] WHERE cast(Model as xml) .value('(/ReportModel/@Template)[1]', 'nvarchar(max)' )=[SRC].CopiedFrom) THEN CAST(1 AS BIT) ELSE CAST(0 AS BIT) END) AS [IsCopyOfSpecificTemplate]
FROM (SELECT [T0].[Id] AS [Id], [T0].[NaturalKey] AS [Source_NaturalKey], [T0].[TemplateKey] AS [TemplateKey], [T0].[Description] AS [Description], [T1].[Id] AS [ReportTypeId], [T1].[Value] AS [ReportTypeValue], [CorePatterns].[GetLocalizedValue]([T1].[Description], @culture) AS [ReportType], [T0].[CopiedFrom] AS [CopiedFrom]
FROM [Reporting].[TemplatesView] [T0]
LEFT JOIN [Reporting].[ReportTypesView] [T1] ON [T0].[ReportTypeId] = [T1].[Id]
WHERE (ISNULL([T0].[TemplateKey] COLLATE Latin1_general_CI_AI, '') LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR ISNULL([T0].[Description] COLLATE Latin1_general_CI_AI, '') LIKE @searchTerm COLLATE Latin1_general_CI_AI)) [SRC]) [FILTERSRC]
WHERE [FILTERSRC].TemplateKey<>'Default')
GO
PRINT N'Refreshing [Reporting].[ReportModelDefinitionsQuery]...';


GO
EXECUTE sp_refreshsqlmodule N'[Reporting].[ReportModelDefinitionsQuery]';
GO
DROP FUNCTION IF EXISTS [Identity].[Group_GroupsForSubGroupsChildGroupQuery]
GO
CREATE FUNCTION  [Identity].[Group_GroupsForSubGroupsChildGroupQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[NaturalKey], [T1].[Name]
FROM [Identity].GroupsQuery(@searchTerm, @user, @culture) [T1]
JOIN [Identity].[GroupsView] [T] ON [T1].[Id] = [T].[Id]
WHERE [T].[IsActive] = 1)
GO
PRINT N'Creating [Identity].[Group_RolesForRolesRoleQuery]...';


GO
DROP FUNCTION IF EXISTS [Identity].[Group_RolesForRolesRoleQuery]
GO
CREATE FUNCTION  [Identity].[Group_RolesForRolesRoleQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[NaturalKey], [T1].[Description]
FROM [Identity].RolesQuery(@searchTerm, @user, @culture) [T1]
JOIN [Identity].[RolesView] [T] ON [T1].[Id] = [T].[Id]
WHERE [T].[IsActive] = 1)
GO
PRINT N'Creating [Identity].[Group_UsersForUsersUserQuery]...';


GO
IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Identity' AND 
                    specific_name = 'Group_UsersForUsersUserQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Identity].[Group_UsersForUsersUserQuery]

GO
CREATE FUNCTION  [Identity].[Group_UsersForUsersUserQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[NaturalKey], [T1].[Picture], [T1].[Name], [T1].[DefaultRoleNaturalKey]
FROM [Identity].UsersQuery(@searchTerm, @user, @culture) [T1]
JOIN [Identity].[UsersView] [T] ON [T1].[Id] = [T].[Id]
WHERE [T].[IsActive] = 1)
GO
PRINT N'Creating [Identity].[Role_GroupsForRoleGroupsGroupQuery]...';
GO
DROP FUNCTION IF EXISTS [Identity].[Role_GroupsForRoleGroupsGroupQuery]
GO
CREATE FUNCTION  [Identity].[Role_GroupsForRoleGroupsGroupQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[NaturalKey], [T1].[Name]
FROM [Identity].GroupsQuery(@searchTerm, @user, @culture) [T1]
JOIN [Identity].[GroupsView] [T] ON [T1].[Id] = [T].[Id]
WHERE [T].[IsActive] = 1)
GO
PRINT N'Creating [Identity].[User_GroupsForGroupsGroupQuery]...';
GO
IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'Identity' AND 
                    specific_name = 'User_GroupsForGroupsGroupQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [Identity].[User_GroupsForGroupsGroupQuery]

GO
CREATE FUNCTION  [Identity].[User_GroupsForGroupsGroupQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[NaturalKey], [T1].[Name]
FROM [Identity].GroupsQuery(@searchTerm, @user, @culture) [T1]
JOIN [Identity].[GroupsView] [T] ON [T1].[Id] = [T].[Id]
WHERE [T].[IsActive] = 1)
GO
PRINT N'Creating [Identity].[Verify_Group_RolesForRolesRoleQuery]...';
GO
DROP FUNCTION IF EXISTS [Identity].[Verify_Group_RolesForRolesRoleQuery]
GO
-- Identity.Verify_Group_RolesForRolesRoleQuery

CREATE FUNCTION [Identity].[Verify_Group_RolesForRolesRoleQuery] (
     @List AS [Identity].Verify_Group_RolesForRolesRoleQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Identity].[Group_RolesForRolesRoleQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO
PRINT N'Creating [Identity].[Verify_Group_UsersForUsersUserQuery]...';
GO
DROP FUNCTION IF EXISTS [Identity].[Verify_Group_UsersForUsersUserQuery]
GO
-- Identity.Verify_Group_UsersForUsersUserQuery

CREATE FUNCTION [Identity].[Verify_Group_UsersForUsersUserQuery] (
     @List AS [Identity].Verify_Group_UsersForUsersUserQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Identity].[Group_UsersForUsersUserQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO
PRINT N'Creating [Identity].[Verify_Role_GroupsForRoleGroupsGroupQuery]...';
GO
DROP FUNCTION IF EXISTS [Identity].[Verify_Role_GroupsForRoleGroupsGroupQuery]
GO
-- Identity.Verify_Role_GroupsForRoleGroupsGroupQuery

CREATE FUNCTION [Identity].[Verify_Role_GroupsForRoleGroupsGroupQuery] (
     @List AS [Identity].Verify_Role_GroupsForRoleGroupsGroupQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Identity].[Role_GroupsForRoleGroupsGroupQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO
PRINT N'Creating [Identity].[Verify_User_GroupsForGroupsGroupQuery]...';
GO
DROP FUNCTION IF EXISTS [Identity].[Verify_User_GroupsForGroupsGroupQuery]
GO
-- Identity.Verify_User_GroupsForGroupsGroupQuery

CREATE FUNCTION [Identity].[Verify_User_GroupsForGroupsGroupQuery] (
     @List AS [Identity].Verify_User_GroupsForGroupsGroupQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Identity].[User_GroupsForGroupsGroupQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO

DROP FUNCTION IF EXISTS [Reporting].[ReportModelDefinition_TemplatesForTemplateQuery]
GO

CREATE FUNCTION  [Reporting].[ReportModelDefinition_TemplatesForTemplateQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[NaturalKey]
FROM [Reporting].TemplatesQuery(@searchTerm, @user, @culture) [T1]
JOIN [Reporting].[TemplatesView] [T] ON [T1].[Id] = [T].[Id]
WHERE [T].[IsActive] = 1)
GO
DROP FUNCTION IF EXISTS [CorePatterns].[SchemaEntities_CustomizableEntitiesQuery]
GO
CREATE FUNCTION  [CorePatterns].[SchemaEntities_CustomizableEntitiesQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM (SELECT [SRC].[Id], [SRC].[Source_NaturalKey], [SRC].[Key], [SRC].[Title], [SRC].[EntityTypeId], [SRC].[EntityTypeValue], [SRC].[EntityType]
FROM (SELECT [T0].[Id] AS [Id], [T0].[NaturalKey] AS [Source_NaturalKey], [T0].[Key] AS [Key], [CorePatterns].[GetLocalizedValue]([T0].[Title], @culture) AS [Title], [T1].[Id] AS [EntityTypeId], [T1].[Value] AS [EntityTypeValue], [CorePatterns].[GetLocalizedValue]([T1].[Description], @culture) AS [EntityType]
FROM [CorePatterns].[SchemaEntitiesView] [T0]
LEFT JOIN [CorePatterns].[SchemaEntityTypesView] [T1] ON [T0].[EntityTypeId] = [T1].[Id]
WHERE (ISNULL([T0].[Key] COLLATE Latin1_general_CI_AI, '') LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR ISNULL([CorePatterns].[GetLocalizedValue]([T0].[Title], @culture), '') LIKE @searchTerm COLLATE Latin1_general_CI_AI)) [SRC]) [FILTERSRC]
WHERE Id IN (SELECT Id from CorePatterns.SchemaEntities where EntityTypeId = (SELECT Id from CorePatterns.SchemaEntityTypes where Name = 'UserEntity')) OR Id IN (SELECT SchemaEntityId from Reporting.GroupSchemaEntities) OR Id IN (SELECT SE.Id FROM CorePatterns.SchemaEntities SE WHERE SE.[AllowExtensibility] = 1 AND SE.[Key] <> 'CustomEntityRecords' AND SE.Id NOT IN (SELECT TargetId FROM CorePatterns.SchemaEntitiesAssociations WHERE IsComposition = 1      )))
GO
PRINT N'Creating [Identity].[CompanyAccessRestriction_GroupsForRestrictedGroupsGroupQuery]...';
DROP FUNCTION IF EXISTS [Identity].[CompanyAccessRestriction_GroupsForRestrictedGroupsGroupQuery]
GO

GO
CREATE FUNCTION  [Identity].[CompanyAccessRestriction_GroupsForRestrictedGroupsGroupQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[NaturalKey], [T1].[Name]
FROM [Identity].GroupsQuery(@searchTerm, @user, @culture) [T1]
JOIN [Identity].[GroupsView] [T] ON [T1].[Id] = [T].[Id]
WHERE [T].[IsActive] = 1)
GO
PRINT N'Creating [Identity].[CompanyAccessRestrictions_CompanyAccessRestrictionsQuery]...';
DROP FUNCTION IF EXISTS [Identity].[CompanyAccessRestrictions_CompanyAccessRestrictionsQuery]
GO

GO
CREATE FUNCTION  [Identity].[CompanyAccessRestrictions_CompanyAccessRestrictionsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [SRC].[Id], [SRC].[Source_NaturalKey], [SRC].[CompanyKey], [SRC].[Name]
FROM (SELECT [T1].[Id] AS [Id], [T1].[NaturalKey] AS [Source_NaturalKey], [T1].[CompanyKey] AS [CompanyKey], [T1].[Name] AS [Name]
FROM [Identity].[CompanyAccessRestrictionsView] [T0]
LEFT JOIN [CorePatterns].[CompaniesView] [T1] ON [T0].[BaseEntityId] = [T1].[Id]
WHERE (ISNULL([T1].[CompanyKey] COLLATE Latin1_general_CI_AI, '') LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR ISNULL([T1].[Name] COLLATE Latin1_general_CI_AI, '') LIKE @searchTerm COLLATE Latin1_general_CI_AI)) [SRC])
GO
PRINT N'Creating [Identity].[CompanyAccessRestrictionsQuery]...';
DROP FUNCTION IF EXISTS [Identity].[CompanyAccessRestrictionsQuery]
GO

GO
CREATE FUNCTION  [Identity].[CompanyAccessRestrictionsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T2].[Id], [T2].[NaturalKey] AS [NaturalKey], [T2].[Name] AS [CompanyName], [T1].[Id] AS [ExtensionId]
FROM [Identity].[CompanyAccessRestrictionsView] [T1]
JOIN [CorePatterns].[CompaniesView] [T2] ON ([T2].[Id] = [T1].[BaseEntityId]
AND [T2].[IsActive] = 1)
WHERE ([T2].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T2].[Name] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI))
GO
PRINT N'Creating [Identity].[Groups_GroupsQuery]...';
DROP FUNCTION IF EXISTS [Identity].[Groups_GroupsQuery]
GO

GO
CREATE FUNCTION  [Identity].[Groups_GroupsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [SRC].[Id], [SRC].[Source_NaturalKey], [SRC].[GroupKey], [SRC].[Name], [SRC].[CreatedBy], [SRC].[ModifiedBy], [SRC].[ModifiedOn]
FROM (SELECT [T0].[Id] AS [Id], [T0].[NaturalKey] AS [Source_NaturalKey], [T0].[GroupKey] AS [GroupKey], [T0].[Name] AS [Name], [T0].[CreatedBy] AS [CreatedBy], [T0].[ModifiedBy] AS [ModifiedBy], [T0].[ModifiedOn] AS [ModifiedOn]
FROM [Identity].[GroupsView] [T0]
WHERE (ISNULL([T0].[GroupKey] COLLATE Latin1_general_CI_AI, '') LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR ISNULL([T0].[Name] COLLATE Latin1_general_CI_AI, '') LIKE @searchTerm COLLATE Latin1_general_CI_AI)) [SRC])
GO
PRINT N'Creating [Identity].[RowLevelSecurityClaim_SchemaEntitiesForSchemaEntityQuery]...';
DROP FUNCTION IF EXISTS [Identity].[RowLevelSecurityClaim_SchemaEntitiesForSchemaEntityQuery]
GO

GO
CREATE FUNCTION  [Identity].[RowLevelSecurityClaim_SchemaEntitiesForSchemaEntityQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[NaturalKey]
FROM [CorePatterns].SchemaEntitiesQuery(@searchTerm, @user, @culture) [T1]
JOIN [CorePatterns].[SchemaEntitiesView] [T] ON [T1].[Id] = [T].[Id]
WHERE [T].[IsActive] = 1)
GO
PRINT N'Creating [Identity].[RowLevelSecurityClaimsQuery]...';
DROP FUNCTION IF EXISTS [Identity].[RowLevelSecurityClaimsQuery]
GO
CREATE FUNCTION  [Identity].[RowLevelSecurityClaimsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[NaturalKey] AS [NaturalKey]
FROM [Identity].[RowLevelSecurityClaimsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO
PRINT N'Creating [Identity].[UserAccessClaim_UsersForUserQuery]...';
DROP FUNCTION IF EXISTS [Identity].[UserAccessClaim_UsersForUserQuery]
GO

GO
CREATE FUNCTION  [Identity].[UserAccessClaim_UsersForUserQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[NaturalKey], [T1].[Picture], [T1].[Name], [T1].[DefaultRoleNaturalKey]
FROM [Identity].UsersQuery(@searchTerm, @user, @culture) [T1]
JOIN [Identity].[UsersView] [T] ON [T1].[Id] = [T].[Id]
WHERE [T].[IsActive] = 1)
GO
PRINT N'Creating [Identity].[UserAccessClaimsQuery]...';
DROP FUNCTION IF EXISTS [Identity].[UserAccessClaimsQuery]
GO

GO
CREATE FUNCTION  [Identity].[UserAccessClaimsQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[NaturalKey] AS [NaturalKey]
FROM [Identity].[UserAccessClaimsView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI)))
GO
PRINT N'Creating [Identity].[Verify_CompanyAccessRestriction_GroupsForRestrictedGroupsGroupQuery]...';
DROP FUNCTION IF EXISTS [Reporting].[Verify_ReportModelDefinition_TemplatesForTemplateQuery]
GO
DROP TYPE IF EXISTS [Reporting].Verify_ReportModelDefinition_TemplatesForTemplateQuery_Parameters
GO
CREATE TYPE [Reporting].Verify_ReportModelDefinition_TemplatesForTemplateQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO
-- Identity.Verify_CompanyAccessRestriction_GroupsForRestrictedGroupsGroupQuery
CREATE FUNCTION [Reporting].[Verify_ReportModelDefinition_TemplatesForTemplateQuery] (
     @List AS [Reporting].Verify_ReportModelDefinition_TemplatesForTemplateQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Reporting].[ReportModelDefinition_TemplatesForTemplateQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO
PRINT N'Creating [Identity].[Verify_RowLevelSecurityClaim_SchemaEntitiesForSchemaEntityQuery]...';
GO
DROP FUNCTION IF EXISTS [Identity].[Verify_RowLevelSecurityClaim_SchemaEntitiesForSchemaEntityQuery]
GO
DROP TYPE IF EXISTS [Identity].Verify_RowLevelSecurityClaim_SchemaEntitiesForSchemaEntityQuery_Parameters
GO
CREATE TYPE [Identity].Verify_RowLevelSecurityClaim_SchemaEntitiesForSchemaEntityQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO
-- Identity.Verify_RowLevelSecurityClaim_SchemaEntitiesForSchemaEntityQuery
CREATE FUNCTION [Identity].[Verify_RowLevelSecurityClaim_SchemaEntitiesForSchemaEntityQuery] (
     @List AS [Identity].Verify_RowLevelSecurityClaim_SchemaEntitiesForSchemaEntityQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Identity].[RowLevelSecurityClaim_SchemaEntitiesForSchemaEntityQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO
PRINT N'Creating [Identity].[Verify_UserAccessClaim_UsersForUserQuery]...';
DROP FUNCTION IF EXISTS [Identity].[Verify_UserAccessClaim_UsersForUserQuery]
GO
DROP TYPE IF EXISTS [Identity].Verify_UserAccessClaim_UsersForUserQuery_Parameters
GO
CREATE TYPE [Identity].Verify_UserAccessClaim_UsersForUserQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO
-- Identity.Verify_UserAccessClaim_UsersForUserQuery

CREATE FUNCTION [Identity].[Verify_UserAccessClaim_UsersForUserQuery] (
     @List AS [Identity].Verify_UserAccessClaim_UsersForUserQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Identity].[UserAccessClaim_UsersForUserQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO
PRINT N'Creating [Reporting].[ReportModelDefinition_TemplatesForTemplateQuery]...';
DROP FUNCTION IF EXISTS [Reporting].[ReportModelDefinition_TemplatesForTemplateQuery]
GO
CREATE FUNCTION  [Reporting].[ReportModelDefinition_TemplatesForTemplateQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[NaturalKey]
FROM [Reporting].TemplatesQuery(@searchTerm, @user, @culture) [T1]
JOIN [Reporting].[TemplatesView] [T] ON [T1].[Id] = [T].[Id]
WHERE [T].[IsActive] = 1)
GO

-- Identity.Verify_CompanyAccessRestriction_GroupsForRestrictedGroupsGroupQuery
DROP FUNCTION IF EXISTS [Identity].[Verify_CompanyAccessRestriction_GroupsForRestrictedGroupsGroupQuery]
GO
DROP TYPE IF EXISTS [Identity].Verify_CompanyAccessRestriction_GroupsForRestrictedGroupsGroupQuery_Parameters
GO
CREATE TYPE [Identity].Verify_CompanyAccessRestriction_GroupsForRestrictedGroupsGroupQuery_Parameters
AS 
TABLE (
    NaturalKey NVARCHAR(100)
);
GO
CREATE FUNCTION [Identity].[Verify_CompanyAccessRestriction_GroupsForRestrictedGroupsGroupQuery] (
     @List AS [Identity].Verify_CompanyAccessRestriction_GroupsForRestrictedGroupsGroupQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Identity].[CompanyAccessRestriction_GroupsForRestrictedGroupsGroupQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO
PRINT N'Creating [Reporting].[Verify_ReportModelDefinition_TemplatesForTemplateQuery]...';
DROP FUNCTION IF EXISTS [Reporting].[Verify_ReportModelDefinition_TemplatesForTemplateQuery]
GO

GO
-- Reporting.Verify_ReportModelDefinition_TemplatesForTemplateQuery

CREATE FUNCTION [Reporting].[Verify_ReportModelDefinition_TemplatesForTemplateQuery] (
     @List AS [Reporting].Verify_ReportModelDefinition_TemplatesForTemplateQuery_Parameters READONLY
    ,@User AS NVARCHAR(100)
    ,@Culture AS NVARCHAR(100)
    )
RETURNS TABLE
AS
RETURN
(
    SELECT ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS [Row]
        ,[NaturalKey]
        ,(
            SELECT TOP 1 [Id]
            FROM [Reporting].[ReportModelDefinition_TemplatesForTemplateQuery](List.NaturalKey, @User, @Culture)
         ) AS [MatchId]
    FROM @List AS List
)
GO
DROP PROCEDURE IF EXISTS [Identity].[usp_LoadGroupUsers]
GO
CREATE PROCEDURE [Identity].[usp_LoadGroupUsers] (@groupId uniqueidentifier)
AS
BEGIN
	WITH GroupCte AS 
	(
		SELECT GU.GroupId, GU.UserId
		FROM [Identity].GroupsUsers GU
		WHERE GroupId = @groupId		
	)

	SELECT DISTINCT
		U.[Id], 
		U.[UserKey], 
		U.[Name]
	FROM GroupCte cte
	INNER JOIN [Identity].[Users] U ON U.Id = cte.UserId
END
GO
DROP PROCEDURE IF EXISTS [Identity].[usp_LoadUserRoles]
GO
CREATE PROCEDURE [Identity].[usp_LoadUserRoles] (@userId uniqueidentifier) AS
BEGIN
	SELECT R.[Id], R.[RoleKey], R.[Description], R.[IsAdministration], R.[IsSystem]
	FROM [Identity].Roles R INNER JOIN [Identity].UsersRoles UR ON R.Id = UR.RoleId
	WHERE UR.UserId = @userId
END
GO
IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = 'BackgroundOperationDetails_IDX1' AND object_id = OBJECT_ID('[CorePatterns].[BackgroundOperationDetails]'))
	CREATE NONCLUSTERED INDEX [BackgroundOperationDetails_IDX1] ON [CorePatterns].[BackgroundOperationDetails]([Description] ASC);
GO
IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = 'BackgroundOperationDetails_IDX2' AND object_id = OBJECT_ID('[CorePatterns].[BackgroundOperationDetails]'))
	CREATE CLUSTERED INDEX [BackgroundOperationDetails_IDX2] ON [CorePatterns].[BackgroundOperationDetails]([BackgroundOperationId] ASC, [Index] ASC);
GO
IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = 'CompanyAccessRestrictions_IDX0' AND object_id = OBJECT_ID('[Identity].[CompanyAccessRestrictions]'))
	CREATE CLUSTERED INDEX [CompanyAccessRestrictions_IDX0] ON [Identity].[CompanyAccessRestrictions]([CreatedOn] ASC);
GO
IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = 'GroupsUsers_IDX0' AND object_id = OBJECT_ID('[Identity].[GroupsUsers]'))
	CREATE CLUSTERED INDEX [GroupsUsers_IDX0] ON [Identity].[GroupsUsers]([CreatedOn] ASC);
GO
IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = 'RestrictedGroups_IDX1' AND object_id = OBJECT_ID('[Identity].[RestrictedGroups]'))
	CREATE CLUSTERED INDEX [RestrictedGroups_IDX1] ON [Identity].[RestrictedGroups]([CompanyAccessRestrictionId] ASC, [Index] ASC);
GO
IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = 'RowLevelSecurityClaims_IDX_SchemaEntityIdRecordId' AND object_id = OBJECT_ID('[Identity].[RowLevelSecurityClaims]'))
	CREATE UNIQUE NONCLUSTERED INDEX [RowLevelSecurityClaims_IDX_SchemaEntityIdRecordId] ON [Identity].[RowLevelSecurityClaims]([SchemaEntityId] ASC, [RecordId] ASC);
GO
IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = 'RowLevelSecurityClaims_IDX0' AND object_id = OBJECT_ID('[Identity].[RowLevelSecurityClaims]'))
	CREATE CLUSTERED INDEX [RowLevelSecurityClaims_IDX0] ON [Identity].[RowLevelSecurityClaims]([CreatedOn] ASC);
GO
IF NOT EXISTS(SELECT * FROM sys.indexes WHERE name = 'UserAccessClaims_IDX0' AND object_id = OBJECT_ID('[Identity].[UserAccessClaims]'))
	CREATE CLUSTERED INDEX [UserAccessClaims_IDX0] ON [Identity].[UserAccessClaims]([CreatedOn] ASC);
GO
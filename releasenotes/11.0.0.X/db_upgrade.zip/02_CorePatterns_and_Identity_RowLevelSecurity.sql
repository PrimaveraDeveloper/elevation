-- Identity Cleanup + Add new objects for RLS support

-------------------------------------------------------------------
-- 1. Authorizable Resources
-------------------------------------------------------------------

-- Custom Indexes (AuthorizableResources)

IF EXISTS(SELECT id FROM sysindexes WHERE name = 'AuthorizableResources_IDXC1')
	DROP INDEX [Identity].[AuthorizableResources].[AuthorizableResources_IDXC1]
GO

-- Stored Procedure (usp_IsAuthorized)

IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[usp_IsAuthorized]'))
	DROP PROCEDURE [Identity].[usp_IsAuthorized]
GO

-- Stored Procedure (usp_LoadUserAuthorizations)

IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[usp_LoadUserAuthorizations]'))
	DROP PROCEDURE [Identity].[usp_LoadUserAuthorizations]
GO

-- Stored Procedure ([usp_GrantRoleFullAccessToAllResources])

IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[usp_GrantRoleFullAccessToAllResources]'))
	DROP PROCEDURE [Identity].[usp_GrantRoleFullAccessToAllResources]
GO


-------------------------------------------------------------------
-- 2. Access Groups
-------------------------------------------------------------------

-- Stored Procedure (usp_LoadAccessGroupsRecordsForEntity)

IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[usp_LoadAccessGroupsRecordsForEntity]'))
	DROP PROCEDURE [Identity].[usp_LoadAccessGroupsRecordsForEntity]
GO

-- Stored Procedure (usp_LoadAccessGroupEntities)

IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[usp_LoadAccessGroupEntities]'))
	DROP PROCEDURE [Identity].[usp_LoadAccessGroupEntities]
GO

-------------------------------------------------------------------
-- 3. Identity Deprecated Views
-------------------------------------------------------------------

/****** Object:  View [Identity].[AccessGroupRecordsView]    Script Date: 16/11/2020 08:51:04 ******/
IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[AccessGroupRecordsView]'))
	DROP VIEW [Identity].[AccessGroupRecordsView]
GO

/****** Object:  View [Identity].[AccessGroupResourcesView]    Script Date: 16/11/2020 08:51:54 ******/
IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[AccessGroupResourcesView]'))
	DROP VIEW [Identity].[AccessGroupResourcesView]
GO

/****** Object:  View [Identity].[AccessGroupsView]    Script Date: 16/11/2020 08:52:07 ******/
IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[AccessGroupsView]'))
	DROP VIEW [Identity].[AccessGroupsView]
GO

/****** Object:  View [Identity].[AccessGroupUsersView]    Script Date: 16/11/2020 08:52:18 ******/
IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[AccessGroupUsersView]'))
	DROP VIEW [Identity].[AccessGroupUsersView]
GO

/****** Object:  View [Identity].[AuthorizableResourcePermissionsView]    Script Date: 16/11/2020 08:52:53 ******/
IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[AuthorizableResourcePermissionsView]'))
	DROP VIEW [Identity].[AuthorizableResourcePermissionsView]
GO

/****** Object:  View [Identity].[AuthorizableResourcesView]    Script Date: 16/11/2020 08:53:02 ******/
IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[AuthorizableResourcesView]'))
	DROP VIEW [Identity].[AuthorizableResourcesView]
GO

/****** Object:  View [Identity].[AuthorizationsView]    Script Date: 16/11/2020 08:53:15 ******/
IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[AuthorizationsView]'))
	DROP VIEW [Identity].[AuthorizationsView]
GO

/****** Object:  View [Identity].[GroupRolesView]    Script Date: 16/11/2020 08:53:36 ******/
IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[GroupRolesView]'))
	DROP VIEW [Identity].[GroupRolesView]
GO

/****** Object:  View [Identity].[RoleGroupsView]    Script Date: 16/11/2020 08:54:55 ******/
IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[RoleGroupsView]'))
	DROP VIEW [Identity].[RoleGroupsView]
GO

/****** Object:  View [Identity].[SubGroupsView]    Script Date: 16/11/2020 08:55:21 ******/
IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[SubGroupsView]'))
	DROP VIEW [Identity].[SubGroupsView]
GO

/****** Object:  View [Identity].[UserGroupsView]    Script Date: 16/11/2020 08:56:23 ******/
IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[UserGroupsView]'))
	DROP VIEW [Identity].[UserGroupsView]
GO

-------------------------------------------------------------------
-- 4. Identity Deprecated Tables
-------------------------------------------------------------------

/****** Object:  Table [Identity].[AccessGroupRecords]    Script Date: 16/11/2020 08:51:04 ******/
IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[AccessGroupRecords]'))
	DROP Table [Identity].[AccessGroupRecords]
GO

/****** Object:  Table [Identity].[AccessGroupUsers]    Script Date: 16/11/2020 08:52:18 ******/
IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[AccessGroupUsers]'))
	DROP Table [Identity].[AccessGroupUsers]
GO

/****** Object:  Table [Identity].[AccessGroups]    Script Date: 16/11/2020 08:52:07 ******/
IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[AccessGroups]'))
	DROP Table [Identity].[AccessGroups]
GO

/****** Object:  Table [Identity].[AuthorizableResourcePermissions]    Script Date: 16/11/2020 08:52:53 ******/
IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[AuthorizableResourcePermissions]'))
	DROP Table [Identity].[AuthorizableResourcePermissions]
GO

/****** Object:  Table [Identity].[AuthorizableResources]    Script Date: 16/11/2020 08:53:02 ******/
IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[AuthorizableResources]'))
	DROP Table [Identity].[AuthorizableResources]
GO

/****** Object:  Table [Identity].[Authorizations]    Script Date: 16/11/2020 08:53:15 ******/
IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[Authorizations]'))
	DROP Table [Identity].[Authorizations]
GO

/****** Object:  Table [Identity].[GroupRoles]    Script Date: 16/11/2020 08:53:36 ******/
IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[GroupRoles]'))
	DROP Table [Identity].[GroupRoles]
GO

/****** Object:  Table [Identity].[RoleGroups]    Script Date: 16/11/2020 08:54:55 ******/
IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[RoleGroups]'))
	DROP Table [Identity].[RoleGroups]
GO

/****** Object:  Table [Identity].[SubGroups]    Script Date: 16/11/2020 08:55:21 ******/
IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[SubGroups]'))
	DROP Table [Identity].[SubGroups]
GO

/****** Object:  Table [Identity].[UserGroups]    Script Date: 16/11/2020 08:56:23 ******/
IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[UserGroups]'))
	DROP Table [Identity].[UserGroups]
GO

--######################### NEW OBJECTS ###########################


-------------------------------------------------------------------
-- 5. Add new column 'AccessClaim' to the 'Companies' entity.
-------------------------------------------------------------------

IF NOT EXISTS(SELECT 1 FROM sys.columns 
          WHERE Name = N'AccessClaim'
          AND Object_ID = Object_ID(N'[CorePatterns].[Companies]'))
	ALTER TABLE [CorePatterns].[Companies] ADD AccessClaim int null
GO

-- The Companies AccessClaim column must have a specific Index for performance reasons

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[CorePatterns].[Companies]') AND name = N'Companies_AccessClaim_IDX')
	CREATE NONCLUSTERED INDEX [Companies_AccessClaim_IDX] ON [CorePatterns].[Companies] ([AccessClaim])
GO

-------------------------------------------------------------------
-- 6. Create New Tables and corresponding Views
-------------------------------------------------------------------

-- CompanyAccessRestrictions (Company Extension)

IF NOT EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[CompanyAccessRestrictions]'))
BEGIN
	CREATE TABLE [Identity].[CompanyAccessRestrictions](
		[Id] [uniqueidentifier] NOT NULL,
		[BaseEntityId] [uniqueidentifier] NOT NULL,
		[IsDraft] [bit] NOT NULL,
		[CreatedBy] [nvarchar](255) NOT NULL,
		[CreatedOn] [datetimeoffset](7) NOT NULL,
		[ModifiedBy] [nvarchar](255) NOT NULL,
		[ModifiedOn] [datetimeoffset](7) NOT NULL,
		[IsActive] [bit] NOT NULL,
		[IsDeleted] [bit] NOT NULL,
		[IsSystem] [bit] NOT NULL,
		[Version] [timestamp] NOT NULL,
	 CONSTRAINT [CompanyAccessRestrictions_PK] PRIMARY KEY NONCLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
	 CONSTRAINT [CompanyAccessRestrictions_BaseEntityId_UK] UNIQUE NONCLUSTERED 
	(
		[BaseEntityId] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
	) ON [PRIMARY]

	ALTER TABLE [Identity].[CompanyAccessRestrictions] ADD  CONSTRAINT [CompanyAccessRestrictions_Id_DF]  DEFAULT (newsequentialid()) FOR [Id]

	ALTER TABLE [Identity].[CompanyAccessRestrictions] ADD  CONSTRAINT [CompanyAccessRestrictions_IsDraft_DF]  DEFAULT ((0)) FOR [IsDraft]

	ALTER TABLE [Identity].[CompanyAccessRestrictions] ADD  CONSTRAINT [CompanyAccessRestrictions_CreatedBy_DF]  DEFAULT ('<Sys>') FOR [CreatedBy]

	ALTER TABLE [Identity].[CompanyAccessRestrictions] ADD  CONSTRAINT [CompanyAccessRestrictions_CreatedOn_DF]  DEFAULT (sysdatetimeoffset()) FOR [CreatedOn]

	ALTER TABLE [Identity].[CompanyAccessRestrictions] ADD  CONSTRAINT [CompanyAccessRestrictions_ModifiedBy_DF]  DEFAULT ('<Sys>') FOR [ModifiedBy]

	ALTER TABLE [Identity].[CompanyAccessRestrictions] ADD  CONSTRAINT [CompanyAccessRestrictions_ModifiedOn_DF]  DEFAULT (sysdatetimeoffset()) FOR [ModifiedOn]	

	ALTER TABLE [Identity].[CompanyAccessRestrictions] ADD  CONSTRAINT [CompanyAccessRestrictions_IsActive_DF]  DEFAULT ((1)) FOR [IsActive]	

	ALTER TABLE [Identity].[CompanyAccessRestrictions] ADD  CONSTRAINT [CompanyAccessRestrictions_IsDeleted_DF]  DEFAULT ((0)) FOR [IsDeleted]

	ALTER TABLE [Identity].[CompanyAccessRestrictions] ADD  CONSTRAINT [CompanyAccessRestrictions_IsSystem_DF]  DEFAULT ((0)) FOR [IsSystem]

	ALTER TABLE [Identity].[CompanyAccessRestrictions]  WITH CHECK ADD  CONSTRAINT [CompanyAccessRestrictions_Companies_BaseEntityId_FK] FOREIGN KEY([BaseEntityId])
	REFERENCES [CorePatterns].[Companies] ([Id])

	ALTER TABLE [Identity].[CompanyAccessRestrictions] CHECK CONSTRAINT [CompanyAccessRestrictions_Companies_BaseEntityId_FK]

END

-- View

IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[CompanyAccessRestrictionsView]'))
	DROP VIEW [Identity].[CompanyAccessRestrictionsView]
GO

CREATE VIEW [Identity].[CompanyAccessRestrictionsView]
WITH SCHEMABINDING AS
SELECT
    E.[Id]
    , E.[BaseEntityId]
	, E.[IsDraft]
	, E.[CreatedBy]
	, E.[CreatedOn]
	, E.[ModifiedBy]
	, E.[ModifiedOn]
	, E.[IsActive]
	, E.[IsDeleted]
	, E.[IsSystem]
	, E.[Version]
FROM [Identity].[CompanyAccessRestrictions] E
WHERE E.[IsDeleted] = 0
GO

-- GroupsUsers (many to many relation table)

IF NOT EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[GroupsUsers]'))
BEGIN
	CREATE TABLE [Identity].[GroupsUsers](
		[Id] [uniqueidentifier] NOT NULL,
		[GroupId] [uniqueidentifier] NOT NULL,
		[UserId] [uniqueidentifier] NOT NULL,
		[IsDraft] [bit] NOT NULL,
		[CreatedBy] [nvarchar](255) NOT NULL,
		[CreatedOn] [datetimeoffset](7) NOT NULL,
		[ModifiedBy] [nvarchar](255) NOT NULL,
		[ModifiedOn] [datetimeoffset](7) NOT NULL,
		[IsActive] [bit] NOT NULL,
		[IsDeleted] [bit] NOT NULL,
		[IsSystem] [bit] NOT NULL,
		[Version] [timestamp] NOT NULL,
	 CONSTRAINT [GroupsUsers_PK] PRIMARY KEY NONCLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
	) ON [PRIMARY]

	ALTER TABLE [Identity].[GroupsUsers] ADD  CONSTRAINT [GroupsUsers_Id_DF]  DEFAULT (newsequentialid()) FOR [Id]

	ALTER TABLE [Identity].[GroupsUsers] ADD  CONSTRAINT [GroupsUsers_IsDraft_DF]  DEFAULT ((0)) FOR [IsDraft]

	ALTER TABLE [Identity].[GroupsUsers] ADD  CONSTRAINT [GroupsUsers_CreatedBy_DF]  DEFAULT ('<Sys>') FOR [CreatedBy]

	ALTER TABLE [Identity].[GroupsUsers] ADD  CONSTRAINT [GroupsUsers_CreatedOn_DF]  DEFAULT (sysdatetimeoffset()) FOR [CreatedOn]

	ALTER TABLE [Identity].[GroupsUsers] ADD  CONSTRAINT [GroupsUsers_ModifiedBy_DF]  DEFAULT ('<Sys>') FOR [ModifiedBy]

	ALTER TABLE [Identity].[GroupsUsers] ADD  CONSTRAINT [GroupsUsers_ModifiedOn_DF]  DEFAULT (sysdatetimeoffset()) FOR [ModifiedOn]

	ALTER TABLE [Identity].[GroupsUsers] ADD  CONSTRAINT [GroupsUsers_IsActive_DF]  DEFAULT ((1)) FOR [IsActive]

	ALTER TABLE [Identity].[GroupsUsers] ADD  CONSTRAINT [GroupsUsers_IsDeleted_DF]  DEFAULT ((0)) FOR [IsDeleted]

	ALTER TABLE [Identity].[GroupsUsers] ADD  CONSTRAINT [GroupsUsers_IsSystem_DF]  DEFAULT ((0)) FOR [IsSystem]

	ALTER TABLE [Identity].[GroupsUsers]  WITH CHECK ADD  CONSTRAINT [GroupsUsers_Group_GroupId_FK] FOREIGN KEY([GroupId])
	REFERENCES [Identity].[Groups] ([Id])
	ON DELETE CASCADE

	ALTER TABLE [Identity].[GroupsUsers] CHECK CONSTRAINT [GroupsUsers_Group_GroupId_FK]

	ALTER TABLE [Identity].[GroupsUsers]  WITH CHECK ADD  CONSTRAINT [GroupsUsers_User_UserId_FK] FOREIGN KEY([UserId])
	REFERENCES [Identity].[Users] ([Id])
	ON DELETE CASCADE

	ALTER TABLE [Identity].[GroupsUsers] CHECK CONSTRAINT [GroupsUsers_User_UserId_FK]
END

-- View [GroupsUsersView]

IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[GroupsUsersView]'))
	DROP VIEW [Identity].[GroupsUsersView]
GO

CREATE VIEW [Identity].[GroupsUsersView]
WITH SCHEMABINDING AS
SELECT
    E.[Id]
    , E.[GroupId]
	, E.[UserId]
	, E.[IsDraft]
	, E.[CreatedBy]
	, E.[CreatedOn]
	, E.[ModifiedBy]
	, E.[ModifiedOn]
	, E.[IsActive]
	, E.[IsDeleted]
	, E.[IsSystem]
	, E.[Version]
FROM [Identity].[GroupsUsers] E
WHERE E.[IsDeleted] = 0
GO

-- RestrictedGroups : Detail of CompanyAccessRestrictions

IF NOT EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[RestrictedGroups]'))
BEGIN
	CREATE TABLE [Identity].[RestrictedGroups](
		[Id] [uniqueidentifier] NOT NULL,
		[GroupId] [uniqueidentifier] NOT NULL,
		[CompanyAccessRestrictionId] [uniqueidentifier] NOT NULL,
		[Index] [int] NOT NULL,
		[CreatedBy] [nvarchar](255) NOT NULL,
		[CreatedOn] [datetimeoffset](7) NOT NULL,
		[ModifiedBy] [nvarchar](255) NOT NULL,
		[ModifiedOn] [datetimeoffset](7) NOT NULL,
		[IsActive] [bit] NOT NULL,
		[IsDeleted] [bit] NOT NULL,
		[IsSystem] [bit] NOT NULL,
		[Version] [timestamp] NOT NULL,
	 CONSTRAINT [RestrictedGroups_PK] PRIMARY KEY NONCLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
	) ON [PRIMARY]

	ALTER TABLE [Identity].[RestrictedGroups] ADD  CONSTRAINT [RestrictedGroups_Id_DF]  DEFAULT (newsequentialid()) FOR [Id]

	ALTER TABLE [Identity].[RestrictedGroups] ADD  CONSTRAINT [RestrictedGroups_Index_DF]  DEFAULT ((0)) FOR [Index]

	ALTER TABLE [Identity].[RestrictedGroups] ADD  CONSTRAINT [RestrictedGroups_CreatedBy_DF]  DEFAULT ('<Sys>') FOR [CreatedBy]

	ALTER TABLE [Identity].[RestrictedGroups] ADD  CONSTRAINT [RestrictedGroups_CreatedOn_DF]  DEFAULT (sysdatetimeoffset()) FOR [CreatedOn]

	ALTER TABLE [Identity].[RestrictedGroups] ADD  CONSTRAINT [RestrictedGroups_ModifiedBy_DF]  DEFAULT ('<Sys>') FOR [ModifiedBy]

	ALTER TABLE [Identity].[RestrictedGroups] ADD  CONSTRAINT [RestrictedGroups_ModifiedOn_DF]  DEFAULT (sysdatetimeoffset()) FOR [ModifiedOn]

	ALTER TABLE [Identity].[RestrictedGroups] ADD  CONSTRAINT [RestrictedGroups_IsActive_DF]  DEFAULT ((1)) FOR [IsActive]

	ALTER TABLE [Identity].[RestrictedGroups] ADD  CONSTRAINT [RestrictedGroups_IsDeleted_DF]  DEFAULT ((0)) FOR [IsDeleted]

	ALTER TABLE [Identity].[RestrictedGroups] ADD  CONSTRAINT [RestrictedGroups_IsSystem_DF]  DEFAULT ((0)) FOR [IsSystem]

	ALTER TABLE [Identity].[RestrictedGroups]  WITH CHECK ADD  CONSTRAINT [RestrictedGroups_CompanyAccessRestrictions_CompanyAccessRestrictionId_FK] FOREIGN KEY([CompanyAccessRestrictionId])
	REFERENCES [Identity].[CompanyAccessRestrictions] ([Id])
	ON DELETE CASCADE

	ALTER TABLE [Identity].[RestrictedGroups] CHECK CONSTRAINT [RestrictedGroups_CompanyAccessRestrictions_CompanyAccessRestrictionId_FK]

	ALTER TABLE [Identity].[RestrictedGroups]  WITH CHECK ADD  CONSTRAINT [RestrictedGroups_Groups_GroupId_FK] FOREIGN KEY([GroupId])
	REFERENCES [Identity].[Groups] ([Id])

	ALTER TABLE [Identity].[RestrictedGroups] CHECK CONSTRAINT [RestrictedGroups_Groups_GroupId_FK]

END
-- View: RestrictedGroupsView

IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[RestrictedGroupsView]'))
	DROP VIEW [Identity].[RestrictedGroupsView]
GO

CREATE VIEW [Identity].[RestrictedGroupsView]
WITH SCHEMABINDING AS
SELECT
    E.[Id]
    , E.[GroupId]
	, E.[CompanyAccessRestrictionId]
	, E.[Index]
	, E.[CreatedBy]
	, E.[CreatedOn]
	, E.[ModifiedBy]
	, E.[ModifiedOn]
	, E.[IsActive]
	, E.[IsDeleted]
	, E.[IsSystem]
	, E.[Version]
FROM [Identity].[RestrictedGroups] E
WHERE E.[IsDeleted] = 0
GO

-- Table: RowLevelSecurityClaims

IF NOT EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[RowLevelSecurityClaims]'))
BEGIN
	CREATE TABLE [Identity].[RowLevelSecurityClaims](
		[Id] [uniqueidentifier] NOT NULL,
		[AccessClaim] [int] IDENTITY(1,1) NOT NULL,
		[SchemaEntityId] [uniqueidentifier] NOT NULL,
		[RecordId] [uniqueidentifier] NOT NULL,
		[NaturalKey] [nvarchar](255) NOT NULL,
		[IsDraft] [bit] NOT NULL,
		[CreatedBy] [nvarchar](255) NOT NULL,
		[CreatedOn] [datetimeoffset](7) NOT NULL,
		[ModifiedBy] [nvarchar](255) NOT NULL,
		[ModifiedOn] [datetimeoffset](7) NOT NULL,
		[IsActive] [bit] NOT NULL,
		[IsDeleted] [bit] NOT NULL,
		[IsSystem] [bit] NOT NULL,
		[Version] [timestamp] NOT NULL,
	 CONSTRAINT [RowLevelSecurityClaims_PK] PRIMARY KEY NONCLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
	 CONSTRAINT [RowLevelSecurityClaims_UK] UNIQUE NONCLUSTERED 
	(
		[AccessClaim] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
	 CONSTRAINT [RowLevelSecurityClaims_UK2] UNIQUE NONCLUSTERED 
	(
		[NaturalKey] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
	) ON [PRIMARY]


	ALTER TABLE [Identity].[RowLevelSecurityClaims] ADD  CONSTRAINT [RowLevelSecurityClaims_Id_DF]  DEFAULT (newsequentialid()) FOR [Id]

	ALTER TABLE [Identity].[RowLevelSecurityClaims] ADD  CONSTRAINT [RowLevelSecurityClaims_IsDraft_DF]  DEFAULT ((0)) FOR [IsDraft]

	ALTER TABLE [Identity].[RowLevelSecurityClaims] ADD  CONSTRAINT [RowLevelSecurityClaims_CreatedBy_DF]  DEFAULT ('<Sys>') FOR [CreatedBy]

	ALTER TABLE [Identity].[RowLevelSecurityClaims] ADD  CONSTRAINT [RowLevelSecurityClaims_CreatedOn_DF]  DEFAULT (sysdatetimeoffset()) FOR [CreatedOn]

	ALTER TABLE [Identity].[RowLevelSecurityClaims] ADD  CONSTRAINT [RowLevelSecurityClaims_ModifiedBy_DF]  DEFAULT ('<Sys>') FOR [ModifiedBy]

	ALTER TABLE [Identity].[RowLevelSecurityClaims] ADD  CONSTRAINT [RowLevelSecurityClaims_ModifiedOn_DF]  DEFAULT (sysdatetimeoffset()) FOR [ModifiedOn]

	ALTER TABLE [Identity].[RowLevelSecurityClaims] ADD  CONSTRAINT [RowLevelSecurityClaims_IsActive_DF]  DEFAULT ((1)) FOR [IsActive]

	ALTER TABLE [Identity].[RowLevelSecurityClaims] ADD  CONSTRAINT [RowLevelSecurityClaims_IsDeleted_DF]  DEFAULT ((0)) FOR [IsDeleted]

	ALTER TABLE [Identity].[RowLevelSecurityClaims] ADD  CONSTRAINT [RowLevelSecurityClaims_IsSystem_DF]  DEFAULT ((0)) FOR [IsSystem]

	ALTER TABLE [Identity].[RowLevelSecurityClaims]  WITH CHECK ADD  CONSTRAINT [RowLevelSecurityClaims_SchemaEntities_SchemaEntityId_FK] FOREIGN KEY([SchemaEntityId])
	REFERENCES [CorePatterns].[SchemaEntities] ([Id])

	ALTER TABLE [Identity].[RowLevelSecurityClaims] CHECK CONSTRAINT [RowLevelSecurityClaims_SchemaEntities_SchemaEntityId_FK]
END

-- View: RowLevelSecurityClaimsView

IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[RowLevelSecurityClaimsView]'))
	DROP VIEW [Identity].[RowLevelSecurityClaimsView]
GO

CREATE VIEW [Identity].[RowLevelSecurityClaimsView]
WITH SCHEMABINDING AS
SELECT
    E.[Id]
    , E.[AccessClaim]
	, E.[SchemaEntityId]
	, E.[RecordId]
	, E.[NaturalKey]
	, E.[IsDraft]
	, E.[CreatedBy]
	, E.[CreatedOn]
	, E.[ModifiedBy]
	, E.[ModifiedOn]
	, E.[IsActive]
	, E.[IsDeleted]
	, E.[IsSystem]
	, E.[Version]
FROM [Identity].[RowLevelSecurityClaims] E
WHERE E.[IsDeleted] = 0
GO

-- Table: UserAccessClaims

IF NOT EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[UserAccessClaims]'))
BEGIN
	CREATE TABLE [Identity].[UserAccessClaims](
		[Id] [uniqueidentifier] NOT NULL,
		[UserId] [uniqueidentifier] NOT NULL,
		[AccessClaim] [int] NOT NULL,
		[NaturalKey] [nvarchar](255) NOT NULL,
		[IsDraft] [bit] NOT NULL,
		[CreatedBy] [nvarchar](255) NOT NULL,
		[CreatedOn] [datetimeoffset](7) NOT NULL,
		[ModifiedBy] [nvarchar](255) NOT NULL,
		[ModifiedOn] [datetimeoffset](7) NOT NULL,
		[IsActive] [bit] NOT NULL,
		[IsDeleted] [bit] NOT NULL,
		[IsSystem] [bit] NOT NULL,
		[Version] [timestamp] NOT NULL,
	 CONSTRAINT [UserAccessClaims_PK] PRIMARY KEY NONCLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
	 CONSTRAINT [UserAccessClaims_UK] UNIQUE NONCLUSTERED 
	(
		[UserId] ASC,
		[AccessClaim] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
	 CONSTRAINT [UserAccessClaims_UK2] UNIQUE NONCLUSTERED 
	(
		[NaturalKey] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
	) ON [PRIMARY]


	ALTER TABLE [Identity].[UserAccessClaims] ADD  CONSTRAINT [UserAccessClaims_Id_DF]  DEFAULT (newsequentialid()) FOR [Id]

	ALTER TABLE [Identity].[UserAccessClaims] ADD  CONSTRAINT [UserAccessClaims_IsDraft_DF]  DEFAULT ((0)) FOR [IsDraft]

	ALTER TABLE [Identity].[UserAccessClaims] ADD  CONSTRAINT [UserAccessClaims_CreatedBy_DF]  DEFAULT ('<Sys>') FOR [CreatedBy]

	ALTER TABLE [Identity].[UserAccessClaims] ADD  CONSTRAINT [UserAccessClaims_CreatedOn_DF]  DEFAULT (sysdatetimeoffset()) FOR [CreatedOn]

	ALTER TABLE [Identity].[UserAccessClaims] ADD  CONSTRAINT [UserAccessClaims_ModifiedBy_DF]  DEFAULT ('<Sys>') FOR [ModifiedBy]

	ALTER TABLE [Identity].[UserAccessClaims] ADD  CONSTRAINT [UserAccessClaims_ModifiedOn_DF]  DEFAULT (sysdatetimeoffset()) FOR [ModifiedOn]

	ALTER TABLE [Identity].[UserAccessClaims] ADD  CONSTRAINT [UserAccessClaims_IsActive_DF]  DEFAULT ((1)) FOR [IsActive]

	ALTER TABLE [Identity].[UserAccessClaims] ADD  CONSTRAINT [UserAccessClaims_IsDeleted_DF]  DEFAULT ((0)) FOR [IsDeleted]

	ALTER TABLE [Identity].[UserAccessClaims] ADD  CONSTRAINT [UserAccessClaims_IsSystem_DF]  DEFAULT ((0)) FOR [IsSystem]

	ALTER TABLE [Identity].[UserAccessClaims]  WITH CHECK ADD  CONSTRAINT [UserAccessClaims_Users_UserId_FK] FOREIGN KEY([UserId])
	REFERENCES [Identity].[Users] ([Id])

	ALTER TABLE [Identity].[UserAccessClaims] CHECK CONSTRAINT [UserAccessClaims_Users_UserId_FK]
END

-- View: UserAccessClaimsView

IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[Identity].[UserAccessClaimsView]'))
	DROP VIEW [Identity].[UserAccessClaimsView]
GO

CREATE VIEW [Identity].[UserAccessClaimsView]
WITH SCHEMABINDING AS
SELECT
    E.[Id]
    , E.[UserId]
	, E.[AccessClaim]
	, E.[NaturalKey]
	, E.[IsDraft]
	, E.[CreatedBy]
	, E.[CreatedOn]
	, E.[ModifiedBy]
	, E.[ModifiedOn]
	, E.[IsActive]
	, E.[IsDeleted]
	, E.[IsSystem]
	, E.[Version]
FROM [Identity].[UserAccessClaims] E
WHERE E.[IsDeleted] = 0
GO

------------------------------------------------------
-- Schema Entities and Attributes : Remove deprecated
------------------------------------------------------

-- [Identity].[AccessGroupRecords]

declare @entityId uniqueidentifier

SELECT @entityId = Id FROM CorePatterns.SchemaEntities WHERE ModuleName='Identity' AND [Key]='AccessGroupUsers'

IF (ISNULL(@entityId, 'C3A1F680-8705-4951-81A1-C3DBD255903D') <> 'C3A1F680-8705-4951-81A1-C3DBD255903D') 
BEGIN
	DELETE FROM QueryBuilder.ListModels WHERE MainEntityId = @entityId	

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE SchemaEntityId=@entityId

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE TargetId IN (SELECT Id FROM CorePatterns.SchemaAttributes WHERE SchemaEntityId=@entityId)

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE AttributeId IN (SELECT Id FROM CorePatterns.SchemaAttributes WHERE SchemaEntityId=@entityId)

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE AttributeId IN (SELECT Id FROM CorePatterns.SchemaAttributes WHERE LookupEntityId=@entityId)

	DELETE FROM CorePatterns.SchemaAttributes WHERE SchemaEntityId=@entityId
	
	DELETE FROM CorePatterns.SchemaAttributes WHERE LookupEntityId=@entityId	

	DELETE FROM CorePatterns.Operations WHERE SchemaEntityId=@entityId
	
	DELETE FROM CorePatterns.SchemaEntities WHERE Id=@entityId
END 
GO 

-- [Identity].[AccessGroupUsers]

declare @entityId uniqueidentifier

SELECT @entityId = Id FROM CorePatterns.SchemaEntities WHERE ModuleName='Identity' AND [Key]='AccessGroupUsers'

IF (ISNULL(@entityId, 'C3A1F680-8705-4951-81A1-C3DBD255903D') <> 'C3A1F680-8705-4951-81A1-C3DBD255903D') 
BEGIN
	DELETE FROM QueryBuilder.ListModels WHERE MainEntityId = @entityId	

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE SchemaEntityId=@entityId

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE TargetId IN (SELECT Id FROM CorePatterns.SchemaAttributes WHERE SchemaEntityId=@entityId)

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE AttributeId IN (SELECT Id FROM CorePatterns.SchemaAttributes WHERE SchemaEntityId=@entityId)

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE AttributeId IN (SELECT Id FROM CorePatterns.SchemaAttributes WHERE LookupEntityId=@entityId)

	DELETE FROM CorePatterns.SchemaAttributes WHERE SchemaEntityId=@entityId
	
	DELETE FROM CorePatterns.SchemaAttributes WHERE LookupEntityId=@entityId	

	DELETE FROM CorePatterns.Operations WHERE SchemaEntityId=@entityId
	
	DELETE FROM CorePatterns.SchemaEntities WHERE Id=@entityId
END 
GO 

-- [Identity].[AccessGroups]

declare @entityId uniqueidentifier

SELECT @entityId = Id FROM CorePatterns.SchemaEntities WHERE ModuleName='Identity' AND [Key]='AccessGroups'

IF (ISNULL(@entityId, 'C3A1F680-8705-4951-81A1-C3DBD255903D') <> 'C3A1F680-8705-4951-81A1-C3DBD255903D') 
BEGIN
	DELETE FROM QueryBuilder.ListModels WHERE MainEntityId = @entityId	

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE SchemaEntityId=@entityId

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE TargetId IN (SELECT Id FROM CorePatterns.SchemaAttributes WHERE SchemaEntityId=@entityId)

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE AttributeId IN (SELECT Id FROM CorePatterns.SchemaAttributes WHERE SchemaEntityId=@entityId)

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE AttributeId IN (SELECT Id FROM CorePatterns.SchemaAttributes WHERE LookupEntityId=@entityId)

	DELETE FROM CorePatterns.SchemaAttributes WHERE SchemaEntityId=@entityId
	
	DELETE FROM CorePatterns.SchemaAttributes WHERE LookupEntityId=@entityId	

	DELETE FROM CorePatterns.Operations WHERE SchemaEntityId=@entityId
	
	DELETE FROM CorePatterns.SchemaEntities WHERE Id=@entityId
END 
GO 

-- [Identity].[AuthorizableResourcePermissions]

declare @entityId uniqueidentifier

SELECT @entityId = Id FROM CorePatterns.SchemaEntities WHERE ModuleName='Identity' AND [Key]='AuthorizableResourcePermissions'

IF (ISNULL(@entityId, 'C3A1F680-8705-4951-81A1-C3DBD255903D') <> 'C3A1F680-8705-4951-81A1-C3DBD255903D') 
BEGIN
	DELETE FROM QueryBuilder.ListModels WHERE MainEntityId = @entityId	

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE SchemaEntityId=@entityId

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE TargetId IN (SELECT Id FROM CorePatterns.SchemaAttributes WHERE SchemaEntityId=@entityId)

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE AttributeId IN (SELECT Id FROM CorePatterns.SchemaAttributes WHERE SchemaEntityId=@entityId)

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE AttributeId IN (SELECT Id FROM CorePatterns.SchemaAttributes WHERE LookupEntityId=@entityId)

	DELETE FROM CorePatterns.SchemaAttributes WHERE SchemaEntityId=@entityId
	
	DELETE FROM CorePatterns.SchemaAttributes WHERE LookupEntityId=@entityId	

	DELETE FROM CorePatterns.Operations WHERE SchemaEntityId=@entityId
	
	DELETE FROM CorePatterns.SchemaEntities WHERE Id=@entityId
END 
GO 

-- [Identity].[AuthorizableResources]

declare @entityId uniqueidentifier

SELECT @entityId = Id FROM CorePatterns.SchemaEntities WHERE ModuleName='Identity' AND [Key]='AuthorizableResources'

IF (ISNULL(@entityId, 'C3A1F680-8705-4951-81A1-C3DBD255903D') <> 'C3A1F680-8705-4951-81A1-C3DBD255903D') 
BEGIN
	DELETE FROM QueryBuilder.ListModels WHERE MainEntityId = @entityId	

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE SchemaEntityId=@entityId

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE TargetId IN (SELECT Id FROM CorePatterns.SchemaAttributes WHERE SchemaEntityId=@entityId)

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE AttributeId IN (SELECT Id FROM CorePatterns.SchemaAttributes WHERE SchemaEntityId=@entityId)

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE AttributeId IN (SELECT Id FROM CorePatterns.SchemaAttributes WHERE LookupEntityId=@entityId)

	DELETE FROM CorePatterns.SchemaAttributes WHERE SchemaEntityId=@entityId
	
	DELETE FROM CorePatterns.SchemaAttributes WHERE LookupEntityId=@entityId	

	DELETE FROM CorePatterns.Operations WHERE SchemaEntityId=@entityId
	
	DELETE FROM CorePatterns.SchemaEntities WHERE Id=@entityId
END 
GO 

-- [Identity].[Authorizations]

declare @entityId uniqueidentifier

SELECT @entityId = Id FROM CorePatterns.SchemaEntities WHERE ModuleName='Identity' AND [Key]='Authorizations'

IF (ISNULL(@entityId, 'C3A1F680-8705-4951-81A1-C3DBD255903D') <> 'C3A1F680-8705-4951-81A1-C3DBD255903D') 
BEGIN
	DELETE FROM QueryBuilder.ListModels WHERE MainEntityId = @entityId	

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE SchemaEntityId=@entityId

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE TargetId IN (SELECT Id FROM CorePatterns.SchemaAttributes WHERE SchemaEntityId=@entityId)

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE AttributeId IN (SELECT Id FROM CorePatterns.SchemaAttributes WHERE SchemaEntityId=@entityId)

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE AttributeId IN (SELECT Id FROM CorePatterns.SchemaAttributes WHERE LookupEntityId=@entityId)

	DELETE FROM CorePatterns.SchemaAttributes WHERE SchemaEntityId=@entityId
	
	DELETE FROM CorePatterns.SchemaAttributes WHERE LookupEntityId=@entityId	

	DELETE FROM CorePatterns.Operations WHERE SchemaEntityId=@entityId
	
	DELETE FROM CorePatterns.SchemaEntities WHERE Id=@entityId
END 
GO 

-- [Identity].[GroupRoles]

declare @entityId uniqueidentifier

SELECT @entityId = Id FROM CorePatterns.SchemaEntities WHERE ModuleName='Identity' AND [Key]='GroupRoles'

IF (ISNULL(@entityId, 'C3A1F680-8705-4951-81A1-C3DBD255903D') <> 'C3A1F680-8705-4951-81A1-C3DBD255903D') 
BEGIN
	DELETE FROM QueryBuilder.ListModels WHERE MainEntityId = @entityId	

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE SchemaEntityId=@entityId

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE TargetId IN (SELECT Id FROM CorePatterns.SchemaAttributes WHERE SchemaEntityId=@entityId)

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE AttributeId IN (SELECT Id FROM CorePatterns.SchemaAttributes WHERE SchemaEntityId=@entityId)

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE AttributeId IN (SELECT Id FROM CorePatterns.SchemaAttributes WHERE LookupEntityId=@entityId)

	DELETE FROM CorePatterns.SchemaAttributes WHERE SchemaEntityId=@entityId
	
	DELETE FROM CorePatterns.SchemaAttributes WHERE LookupEntityId=@entityId	

	DELETE FROM CorePatterns.Operations WHERE SchemaEntityId=@entityId
	
	DELETE FROM CorePatterns.SchemaEntities WHERE Id=@entityId
END 
GO

-- [Identity].[RoleGroups]

declare @entityId uniqueidentifier

SELECT @entityId = Id FROM CorePatterns.SchemaEntities WHERE ModuleName='Identity' AND [Key]='RoleGroups'

IF (ISNULL(@entityId, 'C3A1F680-8705-4951-81A1-C3DBD255903D') <> 'C3A1F680-8705-4951-81A1-C3DBD255903D') 
BEGIN
	DELETE FROM QueryBuilder.ListModels WHERE MainEntityId = @entityId	

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE SchemaEntityId=@entityId

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE TargetId IN (SELECT Id FROM CorePatterns.SchemaAttributes WHERE SchemaEntityId=@entityId)

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE AttributeId IN (SELECT Id FROM CorePatterns.SchemaAttributes WHERE SchemaEntityId=@entityId)

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE AttributeId IN (SELECT Id FROM CorePatterns.SchemaAttributes WHERE LookupEntityId=@entityId)

	DELETE FROM CorePatterns.SchemaAttributes WHERE SchemaEntityId=@entityId
	
	DELETE FROM CorePatterns.SchemaAttributes WHERE LookupEntityId=@entityId	

	DELETE FROM CorePatterns.Operations WHERE SchemaEntityId=@entityId
	
	DELETE FROM CorePatterns.SchemaEntities WHERE Id=@entityId
END 
GO

-- [Identity].[SubGroups]

declare @entityId uniqueidentifier

SELECT @entityId = Id FROM CorePatterns.SchemaEntities WHERE ModuleName='Identity' AND [Key]='SubGroups'

IF (ISNULL(@entityId, 'C3A1F680-8705-4951-81A1-C3DBD255903D') <> 'C3A1F680-8705-4951-81A1-C3DBD255903D') 
BEGIN
	DELETE FROM QueryBuilder.ListModels WHERE MainEntityId = @entityId	

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE SchemaEntityId=@entityId

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE TargetId IN (SELECT Id FROM CorePatterns.SchemaAttributes WHERE SchemaEntityId=@entityId)

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE AttributeId IN (SELECT Id FROM CorePatterns.SchemaAttributes WHERE SchemaEntityId=@entityId)

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE AttributeId IN (SELECT Id FROM CorePatterns.SchemaAttributes WHERE LookupEntityId=@entityId)

	DELETE FROM CorePatterns.SchemaAttributes WHERE SchemaEntityId=@entityId
	
	DELETE FROM CorePatterns.SchemaAttributes WHERE LookupEntityId=@entityId	

	DELETE FROM CorePatterns.Operations WHERE SchemaEntityId=@entityId
	
	DELETE FROM CorePatterns.SchemaEntities WHERE Id=@entityId
END 
GO

-- [Identity].[UserGroups]

declare @entityId uniqueidentifier

SELECT @entityId = Id FROM CorePatterns.SchemaEntities WHERE ModuleName='Identity' AND [Key]='UserGroups'

IF (ISNULL(@entityId, 'C3A1F680-8705-4951-81A1-C3DBD255903D') <> 'C3A1F680-8705-4951-81A1-C3DBD255903D') 
BEGIN
	DELETE FROM QueryBuilder.ListModels WHERE MainEntityId = @entityId	

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE SchemaEntityId=@entityId

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE TargetId IN (SELECT Id FROM CorePatterns.SchemaAttributes WHERE SchemaEntityId=@entityId)

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE AttributeId IN (SELECT Id FROM CorePatterns.SchemaAttributes WHERE SchemaEntityId=@entityId)

	DELETE FROM CorePatterns.SchemaEntitiesAssociations WHERE AttributeId IN (SELECT Id FROM CorePatterns.SchemaAttributes WHERE LookupEntityId=@entityId)

	DELETE FROM CorePatterns.SchemaAttributes WHERE SchemaEntityId=@entityId
	
	DELETE FROM CorePatterns.SchemaAttributes WHERE LookupEntityId=@entityId	

	DELETE FROM CorePatterns.Operations WHERE SchemaEntityId=@entityId
	
	DELETE FROM CorePatterns.SchemaEntities WHERE Id=@entityId
END 
GO


------------------------------------------------------
-- Schema Entities and Attributes : Add new
------------------------------------------------------

-- CompanyAccessRestriction

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaEntities] WHERE Id = 'f3ca66b7-4c22-4828-8507-c88920a7d3ea')
BEGIN
    INSERT INTO [CorePatterns].[SchemaEntities] ([Id], [Key], [ModuleName], [Title], [EntityTypeId], [EntityName], [Database], [BaseEntityId], [IsGenericExtension], [LockingEnabled], [HasSequenceAttribute], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [IsRestrictable]) 
    VALUES ('f3ca66b7-4c22-4828-8507-c88920a7d3ea', 'CompanyAccessRestrictions', 'Identity', '{"Values":[{ "Culture":"es","Data":"Company Access Restriction"},{ "Culture":"pt","Data":"Company Access Restriction"},{ "Culture":"en","Data":"Company Access Restriction"}]}', (SELECT Id from [CorePatterns].[SchemaEntityTypes] WHERE Id = 'd4ed5adc-1618-4e79-9263-e02e3dd6fc79'), 'Primavera.Identity.Domain.CompanyAccessRestriction', 'Enterprise', 'cfceb0dc-99f3-455d-9b6d-38bb7bffa159', 0, 0, 0, 1, 0, 1, 'COMPANYACCESSRESTRICTIONS.IDENTITY', 0 )
END
GO

-- SchemaEntityPatterns for : CompanyAccessRestriction

-- RestrictedGroup

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaEntities] WHERE Id = 'ec550b23-3852-4867-a35b-b75ef0a04895')
BEGIN
    INSERT INTO [CorePatterns].[SchemaEntities] ([Id], [Key], [ModuleName], [Title], [EntityTypeId], [EntityName], [Database], [BaseEntityId], [IsGenericExtension], [LockingEnabled], [HasSequenceAttribute], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [IsRestrictable]) 
    VALUES ('ec550b23-3852-4867-a35b-b75ef0a04895', 'RestrictedGroups', 'Identity', '{"Values":[{ "Culture":"es","Data":"Restricted Group"},{ "Culture":"pt","Data":"Restricted Group"},{ "Culture":"en","Data":"Restricted Group"}]}', (SELECT Id from [CorePatterns].[SchemaEntityTypes] WHERE Id = 'd4ed5adc-1618-4e79-9263-e02e3dd6fc79'), 'Primavera.Identity.Domain.RestrictedGroup', 'Enterprise', NULL, 0, 0, 0, 1, 0, 1, 'RESTRICTEDGROUPS.IDENTITY', 0 )
END
GO

-- SchemaEntityPatterns for : RestrictedGroup

-- RowLevelSecurityClaim

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaEntities] WHERE Id = 'b001ddb4-d863-4ae3-b2b0-e343bb7f1313')
BEGIN
    INSERT INTO [CorePatterns].[SchemaEntities] ([Id], [Key], [ModuleName], [Title], [EntityTypeId], [EntityName], [Database], [BaseEntityId], [IsGenericExtension], [LockingEnabled], [HasSequenceAttribute], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [IsRestrictable]) 
    VALUES ('b001ddb4-d863-4ae3-b2b0-e343bb7f1313', 'RowLevelSecurityClaims', 'Identity', '{"Values":[{ "Culture":"es","Data":"Row Level Security Claim"},{ "Culture":"pt","Data":"Row Level Security Claim"},{ "Culture":"en","Data":"Row Level Security Claim"}]}', (SELECT Id from [CorePatterns].[SchemaEntityTypes] WHERE Id = 'd4ed5adc-1618-4e79-9263-e02e3dd6fc79'), 'Primavera.Identity.Domain.RowLevelSecurityClaim', 'Enterprise', NULL, 0, 0, 0, 1, 0, 1, 'ROWLEVELSECURITYCLAIMS.IDENTITY', 0 )
END
GO

-- SchemaEntityPatterns for : RowLevelSecurityClaim

-- UserAccessClaim

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaEntities] WHERE Id = '299712c3-be35-4461-95ae-1a334f922784')
BEGIN
    INSERT INTO [CorePatterns].[SchemaEntities] ([Id], [Key], [ModuleName], [Title], [EntityTypeId], [EntityName], [Database], [BaseEntityId], [IsGenericExtension], [LockingEnabled], [HasSequenceAttribute], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [IsRestrictable]) 
    VALUES ('299712c3-be35-4461-95ae-1a334f922784', 'UserAccessClaims', 'Identity', '{"Values":[{ "Culture":"es","Data":"User Access Claim"},{ "Culture":"pt","Data":"User Access Claim"},{ "Culture":"en","Data":"User Access Claim"}]}', (SELECT Id from [CorePatterns].[SchemaEntityTypes] WHERE Id = 'd4ed5adc-1618-4e79-9263-e02e3dd6fc79'), 'Primavera.Identity.Domain.UserAccessClaim', 'Enterprise', NULL, 0, 0, 0, 1, 0, 1, 'USERACCESSCLAIMS.IDENTITY', 0 )
END
GO

-- SchemaEntityPatterns for : UserAccessClaim

-- [Entity Extensions]
	
-- Entity Extension : CompanyAccessRestriction

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaEntityExtensions] WHERE BaseEntityId = 'cfceb0dc-99f3-455d-9b6d-38bb7bffa159' AND ExtensionEntityId = 'f3ca66b7-4c22-4828-8507-c88920a7d3ea')
BEGIN
    INSERT INTO [CorePatterns].[SchemaEntityExtensions]([Id], [BaseEntityId], [ExtensionEntityId], [ServiceInterfaceName], [ControllerName], [NaturalKey], [DisplayOrder], [IsRequired], [IsSystemRequired], [IsActive], [IsDeleted], [IsSystem])
    VALUES ('3a9388ce-640b-48c3-8714-dd4b8a929698', 'cfceb0dc-99f3-455d-9b6d-38bb7bffa159', 'f3ca66b7-4c22-4828-8507-c88920a7d3ea', 'Primavera.Identity.Api.ICompanyAccessRestrictionsService, Primavera.Identity.Api', 'Primavera.Identity.Services.Controllers.IdentityCompanyAccessRestrictionsController, Primavera.Identity.Services.Controllers','cfceb0dc-99f3-455d-9b6d-38bb7bffa159.f3ca66b7-4c22-4828-8507-c88920a7d3ea', 0, 1, 1, 1, 0, 1)
END
GO

-- [Related Items]

-- CompanyAccessRestriction.Id

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '45416bbd-1e34-491d-888c-6b0444b46f75')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Id"},{ "Culture":"pt","Data":"Id"},{ "Culture":"en","Data":"Id"}]}', '45416bbd-1e34-491d-888c-6b0444b46f75', 'Id', 'UniqueIdentifier', 'False', 'False' , 1, 'f3ca66b7-4c22-4828-8507-c88920a7d3ea', 'True', 'True', 'False', 'True', 1, 0, 1, 'COMPANYACCESSRESTRICTIONS.IDENTITY.ID', NULL, 0, 'False', 0, 0)
END
GO

-- CompanyAccessRestriction.IsDraft

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'e99603be-30eb-44b1-a200-0774883f2ad6')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Draft"},{ "Culture":"pt","Data":"Draft"},{ "Culture":"en","Data":"Draft"}]}', 'e99603be-30eb-44b1-a200-0774883f2ad6', 'IsDraft', 'Boolean', 'False', 'False' , 1, 'f3ca66b7-4c22-4828-8507-c88920a7d3ea', 'True', 'True', 'False', 'True', 1, 0, 1, 'COMPANYACCESSRESTRICTIONS.IDENTITY.ISDRAFT', NULL, 0, 'False', 0, 0)
END
GO

-- CompanyAccessRestriction.CreatedBy

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '124f0292-2805-4c35-8fef-a3305a84c571')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Created By"},{ "Culture":"pt","Data":"Created By"},{ "Culture":"en","Data":"Created By"}]}', '124f0292-2805-4c35-8fef-a3305a84c571', 'CreatedBy', 'LongText', 'False', 'False' , 1, 'f3ca66b7-4c22-4828-8507-c88920a7d3ea', 'True', 'True', 'False', 'True', 1, 0, 1, 'COMPANYACCESSRESTRICTIONS.IDENTITY.CREATEDBY', NULL, 0, 'False', 0, 0)
END
GO

-- CompanyAccessRestriction.CreatedOn

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '6d491268-6e0e-4943-adb7-ae4dbc21723f')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Created On"},{ "Culture":"pt","Data":"Created On"},{ "Culture":"en","Data":"Created On"}]}', '6d491268-6e0e-4943-adb7-ae4dbc21723f', 'CreatedOn', 'Datetime', 'False', 'False' , 1, 'f3ca66b7-4c22-4828-8507-c88920a7d3ea', 'True', 'True', 'False', 'True', 1, 0, 1, 'COMPANYACCESSRESTRICTIONS.IDENTITY.CREATEDON', NULL, 0, 'False', 0, 0)
END
GO

-- CompanyAccessRestriction.ModifiedBy

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '26630ead-450c-4492-b7a5-c1d3fbff251c')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Modified By"},{ "Culture":"pt","Data":"Modified By"},{ "Culture":"en","Data":"Modified By"}]}', '26630ead-450c-4492-b7a5-c1d3fbff251c', 'ModifiedBy', 'LongText', 'False', 'False' , 1, 'f3ca66b7-4c22-4828-8507-c88920a7d3ea', 'True', 'True', 'False', 'True', 1, 0, 1, 'COMPANYACCESSRESTRICTIONS.IDENTITY.MODIFIEDBY', NULL, 0, 'False', 0, 0)
END
GO

-- CompanyAccessRestriction.ModifiedOn

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '17872e0e-3b34-411e-85f3-c052973074ed')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Modified On"},{ "Culture":"pt","Data":"Modified On"},{ "Culture":"en","Data":"Modified On"}]}', '17872e0e-3b34-411e-85f3-c052973074ed', 'ModifiedOn', 'Datetime', 'False', 'False' , 1, 'f3ca66b7-4c22-4828-8507-c88920a7d3ea', 'True', 'True', 'False', 'True', 1, 0, 1, 'COMPANYACCESSRESTRICTIONS.IDENTITY.MODIFIEDON', NULL, 0, 'False', 0, 0)
END
GO

-- CompanyAccessRestriction.IsActive

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'f784b0e7-2a05-4da3-acfc-933daa8e5acf')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Active"},{ "Culture":"pt","Data":"Active"},{ "Culture":"en","Data":"Active"}]}', 'f784b0e7-2a05-4da3-acfc-933daa8e5acf', 'IsActive', 'Boolean', 'False', 'False' , 1, 'f3ca66b7-4c22-4828-8507-c88920a7d3ea', 'True', 'True', 'False', 'True', 1, 0, 1, 'COMPANYACCESSRESTRICTIONS.IDENTITY.ISACTIVE', NULL, 0, 'False', 0, 0)
END
GO

-- CompanyAccessRestriction.IsDeleted

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '06f9af7a-0d55-4883-a1f1-55a73ab8e26a')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Deleted"},{ "Culture":"pt","Data":"Deleted"},{ "Culture":"en","Data":"Deleted"}]}', '06f9af7a-0d55-4883-a1f1-55a73ab8e26a', 'IsDeleted', 'Boolean', 'False', 'False' , 1, 'f3ca66b7-4c22-4828-8507-c88920a7d3ea', 'True', 'True', 'True', 'True', 1, 0, 1, 'COMPANYACCESSRESTRICTIONS.IDENTITY.ISDELETED', NULL, 0, 'False', 0, 0)
END
GO

-- CompanyAccessRestriction.IsSystem

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'f345054c-85de-4002-88c0-6fe93de090a5')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"System"},{ "Culture":"pt","Data":"System"},{ "Culture":"en","Data":"System"}]}', 'f345054c-85de-4002-88c0-6fe93de090a5', 'IsSystem', 'Boolean', 'False', 'False' , 1, 'f3ca66b7-4c22-4828-8507-c88920a7d3ea', 'True', 'True', 'False', 'True', 1, 0, 1, 'COMPANYACCESSRESTRICTIONS.IDENTITY.ISSYSTEM', NULL, 0, 'False', 0, 0)
END
GO

-- CompanyAccessRestriction.RestrictedGroups

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '008e8e32-d71e-4cfb-ba22-d399fd56f992')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Restricted Groups"},{ "Culture":"pt","Data":"Restricted Groups"},{ "Culture":"en","Data":"Restricted Groups"}]}', '008e8e32-d71e-4cfb-ba22-d399fd56f992', 'RestrictedGroups', 'List', 'False', 'False' , 1, 'f3ca66b7-4c22-4828-8507-c88920a7d3ea', 'False', 'True', 'False', 'False', 1, 0, 1, 'COMPANYACCESSRESTRICTIONS.IDENTITY.RESTRICTEDGROUPS', 'ec550b23-3852-4867-a35b-b75ef0a04895', 0, 'False', 1, 0)
END
GO

-- CompanyAccessRestriction.RestrictedGroups

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaEntitiesAssociations] WHERE [Id] = 'b9ef70ba-6da2-511c-3c21-ce59a7b1b33c')
BEGIN
    INSERT INTO [CorePatterns].[SchemaEntitiesAssociations] ([Id], [SchemaEntityId], [TargetId], [AttributeId], [IsComposition], [IsManyToMany], [IsActive], [IsDeleted], [IsSystem])
    VALUES ('b9ef70ba-6da2-511c-3c21-ce59a7b1b33c', 'f3ca66b7-4c22-4828-8507-c88920a7d3ea', 'ec550b23-3852-4867-a35b-b75ef0a04895', '008e8e32-d71e-4cfb-ba22-d399fd56f992', 1, 0, 1, 0, 1)
END
GO


IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'f3ca66b7-4c22-4828-8507-c88920a7d3ea')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Company Access Restriction"}]}', 'f3ca66b7-4c22-4828-8507-c88920a7d3ea', 'CompanyAccessRestriction', 'View', 0, 0 , 1, 'ec550b23-3852-4867-a35b-b75ef0a04895', 1, 1, 0, 0, 1, 0, 1, 'RestrictedGroups.Identity.CompanyAccessRestriction', 'f3ca66b7-4c22-4828-8507-c88920a7d3ea', 0, 0, 0, 0)

END
GO

-- RestrictedGroup.Id

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'd92e2798-b052-4c4e-a4f8-fd2d3c282951')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Id"},{ "Culture":"pt","Data":"Id"},{ "Culture":"en","Data":"Id"}]}', 'd92e2798-b052-4c4e-a4f8-fd2d3c282951', 'Id', 'UniqueIdentifier', 'False', 'False' , 1, 'ec550b23-3852-4867-a35b-b75ef0a04895', 'True', 'True', 'False', 'True', 1, 0, 1, 'RESTRICTEDGROUPS.IDENTITY.ID', NULL, 0, 'False', 0, 0)
END
GO

-- RestrictedGroup.Index

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '52a969a7-4854-4ccf-bb99-1ab48ffc1dd7')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Index"},{ "Culture":"pt","Data":"Index"},{ "Culture":"en","Data":"Index"}]}', '52a969a7-4854-4ccf-bb99-1ab48ffc1dd7', 'Index', 'Number', 'False', 'False' , 1, 'ec550b23-3852-4867-a35b-b75ef0a04895', 'True', 'True', 'False', 'True', 1, 0, 1, 'RESTRICTEDGROUPS.IDENTITY.INDEX', NULL, 0, 'False', 0, 0)
END
GO

-- RestrictedGroup.CreatedBy

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '5143880b-b32c-40e7-9d33-fbadec7e7a1d')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Created By"},{ "Culture":"pt","Data":"Created By"},{ "Culture":"en","Data":"Created By"}]}', '5143880b-b32c-40e7-9d33-fbadec7e7a1d', 'CreatedBy', 'LongText', 'False', 'False' , 1, 'ec550b23-3852-4867-a35b-b75ef0a04895', 'True', 'True', 'False', 'True', 1, 0, 1, 'RESTRICTEDGROUPS.IDENTITY.CREATEDBY', NULL, 0, 'False', 0, 0)
END
GO

-- RestrictedGroup.CreatedOn

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '23dd0198-0b1a-4d20-9396-5d59d8209f8a')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Created On"},{ "Culture":"pt","Data":"Created On"},{ "Culture":"en","Data":"Created On"}]}', '23dd0198-0b1a-4d20-9396-5d59d8209f8a', 'CreatedOn', 'Datetime', 'False', 'False' , 1, 'ec550b23-3852-4867-a35b-b75ef0a04895', 'True', 'True', 'False', 'True', 1, 0, 1, 'RESTRICTEDGROUPS.IDENTITY.CREATEDON', NULL, 0, 'False', 0, 0)
END
GO

-- RestrictedGroup.ModifiedBy

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'fbd42e40-4ea9-406e-8573-d09b6dba4167')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Modified By"},{ "Culture":"pt","Data":"Modified By"},{ "Culture":"en","Data":"Modified By"}]}', 'fbd42e40-4ea9-406e-8573-d09b6dba4167', 'ModifiedBy', 'LongText', 'False', 'False' , 1, 'ec550b23-3852-4867-a35b-b75ef0a04895', 'True', 'True', 'False', 'True', 1, 0, 1, 'RESTRICTEDGROUPS.IDENTITY.MODIFIEDBY', NULL, 0, 'False', 0, 0)
END
GO

-- RestrictedGroup.ModifiedOn

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '7d1cfadd-1c68-4bd8-8eda-caab6c8708db')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Modified On"},{ "Culture":"pt","Data":"Modified On"},{ "Culture":"en","Data":"Modified On"}]}', '7d1cfadd-1c68-4bd8-8eda-caab6c8708db', 'ModifiedOn', 'Datetime', 'False', 'False' , 1, 'ec550b23-3852-4867-a35b-b75ef0a04895', 'True', 'True', 'False', 'True', 1, 0, 1, 'RESTRICTEDGROUPS.IDENTITY.MODIFIEDON', NULL, 0, 'False', 0, 0)
END
GO

-- RestrictedGroup.IsActive

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '85dff7ce-028d-4c1a-8e3f-4a293d64f673')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Active"},{ "Culture":"pt","Data":"Active"},{ "Culture":"en","Data":"Active"}]}', '85dff7ce-028d-4c1a-8e3f-4a293d64f673', 'IsActive', 'Boolean', 'False', 'False' , 1, 'ec550b23-3852-4867-a35b-b75ef0a04895', 'True', 'True', 'False', 'True', 1, 0, 1, 'RESTRICTEDGROUPS.IDENTITY.ISACTIVE', NULL, 0, 'False', 0, 0)
END
GO

-- RestrictedGroup.IsDeleted

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '98b71665-6f11-41a2-b502-d76bb8ce264f')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Deleted"},{ "Culture":"pt","Data":"Deleted"},{ "Culture":"en","Data":"Deleted"}]}', '98b71665-6f11-41a2-b502-d76bb8ce264f', 'IsDeleted', 'Boolean', 'False', 'False' , 1, 'ec550b23-3852-4867-a35b-b75ef0a04895', 'True', 'True', 'True', 'True', 1, 0, 1, 'RESTRICTEDGROUPS.IDENTITY.ISDELETED', NULL, 0, 'False', 0, 0)
END
GO

-- RestrictedGroup.IsSystem

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'b541aff9-7ac8-43e8-b925-00bc6484f273')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"System"},{ "Culture":"pt","Data":"System"},{ "Culture":"en","Data":"System"}]}', 'b541aff9-7ac8-43e8-b925-00bc6484f273', 'IsSystem', 'Boolean', 'False', 'False' , 1, 'ec550b23-3852-4867-a35b-b75ef0a04895', 'True', 'True', 'False', 'True', 1, 0, 1, 'RESTRICTEDGROUPS.IDENTITY.ISSYSTEM', NULL, 0, 'False', 0, 0)
END
GO

-- RestrictedGroup.Group

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'f01eb2ee-952c-4900-a88c-264891ada1ec')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Group"},{ "Culture":"pt","Data":"Group"},{ "Culture":"en","Data":"Group"}]}', 'f01eb2ee-952c-4900-a88c-264891ada1ec', 'Group', 'View', 'False', 'False' , 1, 'ec550b23-3852-4867-a35b-b75ef0a04895', 'True', 'True', 'False', 'False', 1, 0, 1, 'RESTRICTEDGROUPS.IDENTITY.GROUP', '49a1ddb2-f031-4cd2-870a-390ef0db206c', 0, 'False', 1, 0)
END
GO

-- RestrictedGroup.Group

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaEntitiesAssociations] WHERE [Id] = 'fb2b3242-b963-9f20-929a-83f9fed6744f')
BEGIN
    INSERT INTO [CorePatterns].[SchemaEntitiesAssociations] ([Id], [SchemaEntityId], [TargetId], [AttributeId], [IsComposition], [IsManyToMany], [IsActive], [IsDeleted], [IsSystem])
    VALUES ('fb2b3242-b963-9f20-929a-83f9fed6744f', 'ec550b23-3852-4867-a35b-b75ef0a04895', '49a1ddb2-f031-4cd2-870a-390ef0db206c', 'f01eb2ee-952c-4900-a88c-264891ada1ec', 0, 0, 1, 0, 1)
END
GO

-- RowLevelSecurityClaim.Id

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'e0e55b06-2dc5-4cf0-bd20-ce9704954f87')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Id"},{ "Culture":"pt","Data":"Id"},{ "Culture":"en","Data":"Id"}]}', 'e0e55b06-2dc5-4cf0-bd20-ce9704954f87', 'Id', 'UniqueIdentifier', 'False', 'False' , 1, 'b001ddb4-d863-4ae3-b2b0-e343bb7f1313', 'True', 'True', 'False', 'True', 1, 0, 1, 'ROWLEVELSECURITYCLAIMS.IDENTITY.ID', NULL, 0, 'False', 0, 0)
END
GO

-- RowLevelSecurityClaim.NaturalKey

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '28f90314-4e20-40d7-9e3e-3ecbaf87aafb')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Row Level Security Claim"},{ "Culture":"pt","Data":"Row Level Security Claim"},{ "Culture":"en","Data":"Row Level Security Claim"}]}', '28f90314-4e20-40d7-9e3e-3ecbaf87aafb', 'NaturalKey', 'LongText', 'False', 'False' , 1, 'b001ddb4-d863-4ae3-b2b0-e343bb7f1313', 'True', 'True', 'False', 'True', 1, 0, 1, 'ROWLEVELSECURITYCLAIMS.IDENTITY.NATURALKEY', NULL, 0, 'False', 0, 0)
END
GO

-- RowLevelSecurityClaim.IsDraft

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '58814d6a-7cca-413b-a16e-938a0a549d4a')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Draft"},{ "Culture":"pt","Data":"Draft"},{ "Culture":"en","Data":"Draft"}]}', '58814d6a-7cca-413b-a16e-938a0a549d4a', 'IsDraft', 'Boolean', 'False', 'False' , 1, 'b001ddb4-d863-4ae3-b2b0-e343bb7f1313', 'True', 'True', 'False', 'True', 1, 0, 1, 'ROWLEVELSECURITYCLAIMS.IDENTITY.ISDRAFT', NULL, 0, 'False', 0, 0)
END
GO

-- RowLevelSecurityClaim.CreatedBy

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'f2b25355-8b19-4230-aca0-f22a0ec8d45c')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Created By"},{ "Culture":"pt","Data":"Created By"},{ "Culture":"en","Data":"Created By"}]}', 'f2b25355-8b19-4230-aca0-f22a0ec8d45c', 'CreatedBy', 'LongText', 'False', 'False' , 1, 'b001ddb4-d863-4ae3-b2b0-e343bb7f1313', 'True', 'True', 'False', 'True', 1, 0, 1, 'ROWLEVELSECURITYCLAIMS.IDENTITY.CREATEDBY', NULL, 0, 'False', 0, 0)
END
GO

-- RowLevelSecurityClaim.CreatedOn

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '2c32a14d-fe74-4943-b109-20c30dcc4d5b')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Created On"},{ "Culture":"pt","Data":"Created On"},{ "Culture":"en","Data":"Created On"}]}', '2c32a14d-fe74-4943-b109-20c30dcc4d5b', 'CreatedOn', 'Datetime', 'False', 'False' , 1, 'b001ddb4-d863-4ae3-b2b0-e343bb7f1313', 'True', 'True', 'False', 'True', 1, 0, 1, 'ROWLEVELSECURITYCLAIMS.IDENTITY.CREATEDON', NULL, 0, 'False', 0, 0)
END
GO

-- RowLevelSecurityClaim.ModifiedBy

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '82a693a0-fb97-4d5b-82cf-345b36e429ef')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Modified By"},{ "Culture":"pt","Data":"Modified By"},{ "Culture":"en","Data":"Modified By"}]}', '82a693a0-fb97-4d5b-82cf-345b36e429ef', 'ModifiedBy', 'LongText', 'False', 'False' , 1, 'b001ddb4-d863-4ae3-b2b0-e343bb7f1313', 'True', 'True', 'False', 'True', 1, 0, 1, 'ROWLEVELSECURITYCLAIMS.IDENTITY.MODIFIEDBY', NULL, 0, 'False', 0, 0)
END
GO

-- RowLevelSecurityClaim.ModifiedOn

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '77a60f21-55a7-4197-8ac6-ac81bacbb93f')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Modified On"},{ "Culture":"pt","Data":"Modified On"},{ "Culture":"en","Data":"Modified On"}]}', '77a60f21-55a7-4197-8ac6-ac81bacbb93f', 'ModifiedOn', 'Datetime', 'False', 'False' , 1, 'b001ddb4-d863-4ae3-b2b0-e343bb7f1313', 'True', 'True', 'False', 'True', 1, 0, 1, 'ROWLEVELSECURITYCLAIMS.IDENTITY.MODIFIEDON', NULL, 0, 'False', 0, 0)
END
GO

-- RowLevelSecurityClaim.IsActive

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'b9cecaee-d674-417d-be9c-0ce920ca3842')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Active"},{ "Culture":"pt","Data":"Active"},{ "Culture":"en","Data":"Active"}]}', 'b9cecaee-d674-417d-be9c-0ce920ca3842', 'IsActive', 'Boolean', 'False', 'False' , 1, 'b001ddb4-d863-4ae3-b2b0-e343bb7f1313', 'True', 'True', 'False', 'True', 1, 0, 1, 'ROWLEVELSECURITYCLAIMS.IDENTITY.ISACTIVE', NULL, 0, 'False', 0, 0)
END
GO

-- RowLevelSecurityClaim.IsDeleted

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'bcc6167d-1cf7-4304-ac01-22068eabeba2')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Deleted"},{ "Culture":"pt","Data":"Deleted"},{ "Culture":"en","Data":"Deleted"}]}', 'bcc6167d-1cf7-4304-ac01-22068eabeba2', 'IsDeleted', 'Boolean', 'False', 'False' , 1, 'b001ddb4-d863-4ae3-b2b0-e343bb7f1313', 'True', 'True', 'True', 'True', 1, 0, 1, 'ROWLEVELSECURITYCLAIMS.IDENTITY.ISDELETED', NULL, 0, 'False', 0, 0)
END
GO

-- RowLevelSecurityClaim.IsSystem

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '66f1409b-e887-48ef-8013-83d6c8058fd1')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"System"},{ "Culture":"pt","Data":"System"},{ "Culture":"en","Data":"System"}]}', '66f1409b-e887-48ef-8013-83d6c8058fd1', 'IsSystem', 'Boolean', 'False', 'False' , 1, 'b001ddb4-d863-4ae3-b2b0-e343bb7f1313', 'True', 'True', 'False', 'True', 1, 0, 1, 'ROWLEVELSECURITYCLAIMS.IDENTITY.ISSYSTEM', NULL, 0, 'False', 0, 0)
END
GO

-- RowLevelSecurityClaim.AccessClaim

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'd4e4e72e-d8d0-4cbf-a794-0405988559ff')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Access Claim"},{ "Culture":"pt","Data":"Access Claim"},{ "Culture":"en","Data":"Access Claim"}]}', 'd4e4e72e-d8d0-4cbf-a794-0405988559ff', 'AccessClaim', 'AutoNumber', 'True', 'False' , 1, 'b001ddb4-d863-4ae3-b2b0-e343bb7f1313', 'True', 'True', 'False', 'False', 1, 0, 1, 'ROWLEVELSECURITYCLAIMS.IDENTITY.ACCESSCLAIM', NULL, 0, 'False', 1, 0)
END
GO

-- RowLevelSecurityClaim.SchemaEntity

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '6cb9d98c-23bd-44ac-a0e9-706d3c7c21af')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Schema Entity"},{ "Culture":"pt","Data":"Schema Entity"},{ "Culture":"en","Data":"Schema Entity"}]}', '6cb9d98c-23bd-44ac-a0e9-706d3c7c21af', 'SchemaEntity', 'View', 'False', 'False' , 1, 'b001ddb4-d863-4ae3-b2b0-e343bb7f1313', 'True', 'True', 'False', 'False', 1, 0, 1, 'ROWLEVELSECURITYCLAIMS.IDENTITY.SCHEMAENTITY', 'f5ce031f-fa96-4c2c-8d44-d71f621e9232', 0, 'False', 1, 0)
END
GO

-- RowLevelSecurityClaim.SchemaEntity

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaEntitiesAssociations] WHERE [Id] = 'f2644d78-24bc-7bde-0b21-1c145a1669b5')
BEGIN
    INSERT INTO [CorePatterns].[SchemaEntitiesAssociations] ([Id], [SchemaEntityId], [TargetId], [AttributeId], [IsComposition], [IsManyToMany], [IsActive], [IsDeleted], [IsSystem])
    VALUES ('f2644d78-24bc-7bde-0b21-1c145a1669b5', 'b001ddb4-d863-4ae3-b2b0-e343bb7f1313', 'f5ce031f-fa96-4c2c-8d44-d71f621e9232', '6cb9d98c-23bd-44ac-a0e9-706d3c7c21af', 0, 0, 1, 0, 1)
END
GO

-- RowLevelSecurityClaim.RecordId

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'aa70c059-a7e3-4d61-add5-ea1cb3b8dee4')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Record Id"},{ "Culture":"pt","Data":"Record Id"},{ "Culture":"en","Data":"Record Id"}]}', 'aa70c059-a7e3-4d61-add5-ea1cb3b8dee4', 'RecordId', 'UniqueIdentifier', 'False', 'False' , 1, 'b001ddb4-d863-4ae3-b2b0-e343bb7f1313', 'True', 'True', 'False', 'False', 1, 0, 1, 'ROWLEVELSECURITYCLAIMS.IDENTITY.RECORDID', NULL, 0, 'False', 1, 0)
END
GO

-- UserAccessClaim.Id

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '95c89e81-8442-44b9-a9fd-b24da0b45eb1')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Id"},{ "Culture":"pt","Data":"Id"},{ "Culture":"en","Data":"Id"}]}', '95c89e81-8442-44b9-a9fd-b24da0b45eb1', 'Id', 'UniqueIdentifier', 'False', 'False' , 1, '299712c3-be35-4461-95ae-1a334f922784', 'True', 'True', 'False', 'True', 1, 0, 1, 'USERACCESSCLAIMS.IDENTITY.ID', NULL, 0, 'False', 0, 0)
END
GO

-- UserAccessClaim.NaturalKey

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '18dcfcaf-7b1e-49be-82d3-fddb91fede86')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"User Access Claim"},{ "Culture":"pt","Data":"User Access Claim"},{ "Culture":"en","Data":"User Access Claim"}]}', '18dcfcaf-7b1e-49be-82d3-fddb91fede86', 'NaturalKey', 'LongText', 'False', 'False' , 1, '299712c3-be35-4461-95ae-1a334f922784', 'True', 'True', 'False', 'True', 1, 0, 1, 'USERACCESSCLAIMS.IDENTITY.NATURALKEY', NULL, 0, 'False', 0, 0)
END
GO

-- UserAccessClaim.IsDraft

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '1f53c3c7-412d-40fb-826e-6b3ed5779e2b')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Draft"},{ "Culture":"pt","Data":"Draft"},{ "Culture":"en","Data":"Draft"}]}', '1f53c3c7-412d-40fb-826e-6b3ed5779e2b', 'IsDraft', 'Boolean', 'False', 'False' , 1, '299712c3-be35-4461-95ae-1a334f922784', 'True', 'True', 'False', 'True', 1, 0, 1, 'USERACCESSCLAIMS.IDENTITY.ISDRAFT', NULL, 0, 'False', 0, 0)
END
GO

-- UserAccessClaim.CreatedBy

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '50f23211-e340-4aa3-88c1-6e3fdc06c601')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Created By"},{ "Culture":"pt","Data":"Created By"},{ "Culture":"en","Data":"Created By"}]}', '50f23211-e340-4aa3-88c1-6e3fdc06c601', 'CreatedBy', 'LongText', 'False', 'False' , 1, '299712c3-be35-4461-95ae-1a334f922784', 'True', 'True', 'False', 'True', 1, 0, 1, 'USERACCESSCLAIMS.IDENTITY.CREATEDBY', NULL, 0, 'False', 0, 0)
END
GO

-- UserAccessClaim.CreatedOn

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '286b5100-4939-4278-a724-e2cd7b736f0c')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Created On"},{ "Culture":"pt","Data":"Created On"},{ "Culture":"en","Data":"Created On"}]}', '286b5100-4939-4278-a724-e2cd7b736f0c', 'CreatedOn', 'Datetime', 'False', 'False' , 1, '299712c3-be35-4461-95ae-1a334f922784', 'True', 'True', 'False', 'True', 1, 0, 1, 'USERACCESSCLAIMS.IDENTITY.CREATEDON', NULL, 0, 'False', 0, 0)
END
GO

-- UserAccessClaim.ModifiedBy

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '7aadc8ea-3235-4554-b1b9-f8bd42a607ab')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Modified By"},{ "Culture":"pt","Data":"Modified By"},{ "Culture":"en","Data":"Modified By"}]}', '7aadc8ea-3235-4554-b1b9-f8bd42a607ab', 'ModifiedBy', 'LongText', 'False', 'False' , 1, '299712c3-be35-4461-95ae-1a334f922784', 'True', 'True', 'False', 'True', 1, 0, 1, 'USERACCESSCLAIMS.IDENTITY.MODIFIEDBY', NULL, 0, 'False', 0, 0)
END
GO

-- UserAccessClaim.ModifiedOn

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'd257ffef-fd2f-419f-9b85-f5ed3abfe3b9')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Modified On"},{ "Culture":"pt","Data":"Modified On"},{ "Culture":"en","Data":"Modified On"}]}', 'd257ffef-fd2f-419f-9b85-f5ed3abfe3b9', 'ModifiedOn', 'Datetime', 'False', 'False' , 1, '299712c3-be35-4461-95ae-1a334f922784', 'True', 'True', 'False', 'True', 1, 0, 1, 'USERACCESSCLAIMS.IDENTITY.MODIFIEDON', NULL, 0, 'False', 0, 0)
END
GO

-- UserAccessClaim.IsActive

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'cc63bd43-6ff1-4a7a-bfc4-4599da42d51f')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Active"},{ "Culture":"pt","Data":"Active"},{ "Culture":"en","Data":"Active"}]}', 'cc63bd43-6ff1-4a7a-bfc4-4599da42d51f', 'IsActive', 'Boolean', 'False', 'False' , 1, '299712c3-be35-4461-95ae-1a334f922784', 'True', 'True', 'False', 'True', 1, 0, 1, 'USERACCESSCLAIMS.IDENTITY.ISACTIVE', NULL, 0, 'False', 0, 0)
END
GO

-- UserAccessClaim.IsDeleted

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '39af7949-3584-48aa-a3ae-02c4c2a4fbdc')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Deleted"},{ "Culture":"pt","Data":"Deleted"},{ "Culture":"en","Data":"Deleted"}]}', '39af7949-3584-48aa-a3ae-02c4c2a4fbdc', 'IsDeleted', 'Boolean', 'False', 'False' , 1, '299712c3-be35-4461-95ae-1a334f922784', 'True', 'True', 'True', 'True', 1, 0, 1, 'USERACCESSCLAIMS.IDENTITY.ISDELETED', NULL, 0, 'False', 0, 0)
END
GO

-- UserAccessClaim.IsSystem

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '9a841736-35ed-4a94-af58-610e9b21da20')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"System"},{ "Culture":"pt","Data":"System"},{ "Culture":"en","Data":"System"}]}', '9a841736-35ed-4a94-af58-610e9b21da20', 'IsSystem', 'Boolean', 'False', 'False' , 1, '299712c3-be35-4461-95ae-1a334f922784', 'True', 'True', 'False', 'True', 1, 0, 1, 'USERACCESSCLAIMS.IDENTITY.ISSYSTEM', NULL, 0, 'False', 0, 0)
END
GO

-- UserAccessClaim.User

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'e2dddf0f-5ae7-46d8-93e0-bb937f59aa52')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"User"},{ "Culture":"pt","Data":"User"},{ "Culture":"en","Data":"User"}]}', 'e2dddf0f-5ae7-46d8-93e0-bb937f59aa52', 'User', 'View', 'True', 'False' , 1, '299712c3-be35-4461-95ae-1a334f922784', 'True', 'True', 'False', 'False', 1, 0, 1, 'USERACCESSCLAIMS.IDENTITY.USER', '737af993-cd13-42d3-819f-77ee667da957', 0, 'False', 1, 0)
END
GO

-- UserAccessClaim.User

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaEntitiesAssociations] WHERE [Id] = '313e8655-3053-0013-7e86-c574d179ff10')
BEGIN
    INSERT INTO [CorePatterns].[SchemaEntitiesAssociations] ([Id], [SchemaEntityId], [TargetId], [AttributeId], [IsComposition], [IsManyToMany], [IsActive], [IsDeleted], [IsSystem])
    VALUES ('313e8655-3053-0013-7e86-c574d179ff10', '299712c3-be35-4461-95ae-1a334f922784', '737af993-cd13-42d3-819f-77ee667da957', 'e2dddf0f-5ae7-46d8-93e0-bb937f59aa52', 0, 0, 1, 0, 1)
END
GO

-- UserAccessClaim.AccessClaim

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = 'abcacaa7-7f75-49a9-afa2-13de413f00c0')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"es","Data":"Access Claim"},{ "Culture":"pt","Data":"Access Claim"},{ "Culture":"en","Data":"Access Claim"}]}', 'abcacaa7-7f75-49a9-afa2-13de413f00c0', 'AccessClaim', 'Number', 'True', 'False' , 1, '299712c3-be35-4461-95ae-1a334f922784', 'True', 'True', 'False', 'False', 1, 0, 1, 'USERACCESSCLAIMS.IDENTITY.ACCESSCLAIM', NULL, 0, 'False', 1, 0)
END
GO

-- =========================================================================
-- Create [CorePatterns].[CompaniesIncludeDeletedView] View
-- =========================================================================

IF EXISTS(SELECT id FROM sysobjects WHERE id = OBJECT_ID('[CorePatterns].[CompaniesIncludeDeletedView]'))
	DROP VIEW [CorePatterns].[CompaniesIncludeDeletedView]
GO

CREATE VIEW [CorePatterns].[CompaniesIncludeDeletedView]
WITH SCHEMABINDING AS
SELECT
    E.[Id]
    , E.[CompanyKey]
	, E.[IsExternal]
	, E.[ShowExchangeRateReversed]
	, E.[Name]
	, E.[SearchTerm]
	, E.[CompanyTaxID]
	, E.[Telephone]
	, E.[TeleFax]
	, E.[Mobile]
	, E.[ElectronicMail]
	, E.[EquityCapital]
	, E.[RegistrationOffice]
	, E.[RegistrationNumber]
	, E.[CountryId]
	, E.[BaseCurrencyId]
	, E.[AddressId]
	, E.[Logo]
	, E.[LogoThumbnail]
	, E.[CompanyRegistrationData]
	, E.[AccessClaim]
	, E.[NaturalKey]
	, E.[IsDraft]
	, E.[CreatedBy]
	, E.[CreatedOn]
	, E.[ModifiedBy]
	, E.[ModifiedOn]
	, E.[IsActive]
	, E.[IsDeleted]
	, E.[IsSystem]
	, E.[Version]
FROM [CorePatterns].[Companies] E
GO

-- =========================================================================
-- Company TVF's
-- =========================================================================

-- List Query TVF: CompaniesQuery

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'CompaniesQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[CompaniesQuery]
GO

CREATE FUNCTION  [CorePatterns].[CompaniesQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT [T1].[Id], [T1].[NaturalKey] AS [NaturalKey], [T1].[Name] AS [Name]
FROM [CorePatterns].[CompaniesIncludeDeletedView] [T1]
WHERE (NOT (([T1].[IsActive] = 0
AND [T1].[IsSystem] = 1))
AND ([T1].[NaturalKey] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR [T1].[Name] COLLATE Latin1_general_CI_AI LIKE @searchTerm COLLATE Latin1_general_CI_AI))
AND (ISNULL([T1].[AccessClaim], '') = ''
OR [T1].[AccessClaim] IN (SELECT AccessClaim
FROM [Identity].[UserAccessClaims]
WHERE ([UserAccessClaims].[AccessClaim] = [T1].[AccessClaim]
AND [UserAccessClaims].[UserId] = CAST(@user AS uniqueidentifier)))))
GO


--- [CorePatterns].[Companies_CompaniesQuery] (Default Entity TVF)

IF EXISTS ( SELECT  1
            FROM    Information_schema.Routines
            WHERE   Specific_schema = 'CorePatterns' AND 
                    specific_name = 'Companies_CompaniesQuery'
                    AND Routine_Type = 'FUNCTION' )
    DROP Function [CorePatterns].[Companies_CompaniesQuery]
GO

CREATE FUNCTION  [CorePatterns].[Companies_CompaniesQuery]
(@searchTerm NVARCHAR(100)  = '%', @user NVARCHAR(100)  = 'NULL', @culture NVARCHAR(100)  = 'NULL')
RETURNS TABLE
AS
RETURN
(SELECT *
FROM (SELECT [SRC].[Id], [SRC].[Source_NaturalKey], [SRC].[Source_IsDeleted], [SRC].[Logo], [SRC].[CompanyKey], [SRC].[Name], [SRC].[CountryKey], [SRC].[CountryId], [SRC].[CompanyTaxID], [SRC].[IsActive], [SRC].[IsSystem]
FROM (SELECT [T0].[Id] AS [Id], [T0].[NaturalKey] AS [Source_NaturalKey], [T0].[IsDeleted] AS [Source_IsDeleted], [T0].[LogoThumbnail] AS [Logo], [T0].[CompanyKey] AS [CompanyKey], [T0].[Name] AS [Name], [T1].[CountryKey] AS [CountryKey], [T1].[Id] AS [CountryId], [T0].[CompanyTaxID] AS [CompanyTaxID], [T0].[IsActive] AS [IsActive], [T0].[IsSystem] AS [IsSystem], AccessClaim
FROM [CorePatterns].[CompaniesIncludeDeletedView] [T0]
LEFT JOIN [CorePatterns].[CountriesView] [T1] ON [T0].[CountryId] = [T1].[Id]
WHERE (ISNULL([T0].[CompanyKey] COLLATE Latin1_general_CI_AI, '') LIKE @searchTerm COLLATE Latin1_general_CI_AI
OR ISNULL([T0].[Name] COLLATE Latin1_general_CI_AI, '') LIKE @searchTerm COLLATE Latin1_general_CI_AI)) [SRC]
WHERE (ISNULL([SRC].[AccessClaim], '') = ''
OR [SRC].[AccessClaim] IN (SELECT AccessClaim
FROM [Identity].[UserAccessClaims]
WHERE ([UserAccessClaims].[AccessClaim] = [SRC].[AccessClaim]
AND [UserAccessClaims].[UserId] = CAST(@user AS uniqueidentifier))))) [FILTERSRC]
WHERE NOT (IsActive = 0 and IsSystem = 1))
GO




DROP VIEW IF EXISTS [QueryBuilder].[ListModelColumnsView]
GO

IF NOT EXISTS (SELECT * FROM syscolumns WHERE id=object_id('[QueryBuilder].[ListModelColumns]') and name='GroupHeaderTemplate')
    ALTER TABLE [QueryBuilder].[ListModelColumns] ADD [GroupHeaderTemplate] nvarchar(255) NULL
GO

CREATE VIEW [QueryBuilder].[ListModelColumnsView]
WITH SCHEMABINDING AS
SELECT
    E.[Id]
    , E.[Name]
	, E.[Description]
	, E.[Sortable]
	, E.[Groupable]
	, E.[Searchable]
	, E.[DisplayOrder]
	, E.[PresentationDataType]
	, E.[SchemaAttributeId]
	, E.[GroupByDirection]
	, E.[GroupByIndex]
	, E.[OrderByDirection]
	, E.[OrderByIndex]
	, E.[Path]
	, E.[IsMainDrillDown]
	, E.[IsVisible]
	, E.[Uri]
	, E.[IsCustom]
	, E.[CustomExpression]
	, E.[IsLocalizable]
	, E.[StyleId]
	, E.[AggregationOperationId]
	, E.[DisplayAggregationInFooter]
	, E.[StandardFormattingId]
	, E.[StandardFormattingColumn]
	, E.[TotalOperationId]
	, E.[IsCustomAttribute]
	, E.[DecimalPlaces]
	, E.[GroupHeaderTemplate]
	, E.[ListModelId]
	, E.[Index]
	, E.[CreatedBy]
	, E.[CreatedOn]
	, E.[ModifiedBy]
	, E.[ModifiedOn]
	, E.[IsActive]
	, E.[IsDeleted]
	, E.[IsSystem]
	, E.[Version]
FROM [QueryBuilder].[ListModelColumns] E
WHERE E.[IsDeleted] = 0
GO

-- ListModelColumn.GroupHeaderTemplate

IF NOT EXISTS(SELECT 1 FROM [CorePatterns].[SchemaAttributes] WHERE Id = '951b3522-e588-4bf5-b9a7-fac5dccd1bd0')
BEGIN
    INSERT INTO [CorePatterns].[SchemaAttributes] ([Description], [Id], [Key], [AttributeType], [IsNaturalKey], [IsDescription], [Visible], [SchemaEntityId], [IsRequired], [Persisted], [IsInternal], [IsSystemBase], [IsActive], [IsDeleted], [IsSystem], [NaturalKey], [LookupEntityId], [IsSequenceManaged], [Localizable], [Cloneable], [IsPersonalData])
    VALUES ('{"Values":[{ "Culture":"en","Data":"Group Header Template"}]}', '951b3522-e588-4bf5-b9a7-fac5dccd1bd0', 'GroupHeaderTemplate', 'LongText', 'False', 'False' , 1, 'a2f80908-aee2-4b86-a4d5-01094820b159', 'False', 'True', 'False', 'False', 1, 0, 1, 'LISTMODELCOLUMNS.QUERYBUILDER.GROUPHEADERTEMPLATE', NULL, 0, 'False', 1, 0)
END
GO